#include <iostream>
#include <string.h>
#include "ByteBuffer.h"

using namespace bytebuffer;

int main()
{
#if 0 /* save 2K byte */
	ByteBuffer bb;
	byte temp = 0;
	int i = 0;
	for (i = 0; i < 2048; ++i)
	{
		bb.put(temp);
		temp = (temp + 1) % 255;
	}

	bb.printAscii();

	ByteBuffer bb2 = bb;
	bb2.printAscii();
#endif

	ByteBuffer bb;
	byte my_string[512] = "this is a test for bb!!!\n";
	bb.putBytes(my_string, strlen((const char*)my_string));
	bb.printAscii();

	memset(my_string, 0, sizeof(my_string));
	strcpy((char*)my_string, "Hello World\n");
	bb.putBytes(my_string, strlen((const char*)my_string));
	bb.printAscii();

	return 0;
}
