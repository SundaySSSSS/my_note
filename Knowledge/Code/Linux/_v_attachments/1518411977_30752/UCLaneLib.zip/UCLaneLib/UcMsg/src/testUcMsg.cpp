#include "UcMsg.h"

#include <iostream>
using namespace std;
using namespace ucmsg;


void savePic(int count, char* buf, size_t size)
{
	char imgPath[64] = {0};
	snprintf(imgPath, sizeof(imgPath), "%d.bmp", count);

	FILE* fp = fopen(imgPath, "wb");
	if (fp != NULL)
	{
		fwrite(buf, size, 1, fp);
		fclose(fp);
	}
	else
	{
		printf("savePic: open file error\n");
	}
}

//从硬盘上读取一张图片放入buffer中
void readPic(int count, char* buf, size_t* pSize)
{
	char file_path[128] = {0};

	if (buf == NULL || pSize == NULL)
	{
		printf("readPic: input param error\n");
		return;
	}

	snprintf(file_path, sizeof(file_path), "pic/%d.bmp", count);
	FILE* fp = fopen(file_path, "rb");
	if (fp != NULL)
	{
		fseek(fp, 0, SEEK_END);
		size_t fileSize = ftell(fp);
		rewind(fp);
		int read_len = fread(buf, 1, fileSize, fp);
		printf("readPic: read_len = %d, fileSize = %d\n", read_len, fileSize);
		*pSize = read_len;
		fclose(fp);
	}
	else
		printf("readPic: read pic %s error\n", file_path);
}

int main()
{
	/* 构建一个UcMsg */
	UcMsg um;
	um.append("test1", "value1");
	um.append("test2", "value2");

	byte temp[12] = "123456";
	size_t size = sizeof(temp);
	um.append("buffer1", temp, size);
	strcpy((char*)temp, "7890abcd");
	um.append("buffer2", temp, size);

	byte pic_buf[1024*1024] = {0};
	size_t pic_size = sizeof(pic_buf);
	readPic(0, (char*)pic_buf, &pic_size);
	um.append("imgData", pic_buf, pic_size);

	/* 重新建立一个UcMsg */
	size = um.getAllDataLen();
	cout << "origin data: " << endl;
	//um.printAllData();
	//UcMsg um_copied(um.getAllData(), size);
	UcMsg um_copied = UcMsg(um.getAllData(), size);
	cout << "copied data: " << endl;
	//um_copied.printAllData();

	/* 解析UcMsg */
	byte temp2[12] = {0};
	size = sizeof(temp2);
	string value = um_copied.parse("test1");
	cout << "test1 : " << value << endl;
	value = um_copied.parse("test2");
	cout << "test2 : " << value << endl;
	um_copied.parse("buffer1", temp2, size);
	cout << "buffer1 : " << string((char*)temp2) << " size = " << size << endl;

	memset(temp2, 0, sizeof(temp2));
	size = sizeof(temp2);
	um_copied.parse("buffer2", temp2, size);
	cout << "buffer2 : " << string((char*)temp2) << " size = " << size  << endl;

	memset(pic_buf, 0, sizeof(pic_buf));
	pic_size = sizeof(pic_buf);
	um_copied.parse("imgData", pic_buf, pic_size);
	savePic(1, (char*)pic_buf, pic_size);

	return 0;
}
