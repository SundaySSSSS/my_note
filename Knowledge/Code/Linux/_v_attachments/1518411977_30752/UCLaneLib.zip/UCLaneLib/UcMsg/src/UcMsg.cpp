/*
 * UcMsg.cpp
 *
 *  Created on: 2017-12-26
 *      Author: cxy
 */

#include "UcMsg.h"
#include "cjson/cJSON.h"

namespace ucmsg {

UcMsg::UcMsg()
{
	m_bData.clear();
	m_sData.clear();
	m_isCreated = false;
}

UcMsg::UcMsg(const byte* buf, size_t size)
{
	m_bData.clear();
	m_sData.clear();
	if (buf != NULL)
	{
		m_allData.putBytes(buf, size);
		if (readToMap() == 0)
			m_isCreated = true;
		else
			m_isCreated = false;
	}
	else
	{
		m_isCreated = false;
	}
}

UcMsg::~UcMsg()
{
	m_bData.clear();
	m_sData.clear();
}

const byte* UcMsg::getAllData()
{
	writeTotolData();
	return m_allData.getAllData();
}
size_t UcMsg::getAllDataLen()
{
	writeTotolData();
	return m_allData.size();
}

void UcMsg::printAllData()
{
	int i = 0;

	writeTotolData();
	m_allData.printHex();
}
/*
 * 约定协议为:
 * 协议头(0xaa, 0xbb) + 二进制块个数(4byte) + 序列化长度(4byte) + 序列化数据 +
 * 		第一个二进制块key字串长度(4byte) + 第一个二进制块key字串 + 第一个二进制块长度 + 第一个二进制块数据 +
 * 		... + 校验码(1byte) + 协议尾(2byte)
 * 协议头为0xaa, 0xbb
 * 协议尾为0xcc, 0xdd
 * 校验码为从协议头结束开始, 到校验码之前的所有数据byte的异或和
 * */

#define BLOCK_SIZE_LEN (4)	//块长度用几个字节存储
#define BIN_BLOCK_NUM_LEN (4)	//二进制块个数用几个字节存储
#define HEAD_LEN (2)	//协议头长度
#define TAIL_LEN (2)	//协议尾长度
#define CHECK_CODE_LEN (1)	//校验码长度

int UcMsg::writeTotolData()
{
	if (m_isCreated == true)
	{	//当前已经写入过, 且未被修改, 直接退出
		return 0;
	}

	m_allData.clear();
	//写入协议头
	m_allData.put(0xaa);
	m_allData.put(0xbb);
	//二进制块个数
	m_allData.putInt(m_bData.size());
	//序列化数据
	string json;
	MapToJson(m_sData, json);
	m_allData.putInt(json.size() + 1);	//这里+1是要把末尾的\0也写入buffer中
	m_allData.putBytes((const byte*)(json.c_str()), json.size() + 1);
	//二进制数据长度和信息
	map<string, ByteBuffer>::iterator iter;
	for(iter = m_bData.begin(); iter != m_bData.end(); iter++)
	{
		string key = iter->first;
		//key字串长度
		m_allData.putInt(key.size());
		//key字串
		m_allData.putBytes((const byte*)(key.c_str()), key.size());
		//二进制数据长度
		m_allData.putInt(iter->second.size());
		//二进制数据
		m_allData.put((ByteBuffer*)&(iter->second));
	}
	//校验码
	byte checkCode = getXorValue(m_allData.getAllData() + HEAD_LEN,
			m_allData.size() - HEAD_LEN);	//此时m_allData还没有被填满, 只需去掉头即可
	m_allData.put(checkCode);
	//协议尾
	m_allData.put(0xcc);
	m_allData.put(0xdd);

	//标记已经写入完毕
	m_isCreated = true;
	return 0;
}

int UcMsg::readToMap()
{
	m_allData.setReadPos(0);	//从第一个元素开始读取
	//协议头
	if (m_allData.get() != 0xaa) return -1;
	if (m_allData.get() != 0xbb) return -1;
	//二进制块个数
	uint32_t binBlockCount = m_allData.getInt();
	//序列化数据长度
	size_t sDataSize = m_allData.getInt();
	//序列化数据
	byte* sData = new byte[sDataSize];
	memset(sData, 0, sDataSize);
	m_allData.getBytes(sData, sDataSize);
	//将序列化数据放入map中
	string json = string((const char*)sData, sDataSize);
	JsonToMap(json, m_sData);
	delete[] sData;
	//读取二进制数据
	int i = 0;
	for (i = 0; i < binBlockCount; ++i)
	{
		//获取二进制数据块键值
		uint32_t key_size = m_allData.getInt();
		byte* key = new byte[key_size + 1];
		memset(key, 0, key_size + 1);
		m_allData.getBytes(key, key_size);
		//获取二进制数据块数据
		uint32_t bData_size = m_allData.getInt();
		byte* bData = new byte[bData_size];
		memset(bData, 0, bData_size);
		m_allData.getBytes(bData, bData_size);
		m_bData.insert(map<string, ByteBuffer>::value_type(string((const char*)key, key_size), ByteBuffer(bData, bData_size)));
		delete[] key;
		delete[] bData;
	}
	//校验码
	byte checkCodeCalc = getXorValue(m_allData.getAllData() + HEAD_LEN,
			m_allData.size() - HEAD_LEN - TAIL_LEN - CHECK_CODE_LEN);
	byte checkCodeInMsg = m_allData.get();
	if (checkCodeInMsg != checkCodeCalc)
	{
		return -1;
	}
	//协议尾
	if (m_allData.get() != 0xcc) return -1;
	if (m_allData.get() != 0xdd) return -1;
	return 0;
}

int UcMsg::append(const string& key, const string& value)
{
	m_sData.insert(map<string, string>::value_type (key, value));
	m_isCreated = false;	//数据有更新, 修改为尚未创建状态
	return 0;
}

int UcMsg::append(const string& key, const byte* data, size_t size)
{
	int ret = 0;

	m_bData.insert(map<string, ByteBuffer>::value_type (key, ByteBuffer(data, size)));

	m_isCreated = false;	//数据有更新, 修改为尚未创建状态
	return ret;
}

string UcMsg::parse(const string& key)
{
	string value = "";
	map<string, string>::iterator iter;
	iter = m_sData.find(key);
	if(iter != m_sData.end())
	{
		value = iter->second;
	}
	return value;
}

int UcMsg::parse(const string& key, byte* data, size_t& size)
{
	int ret = -1;

	if (data == NULL)
		return ret;

	map<string, ByteBuffer>::iterator iter;
	iter = m_bData.find(key);
	if(iter != m_bData.end())
	{	//找到了指定key
		memcpy(data, iter->second.getAllData(), iter->second.size());
		size = iter->second.size();
		ret = 0;
	}
	return ret;
}

int UcMsg::MapToJson(const map<string, string>& map_data, string& json)
{
	cJSON *root = cJSON_CreateObject();
	if (root == NULL)
	{
		return -1;
	}
	map<string, string>::const_iterator iter;
	for(iter = map_data.begin(); iter != map_data.end(); iter++)
	{
		cJSON_AddStringToObject(root, (iter->first).c_str(), (iter->second).c_str());
	}
	char* strJson = cJSON_Print(root);
	json = strJson;
	free(strJson);

	cJSON_Delete(root);
	return 0;
}

int UcMsg::JsonToMap(const string& json, map<string, string>& map_data)
{
	cJSON* root = cJSON_Parse(json.c_str());
	if (root == NULL)
	{
		return -1;
	}
	else
	{
		map_data.clear();
		cJSON* json_node = root->child;
		if (json_node == NULL)
		{
			cJSON_Delete(root);
			return -1;
		}
		else
		{
			do {
				map_data.insert(map<string, string>::value_type (json_node->string, json_node->valuestring));
				json_node = json_node->next;
			}
			while(json_node != NULL);
		}
	}
	cJSON_Delete(root);
	return 0;
}

/*
 * 取得byte字串的亦或校验值
 * 参数:
 * const byte* input - [in]待计算的byte字串
 * size_t len - [in]待计算的byte字串长度
 * 返回值:
 * 计算后的校验值
 * */
byte UcMsg::getXorValue(const byte* input, size_t len)
{
	byte ret = 0;
	int i = 0;

	//cout<<"the following bytes will be calc: " << endl;
	ret = input[0];
	//printf("0x%02x ", ret);
	for (i = 1; i < len; ++i)
	{
		ret ^= input[i];
		//printf("0x%02x ", input[i]);
	}

	//cout << endl<< "---------------------" << endl;
	//printf("calc ret = 0x%02x\n", ret);
	return ret;
}

}

