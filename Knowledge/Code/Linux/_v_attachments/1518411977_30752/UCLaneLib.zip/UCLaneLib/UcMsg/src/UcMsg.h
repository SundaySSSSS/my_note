/*
 * UcMsg.h
 *
 *  Created on: 2017-12-26
 *      Author: cxy
 */

#ifndef UCMSG_H_
#define UCMSG_H_

#include <string>
#include <map>
#include <vector>
#include <iostream>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "typedef.h"
#include "ByteBuffer/ByteBuffer.h"

using namespace std;

namespace ucmsg {

class UcMsg
{
public:
    UcMsg();
    UcMsg(const byte* buf, size_t size);
    ~UcMsg();

    //创建消息的方法
    int append(const string& key, const string& value);    //添加一条序列化数据
    int append(const string& key, const byte* data, size_t size);    //添加一条二进制数据
    //解析消息的方法
    string parse(const string& key);	//返回值: 非空-成功 空-失败
    int parse(const string& key, byte* data, size_t& size);

    const byte* getAllData();    //获取全数据地址
    size_t getAllDataLen();       //获取全数据长度

    void printAllData();	//打印全数据

private:
    map<string, string> m_sData;	//存储所有序列化数据
    map<string, ByteBuffer> m_bData;		//存储所有二进制数据, 内存为动态分配
    bool m_isCreated;	//消息是否创建完毕

    ByteBuffer m_allData;
    int writeTotolData();	//将map中的数据写入m_allData中
    int readToMap();		//将m_allData中的数据解析到map中
    int MapToJson(const map<string, string>& map_data, string& json);	//将map转化为json字符串
    int JsonToMap(const string& json, map<string, string>& map_data);
    /*
     * 取得byte字串的亦或校验值
     * 参数:
     * const byte* input - [in]待计算的byte字串
     * size_t len - [in]待计算的byte字串长度
     * 返回值:
     * 计算后的校验值
     * */
    byte getXorValue(const byte* input, size_t len);
};

}	//namespace ucmsg

#endif /* UCMSG_H_ */
