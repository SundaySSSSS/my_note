
#include "ByteBuffer.h"

namespace ucmsg {

/**
 * ByteBuffer constructor
 * Reserves specified size in internal vector
 *
 * @param size Size (in bytes) of space to preallocate internally. Default is set in DEFAULT_SIZE
 */
ByteBuffer::ByteBuffer(size_t size)
{
	buf.reserve(size);
	clear();
}

/**
 * ByteBuffer constructor
 * Consume an entire uint8_t array of length len in the ByteBuffer
 *
 * @param arr uint8_t array of data (should be of length len)
 * @param size Size of space to allocate
 */
ByteBuffer::ByteBuffer(const byte* arr, size_t size) {
	// If the provided array is NULL, allocate a blank buffer of the provided size
	if (arr == NULL) {
		buf.reserve(size);
		clear();
	} else { // Consume the provided array
		buf.reserve(size);
		clear();
		putBytes(arr, size);
	}
}

/**
 * Bytes Remaining
 * Returns the number of bytes from the current read position till the end of the buffer
 *
 * @return Number of bytes from rpos to the end (size())
 */
size_t ByteBuffer::bytesRemaining() {
	return size() - rpos;
}

/**
 * Clear
 * Clears out all data from the internal vector (original preallocated size remains), resets the positions to 0
 */
void ByteBuffer::clear() {
	rpos = 0;
	wpos = 0;
	buf.clear();
}

/**
 * Equals, test for data equivilancy
 * Compare this ByteBuffer to another by looking at each byte in the internal buffers and making sure they are the same
 *
 * @param other A pointer to a ByteBuffer to compare to this one
 * @return True if the internal buffers match. False if otherwise
 */
bool ByteBuffer::equals(ByteBuffer* other) {
	// If sizes aren't equal, they can't be equal
	if (size() != other->size())
		return false;

	// Compare byte by byte
	size_t len = size();
	for (size_t i = 0; i < len; i++) {
		if ((byte) get(i) != (byte) other->get(i))
			return false;
	}

	return true;
}

/**
 * Resize
 * Reallocates memory for the internal buffer of size newSize. Read and write positions will also be reset
 *
 * @param newSize The amount of memory to allocate
 */
void ByteBuffer::resize(size_t newSize) {
	buf.resize(newSize);
	rpos = 0;
	wpos = 0;
}

/**
 * Size
 * Returns the size of the internal buffer...not necessarily the length of bytes used as data!
 *
 * @return size of the internal buffer
 */
size_t ByteBuffer::size() const {
	return buf.size();
}

// Read Functions
byte ByteBuffer::get() const {
	return read<byte>();
}

byte ByteBuffer::get(int index) const {
	return read<byte>(index);
}

void ByteBuffer::getBytes(byte* buf, size_t len) const {
	for (size_t i = 0; i < len; i++) {
		buf[i] = read<byte>();
	}
}

char ByteBuffer::getChar() const {
	return read<char>();
}

char ByteBuffer::getChar(int index) const {
	return read<char>(index);
}

double ByteBuffer::getDouble() const {
	return read<double>();
}

double ByteBuffer::getDouble(int index) const {
	return read<double>(index);
}

float ByteBuffer::getFloat() const {
	return read<float>();
}

float ByteBuffer::getFloat(int index) const {
	return read<float>(index);
}

uint32_t ByteBuffer::getInt() const {
	return read<uint32_t>();
}

uint32_t ByteBuffer::getInt(int index) const {
	return read<uint32_t>(index);
}

uint64_t ByteBuffer::getLong() const {
	return read<uint64_t>();
}

uint64_t ByteBuffer::getLong(int index) const {
	return read<uint64_t>(index);
}

uint16_t ByteBuffer::getShort() const {
	return read<uint16_t>();
}

uint16_t ByteBuffer::getShort(int index) const {
	return read<uint16_t>(index);
}

const byte* ByteBuffer::getAllData() {
	return &(buf[0]);
}

// Write Functions

void ByteBuffer::put(const ByteBuffer* src) {
	size_t len = src->size();
	for (size_t i = 0; i < len; i++)
		append<byte>(src->get(i));
}

void ByteBuffer::put(byte b) {
	append<byte>(b);
}

void ByteBuffer::put(byte b, uint32_t index) {
	insert<byte>(b, index);
}

void ByteBuffer::putBytes(const byte* b, uint32_t len) {
	// Insert the data one byte at a time into the internal buffer at position i+starting index
	for (uint32_t i = 0; i < len; i++)
		append<byte>(b[i]);
}

void ByteBuffer::putBytes(const byte* b, uint32_t len, uint32_t index) {
	wpos = index;
	// Insert the data one byte at a time into the internal buffer at position i+starting index
	for (uint32_t i = 0; i < len; i++)
		append<byte>(b[i]);
}

void ByteBuffer::putChar(char value) {
	append<char>(value);
}

void ByteBuffer::putChar(char value, uint32_t index) {
	insert<char>(value, index);
}

void ByteBuffer::putDouble(double value) {
	append<double>(value);
}

void ByteBuffer::putDouble(double value, uint32_t index) {
	insert<double>(value, index);
}
void ByteBuffer::putFloat(float value) {
	append<float>(value);
}

void ByteBuffer::putFloat(float value, uint32_t index) {
	insert<float>(value, index);
}

void ByteBuffer::putInt(uint32_t value) {
	append<uint32_t>(value);
}

void ByteBuffer::putInt(uint32_t value, uint32_t index) {
	insert<uint32_t>(value, index);
}

void ByteBuffer::putLong(uint64_t value) {
	append<uint64_t>(value);
}

void ByteBuffer::putLong(uint64_t value, uint32_t index) {
	insert<uint64_t>(value, index);
}

void ByteBuffer::putShort(uint16_t value) {
	append<uint16_t>(value);
}

void ByteBuffer::putShort(uint16_t value, uint32_t index) {
	insert<uint16_t>(value, index);
}

void ByteBuffer::printAscii() {
	uint32_t length = buf.size();
	for (uint32_t i = 0; i < length; i++) {
		printf("%c ", buf[i]);
	}
	printf("\n");
}

void ByteBuffer::printHex() {
	uint32_t length = buf.size();

	for (uint32_t i = 0; i < length; i++) {
		printf("0x%02x ", buf[i]);
	}
	printf("\n");
}

}	/* namespace ucmsg */

