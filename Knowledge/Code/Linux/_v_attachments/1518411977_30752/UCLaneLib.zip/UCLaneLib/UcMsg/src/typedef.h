#ifndef _UC_MSG_TYPE_DEF_H_
#define _UC_MSG_TYPE_DEF_H_

namespace ucmsg {

typedef unsigned char byte;
typedef unsigned int uint32_t;
typedef unsigned long uint64_t;
typedef unsigned short uint16_t;

}

#endif /* _UC_MSG_TYPE_DEF_H_ */
