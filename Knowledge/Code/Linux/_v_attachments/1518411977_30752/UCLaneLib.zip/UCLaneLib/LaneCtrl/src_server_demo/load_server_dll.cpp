#include <stdlib.h>
#include <dlfcn.h>
#include <string.h>
#include <stdio.h>
#include "load_server_dll.h"


//动态库函数定义
lfLaneCtrlServer_Start					LaneCtrlServerDll_Start;
lfLaneCtrlServer_Stop					LaneCtrlServerDll_Stop;
lfLaneCtrlServer_RegGetTimeCallback		LaneCtrlServerDll_RegGetTimeCallback;
lfLaneCtrlServer_RegSetTimeCallback		LaneCtrlServerDll_RegSetTimeCallback;
lfLaneCtrlServer_RegGetCarInfoCallback	LaneCtrlServerDll_RegGetCarInfoCallback;
lfLaneCtrlServer_RegUnlockCallback		LaneCtrlServerDll_RegUnlockCallback;
lfLaneCtrl_RegLogCallback    			LaneCtrlDll_RegLogCallback;

#define DLL_FILENAME "liblanectrl.so"

//本文件全局变量
//动态库句柄
static void	*m_dllHandle = NULL;

//函数功能：	ndk.dll动态库加载
//DllPath	ndk.dll所在路径，结束不要有“\”
//返回值：	0-成功，其他-失败
int	LaneCtrlServerDll_Init(const char *DllPath)
{
	int	result = 0;
	char	FileName[256];
	char	*errorInfo;
	if(DllPath == NULL)
	{
		m_dllHandle = dlopen(DLL_FILENAME, RTLD_LAZY);
	}
	else
	{
		sprintf(FileName,"%s/%s",DllPath, DLL_FILENAME);
		m_dllHandle = dlopen(FileName, RTLD_LAZY);
	}
	if(m_dllHandle == NULL)
	{
		errorInfo = dlerror();
		printf("error info = %s\n",errorInfo);
		return -1;
	}

	/********************************取得接口*****************************************/
	LaneCtrlServerDll_Start = (lfLaneCtrlServer_Start)dlsym(m_dllHandle,"LaneCtrlServer_Start");
	if(LaneCtrlServerDll_Start == NULL)
	{
		printf("get *LaneCtrlServer_Start* address failed\n");
		result = -1;
	}
	LaneCtrlServerDll_Stop = (lfLaneCtrlServer_Stop)dlsym(m_dllHandle,"LaneCtrlServer_Stop");
	if(LaneCtrlServerDll_Stop == NULL)
	{
		printf("get *LaneCtrlServer_Stop* address failed\n");
		result = -1;
	}
	LaneCtrlServerDll_RegGetTimeCallback = (lfLaneCtrlServer_RegGetTimeCallback)dlsym(m_dllHandle,"LaneCtrlServer_RegGetTimeCallback");
	if(LaneCtrlServerDll_RegGetTimeCallback == NULL)
	{
		printf("get *LaneCtrlServer_RegGetTimeCallback* address failed\n");
		result = -1;
	}

	LaneCtrlServerDll_RegSetTimeCallback = (lfLaneCtrlServer_RegSetTimeCallback)dlsym(m_dllHandle,"LaneCtrlServer_RegSetTimeCallback");
	if(LaneCtrlServerDll_RegSetTimeCallback == NULL)
	{
		printf("get *LaneCtrlServer_RegSetTimeCallback* address failed\n");
		result = -1;
	}

	LaneCtrlServerDll_RegGetCarInfoCallback = (lfLaneCtrlServer_RegGetCarInfoCallback)dlsym(m_dllHandle,"LaneCtrlServer_RegGetCarInfoCallback");
	if(LaneCtrlServerDll_RegGetCarInfoCallback == NULL)
	{
		printf("get *LaneCtrlServer_RegGetCarInfoCallback* address failed\n");
		result = -1;
	}

	LaneCtrlServerDll_RegUnlockCallback = (lfLaneCtrlServer_RegUnlockCallback)dlsym(m_dllHandle,"LaneCtrlServer_RegUnlockCallback");
	if(LaneCtrlServerDll_RegUnlockCallback == NULL)
	{
		printf("get *LaneCtrlServer_RegUnlockCallback* address failed\n");
		result = -1;
	}
	LaneCtrlDll_RegLogCallback = (lfLaneCtrl_RegLogCallback)dlsym(m_dllHandle,"LaneCtrl_RegLogCallback");
	if(LaneCtrlDll_RegLogCallback == NULL)
	{
		printf("get *LaneCtrl_RegLogCallback* address failed\r\n");
		result = -1;
	}
    
	if(result != 0)
	{
		//free so handle
		LaneCtrlServerDll_Free();
		return -1;
	}
	printf("LaneCtrlServerDll_Init: init dll success\n");
	return result;
}

//函数功能：动态库释放
void LaneCtrlServerDll_Free()
{
	if(m_dllHandle != NULL)
	{
		dlclose(m_dllHandle);
		m_dllHandle = NULL;
	}
}




