#include "LaneCtrlClientDll.h"
#include "client/client.h"
#include "utils/utils.h"

#define CLIENT_LIST_MAX (100)

LaneCtrlClient* g_ClientList[CLIENT_LIST_MAX] = {0};

//从客户端列表中找一个未被使用的
//返回值：0-CLIENT_LIST_MAX: OK 其他: 失败
int findEmptyPosInClientList()
{
    int i = 0;
    for (i = 0; i < CLIENT_LIST_MAX; ++i)
    {
        if (g_ClientList[i] == NULL)
        {
            return i;
        }
    }
    return -1;
}

//确认输入的客户端id是否合法
//返回值： 1-合法 0-非法
int isDevIdValid(int devId)
{
    if (devId >= 0 && devId < CLIENT_LIST_MAX)
    {
        return 1;
    }
    return 0;
}

int LaneCtrl_Connect (const char * deviceIP, int deviceType)
{
	LaneCtrlClient* pClient = new LaneCtrlClient();
	if (pClient == NULL)
		return -1;
	if (pClient->Connect(deviceIP, DEFAULT_PORT) != 0)
	{
		delete pClient;
		return -2;
	}
    int index = findEmptyPosInClientList();
    if (isDevIdValid(index))
    {
        g_ClientList[index] = pClient;
        return index;
    }
    else
    {
        dbout("no space in client list\n");
        delete pClient;
        return -1;
    }
}

int LaneCtrl_DisConnect (int devId)
{
	int ret = -1;

    if (isDevIdValid(devId) == 0)
    {
        dbout("input devId error, %d\n", devId);
        return ret;
    }
    if (g_ClientList[devId] != NULL)
    {
    	g_ClientList[devId]->DisConnect();
        delete g_ClientList[devId];
        g_ClientList[devId] = NULL;
        ret = 0;
    }
    else
    {
        dbout("this devId already delete, %d\n", devId);
    }
	return ret;
}

int LaneCtrl_GetVersion(int devId, char* ver)
{
	if (ver == NULL)
		return -1;
	if (isDevIdValid(devId) == 0)
		return -2;
	return g_ClientList[devId]->GetVersion(ver);
}

int LaneCtrl_GetTime(int devId, char* time)
{
	if (time == NULL)
		return -1;
	if (isDevIdValid(devId) == 0)
		return -2;
	return g_ClientList[devId]->GetTime(time);
}

int LaneCtrl_SetTime(int devId, const char* time)
{
	if (time == NULL)
		return -1;
	if (isDevIdValid(devId) == 0)
		return -2;
	return g_ClientList[devId]->SetTime(time);
}

int LaneCtrl_GetCarInfo(int devId, SUpCarInfo * carInfo)
{
	if (carInfo == NULL)
		return -1;
	if (isDevIdValid(devId) == 0)
		return -2;
	return g_ClientList[devId]->GetCarInfo(carInfo);
}

int LaneCtrl_Unlock(int devId)
{
	if (isDevIdValid(devId) ==  0)
		return -2;
	return g_ClientList[devId]->SetLock(0);
}

