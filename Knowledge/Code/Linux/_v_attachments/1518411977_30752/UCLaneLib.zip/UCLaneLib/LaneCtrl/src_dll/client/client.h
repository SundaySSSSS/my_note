#ifndef _LANE_CTRL_CLIENT_H_
#define _LANE_CTRL_CLIENT_H_

#include "../global.h"
#include "../msg/msg.h"
#include "../LaneCtrlClientDll.h"

class LaneCtrlClient
{
private:
	/* ip,端口 */
	char m_ip_server[20];
	int m_port;

	/* socket */
	int m_sock;

	/* 通信锁 */
	pthread_mutex_t m_comm_mutex;

	int CreateSocket(void);	//创建socket

	/* 线程句柄 */
	pthread_t m_comm_handle;

	/* 通信处理函数 */
	friend void* do_comm_client(void* pthis);

public:
	LaneCtrlClient();
	~LaneCtrlClient();
	int Connect(const char* ip_center, int port);
	void DisConnect();

	int GetVersion(char * ver);
	int SetTime(const char * time);
	int GetTime(char * time);
	int GetCarInfo(SUpCarInfo* carInfo);
	int SetLock(int lockCmd);	//lockCmd == 0 解锁, lockCmd != 0 锁定
};

#endif /* _LANE_CTRL_CLIENT_H_ */

