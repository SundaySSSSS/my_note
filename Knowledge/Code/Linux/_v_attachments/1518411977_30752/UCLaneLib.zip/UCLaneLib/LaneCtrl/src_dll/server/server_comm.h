#ifndef _LANE_CTRL_COMM_H_
#define _LANE_CTRL_COMM_H_

#include "../global.h"

void* do_comm_server(void* pthis);

#endif /* _LANE_CTRL_COMM_H_ */
