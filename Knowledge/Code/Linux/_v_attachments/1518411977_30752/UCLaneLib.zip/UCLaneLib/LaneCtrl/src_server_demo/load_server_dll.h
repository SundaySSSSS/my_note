#ifndef	_LOAD_SERVER_DLL_H_
#define	_LOAD_SERVER_DLL_H_

#include <stdlib.h>
#include "../interface/interface.h"

typedef int (*lfLaneCtrlServer_Start)(void);
typedef int (*lfLaneCtrlServer_Stop)(void);
typedef void (*lfLaneCtrlServer_RegGetTimeCallback)(int (*getTime_callback)(char* time));
typedef void (*lfLaneCtrlServer_RegSetTimeCallback)(int (*setTime_callback)(const char* time));
typedef void (*lfLaneCtrlServer_RegGetCarInfoCallback)(int (*getCarInfo_callback)(SUpCarInfo* carinfo));
typedef void (*lfLaneCtrlServer_RegUnlockCallback)(int (*unlock_callback)(void));
typedef int (*lfLaneCtrl_RegLogCallback)(void (*printLogCallback)(const char* log));

////////////////////////////////////////////////////////////////////
//函数功能：	动态库加载
//DllPath	动态库所在路径，结束不要有“\”
//返回值：	0成功，1加载动态库失败，2在动态库中找函数失败
int	LaneCtrlServerDll_Init(const char *DllPath);

//函数功能：	动态库释放
void LaneCtrlServerDll_Free();

/********************************车道动态库服务器接口*****************************************/
extern lfLaneCtrlServer_Start					LaneCtrlServerDll_Start;
extern lfLaneCtrlServer_Stop					LaneCtrlServerDll_Stop;
extern lfLaneCtrlServer_RegGetTimeCallback		LaneCtrlServerDll_RegGetTimeCallback;
extern lfLaneCtrlServer_RegSetTimeCallback		LaneCtrlServerDll_RegSetTimeCallback;
extern lfLaneCtrlServer_RegGetCarInfoCallback	LaneCtrlServerDll_RegGetCarInfoCallback;
extern lfLaneCtrlServer_RegUnlockCallback		LaneCtrlServerDll_RegUnlockCallback;
extern lfLaneCtrl_RegLogCallback    			LaneCtrlDll_RegLogCallback;

#endif	/* _LOAD_SERVER_DLL_H_ */
