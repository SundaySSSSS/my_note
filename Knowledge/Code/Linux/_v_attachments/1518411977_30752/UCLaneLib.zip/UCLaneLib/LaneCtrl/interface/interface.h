#ifndef _LANE_CTRL_INTERFACE_H_
#define _LANE_CTRL_INTERFACE_H_

#define CARINFO_TYPE_NOTHING (-1)	//当前无车
#define CARINFO_TYPE_NORMAL (0)		//正常车辆
#define CARINFO_TYPE_PLATE_STEALCARD (1)	//有牌车盗卡
#define CARINFO_TYPE_NO_PLATE_STEALCARD (2) //无牌车盗卡
#define CARINFO_TYPE_ETC_STEALCARD (3) //ETC盗卡

typedef struct _SUpCarInfo
{
	int		ID;					//内部编号,可出现不连续
	int	    carType_int;		//SVM识别出来的未翻译的类别[数值标签]	取值:正常车[101 999], 倒车正常车[1101 1999],干扰车{0}
	int		carType;			//翻译后的车型结果[数值型] 根据翻译表进行赋值，不同的地方不一样
	char	carTypeStr[64];	//翻译后的车型结果[字符串] 根据翻译表进行赋值，不同的地方不一样
	int		carLength;			//车辆长度(单位:厘米)
	int		carHeight;			//车头高度(单位:厘米)
	char	szAxleType[9];	//轴型
	char	plateNump[20];	//G25设备内部车牌号码,G2设备此值失效
	char	plateColor[5];	//G25设备内部车牌颜色,G2设备此值失效
	char	bigImgData[1024*1024];	//全景图内存地址，至少1M内存
	int		imgSize;					//全景图大小
	char    carTypeUpDownFlag;	//上下工位判定标记,0-下工位;1-上工位
	char    nLKYW;		//两客一危标记 0-非两客一危车辆, 1-两客车辆 2-危险品车辆
	int 	type;		//信息类型, -1-当前无车 0-正常车（未违章） 1-有牌车盗卡(只有车牌，但可通过车牌查询出车辆的其它信息) 2-无牌车盗卡（只记录一次盗卡，无任何车辆信息） 3-ETC盗卡（只记录车牌）
}SUpCarInfo;

#endif /* _LANE_CTRL_INTERFACE_H_ */
