#ifndef _LANE_CTRL_MSG_H_
#define _LANE_CTRL_MSG_H_

#include "../global.h"
#include "../server/server.h"
#include "../LaneCtrlClientDll.h"

#include "UcMsgInterface.h"

using namespace ucmsg;

//数据集Key
#define MSG_TYPE_STR "msgType"
#define DATA_STR "data"
/* 车型类型 */
#define CARINFO_TYPE_STR "carInfoType"		//0-正常车（未违章）1-有牌车盗卡(只有车牌)2-无牌车盗卡（无任何车辆信息）3-ETC盗卡（只记录车牌）
/* 车型数据相关 */
#define ID_STR "ID"							//内部编号,可出现不连续
#define CARTYPE_INT_STR "carTypeInt"		//SVM识别出来的未翻译的类别[数值标签]	取值:正常车[101 999], 倒车正常车[1101 1999],干扰车{0}
#define CARTYPE_STR "carType"				//车型
#define CARTYPE_STR_STR "carTypeStr"		//车型字符串
#define CARLENGTH_STR "carLength"			//车辆长度(单位:厘米)
#define CARHEIGHT_STR "carHeight"			//车头高度(单位:厘米)
#define AXLE_TYPE_STR "axleType"			//轴型
#define PLATE_NUMP_STR "plateNump"			//车牌号码
#define PLATE_COLOR_STR "plateColor"		//车牌颜色
#define IMG_SIZE_STR "imgSize"				//全景图大小
#define UP_DOWN_FLAG_STR "upDownFlag"		//上下工位判定标记,0-下工位;1-上工位
#define LKYW_STR "LKYW"						//两客一危标记 0-非两客一危车辆, 1-两客车辆 2-危险品车辆

#define IMG_DATA_STR "imgData"				//车辆图片

//消息类型字符串
#define MSG_TYPE_UNINIT_STR "UNINIT"	//未初始化
#define MSG_TYPE_UNKNOWN_STR "UNKNOWN"	//未知类型(初始化过了, 但是不知道是什么类型的消息)
#define MSG_TYPE_GET_TIME_STR "GET_TIME"
#define MSG_TYPE_GET_TIME_REPLY_STR "GET_TIME_REPLY"
#define MSG_TYPE_SET_TIME_STR "SET_TIME"
#define MSG_TYPE_SET_TIME_REPLY_STR "SET_TIME_REPLY"
#define MSG_TYPE_GET_CARINFO_STR "GET_CARINFO"
#define MSG_TYPE_GET_CARINFO_REPLY_STR "GET_CARINFO_REPLY"
#define MSG_TYPE_SET_LOCK_STR "SET_LOCK"
#define MSG_TYPE_SET_LOCK_REPLY_STR "SET_LOCK_REPLY"

class Message
{
private:
	UcMsg m_UcMsg;
public:
	Message();
	Message(const byte* buf, size_t size);
	~Message();

	string GetType() { return m_UcMsg.parse(MSG_TYPE_STR); }

	const byte* getAllData() { return m_UcMsg.getAllData(); }
	size_t getAllDataLen() { return m_UcMsg.getAllDataLen(); }
	void printAllData() { m_UcMsg.printAllData(); }


	/* GET_TIME相关 */
	void CreateGetTimeRequest();
	int ParseGetTimeRequest();
	void CreateGetTimeReply(const string& timeStr);
	int ParseGetTimeReply(string& timeStr);

	/* SET_TIME相关 */
	void CreateSetTimeRequest(const string& timeStr);
	int ParseSetTimeRequest(string& timeStr);
	void CreateSetTimeReply(bool isOK);
	int ParseSetTimeReply(bool& isOK);

	/* SET_LOCK相关 */
	void CreateSetLockRequest(int lockCmd);	//lockCmd == 0 解锁, lockCmd != 0 锁定
	int ParseSetLockRequest(int& lockCmd);
	void CreateSetLockReply(bool isOK);
	int ParseSetLockReply(bool& isOK);

	/* GET_CARINFO相关 */
	void CreateGetCarInfoRequest();
	int ParseGetCarInfoRequest();
	//int isHaveCarInfo-是否有车型信息, 如果为0, 则后面两个参数无效, 如果为1, 将会构建车型信息数据
	void CreateGetCarInfoReply(const SUpCarInfo& carInfo);
	int ParseGetCarInfoReply(SUpCarInfo& carInfo);
};

#endif /* _LANE_CTRL_MSG_H_ */
