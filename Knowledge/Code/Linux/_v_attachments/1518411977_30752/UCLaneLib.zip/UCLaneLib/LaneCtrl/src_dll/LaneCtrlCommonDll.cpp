#include "LaneCtrlCommonDll.h"
#include "utils/utils.h"

void LaneCtrl_RegLogCallback(void (*printLogCallback)(const char* log))
{
	m_log_callback = printLogCallback;
}

