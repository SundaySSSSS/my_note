#include "server.h"
#include "../utils/utils.h"
#include "../msg/msg.h"

LaneCtrlServer::LaneCtrlServer()
{
	m_port = DEFAULT_PORT;
	m_sock = -1;
	m_run_flag = 0;
	//设置内核参数, 增大网络缓冲
	system("sysctl -w net.core.rmem_max=2048576");
	system("sysctl -w net.core.wmem_max=2048576");
}

LaneCtrlServer::~LaneCtrlServer()
{
	Stop();
}

int LaneCtrlServer::CreateSocket(void)
{
	int ret = 0;
	int sock = 0;

	sock = Utils::CreateSocket_Reply(m_port);
	if (sock < 0)
	{
		dbout("init socket error\n");
		ret = -1;
	}
	else
	{
		m_sock = sock;
		ret = 0;
	}
	return ret;
}

int LaneCtrlServer::StartComm(void)
{
	int ret = 0;

	if((pthread_create(&m_comm_handle, NULL, do_comm_server, this)) != 0)
	{	//创建线程失败
		dbout("create thread error\n");
		ret = -1;
	}
	else
		pthread_detach(m_comm_handle);

	return ret;
}

int LaneCtrlServer::Start()
{
	if (CreateSocket() < 0)
	{
		dbout("create socket error\n");
		return -1;
	}

	m_run_flag = 1;
	if (StartComm() < 0)
	{
		dbout("start communication error\n");
		return -1;
	}

	return 0;
}

int LaneCtrlServer::Stop()
{
	m_run_flag = 0;
	if (m_sock >= 0)
	{
		nn_close(m_sock);
		m_sock = -1;
	}
	return 0;
}

