#include "client.h"
#include "../utils/utils.h"

LaneCtrlClient::LaneCtrlClient()
{
	memset(m_ip_server, 0, sizeof(m_ip_server));
	m_port = 0;
	m_sock = -1;
	m_comm_handle = 0;
	pthread_mutex_init(&m_comm_mutex, NULL);
	//设置内核参数, 增大网络缓冲
	system("sysctl -w net.core.rmem_max=2048576");
	system("sysctl -w net.core.wmem_max=2048576");
}

LaneCtrlClient::~LaneCtrlClient()
{
	DisConnect();
	pthread_mutex_destroy(&m_comm_mutex);
}

int LaneCtrlClient::CreateSocket(void)
{
	int ret = 0;

	int sock = Utils::CreateSocket_Request(m_ip_server, m_port);

	if (sock < 0)
	{
		dbout("init socket error\n");
		ret = -1;
	}
	else
	{
		m_sock = sock;
		ret = 0;
	}
	return ret;
}

int LaneCtrlClient::Connect(const char* ip_center, int port)
{
	if (ip_center == NULL)
		return -1;

	strncpy(m_ip_server, ip_center, sizeof(m_ip_server));
	m_port = port;
	return CreateSocket();
}
void LaneCtrlClient::DisConnect()
{
	if (m_sock >= 0)
	{
		nn_close(m_sock);
		m_sock = 0;
	}
}

int LaneCtrlClient::GetVersion(char * ver)
{
	if (ver == NULL)
		return -1;

	memcpy(ver, VERSION, strlen(VERSION));
	return 0;
}

int LaneCtrlClient::SetTime(const char * time)
{
	int ret = -1;

	if (time == NULL)
		return -1;

	dbout("set time %s\n", time);
	Message msg_send;
	string timeStr = time;
	msg_send.CreateSetTimeRequest(timeStr);
	if (Utils::Msg_Send(m_sock, msg_send) != 0)
	{
		dbout("send error\n");
	}
	else
	{
		Message msg_recv;
		if (Utils::Msg_RecvTimeOut(m_sock, msg_recv, RECV_TIME_OUT) == 0)
		{
			dbout("server replied\n");
			bool isSetOK = false;
			if (msg_recv.ParseSetTimeReply(isSetOK) == 0)
			{
				if (isSetOK == true)
				{
					dbout("set time OK\n");
					ret = 0;
				}
				else
					dbout("set time NG\n");
			}
			else
				dbout("parse reply error\n");
		}
		else
			dbout("receive error\n");
	}
	return ret;
}

int LaneCtrlClient::GetTime(char * time)
{
	int ret = -1;

	if (time == NULL)
		return -1;

	Message msg_send;
	msg_send.CreateGetTimeRequest();

	if (Utils::Msg_Send(m_sock, msg_send) != 0)
	{
		dbout("send error\n");
	}
	else
	{
		Message msg_recv;
		if (Utils::Msg_RecvTimeOut(m_sock, msg_recv, RECV_TIME_OUT) == 0)
		{
			dbout("server replied\n");
			bool isSetOK = false;
			string server_time;
			if (msg_recv.ParseGetTimeReply(server_time) == 0)
			{
				strcpy(time, server_time.c_str());
				dbout("get time success, time = %s\n", time);
				ret = 0;
			}
			else
				dbout("parse reply error\n");
		}
		else
			dbout("receive error\n");
	}
	return ret;
}

int LaneCtrlClient::GetCarInfo(SUpCarInfo* carInfo)
{
	int ret = -1;
	if (carInfo == NULL)
		return -1;

	Message msg_send;
	msg_send.CreateGetCarInfoRequest();
	if (Utils::Msg_Send(m_sock, msg_send) != 0)
	{
		dbout("send error\n");
	}
	else
	{
		Message msg_recv;
		if (Utils::Msg_RecvTimeOut(m_sock, msg_recv, RECV_TIME_OUT) == 0)
		{
			dbout("server replied\n");
			SUpCarInfo reply_carInfo = {0};
			if (msg_recv.ParseGetCarInfoReply(reply_carInfo) == 0)
			{
				if (reply_carInfo.type == -1)
				{	//没有车型信息
					ret = 1;
				}
				else
				{
					*carInfo = reply_carInfo;
					ret = 0;
				}
			}
			else
				dbout("parse reply error\n");
		}
		else
			dbout("receive error\n");
	}
	return ret;
}

int LaneCtrlClient::SetLock(int lockCmd)
{
	int ret = -1;

	Message msg_send;
	msg_send.CreateSetLockRequest(lockCmd);
	if (Utils::Msg_Send(m_sock, msg_send) != 0)
	{
		dbout("send error\n");
	}
	else
	{
		Message msg_recv;
		if (Utils::Msg_RecvTimeOut(m_sock, msg_recv, RECV_TIME_OUT) == 0)
		{
			dbout("server replied\n");
			bool isOK = false;
			if (msg_recv.ParseSetLockReply(isOK) == 0)
			{
				if (isOK)
					ret = 0;
				else
					dbout("server reply ng\n");
			}
			else
				dbout("parse reply error\n");
		}
		else
			dbout("receive error\n");
	}
	return ret;
}

