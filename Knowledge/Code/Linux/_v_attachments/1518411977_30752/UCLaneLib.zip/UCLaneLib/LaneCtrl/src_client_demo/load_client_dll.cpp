#include <stdlib.h>
#include <dlfcn.h>
#include <string.h>
#include <stdio.h>
#include "load_client_dll.h"


//动态库函数定义
lfLaneCtrl_Connect			LaneCtrlDll_Connect;
lfLaneCtrl_DisConnect		LaneCtrlDll_DisConnect;
lfLaneCtrl_GetVersion		LaneCtrlDll_GetVersion;
lfLaneCtrl_GetTime			LaneCtrlDll_GetTime;
lfLaneCtrl_SetTime			LaneCtrlDll_SetTime;
lfLaneCtrl_GetCarInfo		LaneCtrlDll_GetCarInfo;
lfLaneCtrl_Unlock			LaneCtrlDll_Unlock;
lfLaneCtrl_RegLogCallback    LaneCtrlDll_RegLogCallback;

#define DLL_FILENAME "liblanectrl.so"

//本文件全局变量
//动态库句柄
static void *m_dllHandle = NULL;

//函数功能：	动态库加载
//DllPath	动态库所在路径，结束不要有“\”
//返回值：	0-成功，其他-失败
int	LaneCtrlClientDll_Init(const char *DllPath)
{
	int	result = 0;
	char	FileName[256];
	char	*errorInfo;
	if(DllPath == NULL)
	{
		m_dllHandle = dlopen(DLL_FILENAME, RTLD_LAZY);
	}
	else
	{
		sprintf(FileName,"%s/%s",DllPath, DLL_FILENAME);
		m_dllHandle = dlopen(FileName, RTLD_LAZY);
	}
	if(m_dllHandle == NULL)
	{
		errorInfo = dlerror();
		printf("error info = %s\n",errorInfo);
		return -1;
	}

	/********************************获取函数接口*****************************************/
	LaneCtrlDll_Connect = (lfLaneCtrl_Connect)dlsym(m_dllHandle,"LaneCtrl_Connect");
	if(LaneCtrlDll_Connect == NULL)
	{
		printf("get *LaneCtrl_Connect* address failed\n");
		result = -1;
	}
	LaneCtrlDll_DisConnect = (lfLaneCtrl_DisConnect)dlsym(m_dllHandle,"LaneCtrl_DisConnect");
	if(LaneCtrlDll_DisConnect == NULL)
	{
		printf("get *LaneCtrl_DisConnect* address failed\r\n");
		result = -1;
	}
	LaneCtrlDll_GetVersion = (lfLaneCtrl_GetVersion)dlsym(m_dllHandle,"LaneCtrl_GetVersion");
	if(LaneCtrlDll_GetVersion == NULL)
	{
		printf("get *LaneCtrl_GetVersion* address failed\r\n");
		result = -1;
	}
	LaneCtrlDll_GetTime = (lfLaneCtrl_GetTime)dlsym(m_dllHandle,"LaneCtrl_GetTime");
	if(LaneCtrlDll_GetTime == NULL)
	{
		printf("get *LaneCtrl_GetTime* address failed\r\n");
		result = -1;
	}
	LaneCtrlDll_SetTime = (lfLaneCtrl_SetTime)dlsym(m_dllHandle,"LaneCtrl_SetTime");
	if(LaneCtrlDll_SetTime == NULL)
	{
		printf("get *LaneCtrl_SetTime* address failed\r\n");
		result = -1;
	}
	LaneCtrlDll_GetCarInfo = (lfLaneCtrl_GetCarInfo)dlsym(m_dllHandle,"LaneCtrl_GetCarInfo");
	if(LaneCtrlDll_GetCarInfo == NULL)
	{
		printf("get *LaneCtrl_GetCarInfo* address failed\r\n");
		result = -1;
	}
	LaneCtrlDll_Unlock = (lfLaneCtrl_Unlock)dlsym(m_dllHandle,"LaneCtrl_Unlock");
	if(LaneCtrlDll_Unlock == NULL)
	{
		printf("get *LaneCtrl_Unlock* address failed\r\n");
		result = -1;
	}
	LaneCtrlDll_RegLogCallback = (lfLaneCtrl_RegLogCallback)dlsym(m_dllHandle,"LaneCtrl_RegLogCallback");
	if(LaneCtrlDll_RegLogCallback == NULL)
	{
		printf("get *LaneCtrl_RegLogCallback* address failed\r\n");
		result = -1;
	}

	if(result != 0)
	{
		//free so handle
		LaneCtrlClientDll_Free();
		return -1;
	}
	printf("LaneCtrlClientDll_Init: init dll success\n");
	return result;
}

//函数功能：动态库释放
void LaneCtrlClientDll_Free()
{
	if(m_dllHandle != NULL)
	{
		dlclose(m_dllHandle);
		m_dllHandle = NULL;
	}
}




