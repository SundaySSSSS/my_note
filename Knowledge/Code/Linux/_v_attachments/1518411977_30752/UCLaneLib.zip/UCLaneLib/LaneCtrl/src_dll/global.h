#ifndef _LANE_CTRL_H_
#define _LANE_CTRL_H_

#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <assert.h>
#include <time.h>
#include <sys/time.h>
#include <stdlib.h>
#include <pthread.h>
#include <stdarg.h>
#include <iostream>
#include <vector>
#include <map>
#include <queue>
#include <string>
#include "nanomsg/nn.h"
#include "nanomsg/reqrep.h"
#include "nanomsg/survey.h"

using namespace std;

// 版本号, 正常情况下, 版本号在Makefile文件中写定
#ifndef VERSION
#define VERSION "1.0.0"
#endif

#define DEFAULT_PORT (9899)
// 接收不到消息几秒后退出
#define RECV_TIME_OUT (5)

extern int g_isLogOpen;

#define dbout(arg...) do { Utils::writeLog("<%s-%d> : ", __FUNCTION__, __LINE__); Utils::writeLog(arg);} while(0)

#endif /* _LANE_CTRL_H_ */
