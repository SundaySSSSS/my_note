#include "LaneCtrlServerDll.h"
#include "server/server.h"

LaneCtrlServer g_server;

int LaneCtrlServer_Start(void)
{
	return g_server.Start();
}

int LaneCtrlServer_Stop(void)
{
	return g_server.Stop();
}

void LaneCtrlServer_RegGetTimeCallback(int (*getTime_callback)(char* time))
{
	g_server.RegGetTimeCallback(getTime_callback);
}

void LaneCtrlServer_RegSetTimeCallback(int (*setTime_callback)(const char* time))
{
	g_server.RegSetTimeCallback(setTime_callback);
}

void LaneCtrlServer_RegGetCarInfoCallback(int (*getCarInfo_callback)(SUpCarInfo* carinfo))
{
	g_server.RegGetCarInfoCallback(getCarInfo_callback);
}

void LaneCtrlServer_RegUnlockCallback(int (*unlock_callback)(void))
{
	g_server.RegUnlockCallback(unlock_callback);
}
