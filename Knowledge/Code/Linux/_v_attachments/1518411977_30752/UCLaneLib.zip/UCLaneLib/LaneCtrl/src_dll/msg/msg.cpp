#include "msg.h"
#include "../global.h"
#include "../utils/utils.h"

Message::Message()
{
	;
}

Message::Message(const byte* buf, size_t size)
{
	m_UcMsg = UcMsg(buf, size);
}

Message::~Message()
{
	;
}

/* GET_TIME相关 */
void Message::CreateGetTimeRequest(void)
{
	m_UcMsg.append(MSG_TYPE_STR, MSG_TYPE_GET_TIME_STR);
}
int Message::ParseGetTimeRequest(void)
{
	int result = -1;
	string msg_type_val;
	if (m_UcMsg.parse(MSG_TYPE_STR) == MSG_TYPE_GET_TIME_STR)
		result = 0;
	return result;
}
void Message::CreateGetTimeReply(const string& timeStr)
{
	m_UcMsg.append(MSG_TYPE_STR, MSG_TYPE_GET_TIME_REPLY_STR);
	m_UcMsg.append(DATA_STR, timeStr);
}
int Message::ParseGetTimeReply(string& timeStr)
{
	int result = -1;

	if (m_UcMsg.parse(MSG_TYPE_STR) == MSG_TYPE_GET_TIME_REPLY_STR)
	{
		timeStr = m_UcMsg.parse(DATA_STR);
		if (timeStr != "")
			result = 0;
	}
	return result;
}

/* SET_TIME相关 */
void Message::CreateSetTimeRequest(const string& timeStr)
{
	m_UcMsg.append(MSG_TYPE_STR, MSG_TYPE_SET_TIME_STR);
	m_UcMsg.append(DATA_STR, timeStr);
}

int Message::ParseSetTimeRequest(string& timeStr)
{
	int result = -1;
	if (m_UcMsg.parse(MSG_TYPE_STR) == MSG_TYPE_SET_TIME_STR)
	{
		timeStr = m_UcMsg.parse(DATA_STR);
		if (timeStr != "")
			result = 0;
	}
	return result;
}

void Message::CreateSetTimeReply(bool isOK)
{
	string replyStr;

	m_UcMsg.append(MSG_TYPE_STR, MSG_TYPE_SET_TIME_REPLY_STR);
	if (isOK)
		replyStr = "OK";
	else
		replyStr = "NG";
	m_UcMsg.append(DATA_STR, replyStr);
}

int Message::ParseSetTimeReply(bool& isOK)
{
	int result = -1;
	string replyStr;

	if (MSG_TYPE_SET_TIME_REPLY_STR == m_UcMsg.parse(MSG_TYPE_STR))
	{
		replyStr = m_UcMsg.parse(DATA_STR);
		if (replyStr == string("OK"))
		{
			result = 0;
			isOK = true;
		}
		else if (replyStr == string("NG"))
		{
			result = 0;
			isOK = false;
		}
	}
	return result;
}

/* SET_LOCK相关 */
void Message::CreateSetLockRequest(int lockCmd)
{
	m_UcMsg.append(MSG_TYPE_STR, MSG_TYPE_SET_LOCK_STR);
	string lock_sts;
	if (lockCmd == 0)
		lock_sts = "UNLOCK";
	else
		lock_sts = "LOCK";
	m_UcMsg.append(DATA_STR, lock_sts);
}

int Message::ParseSetLockRequest(int& lockCmd)
{
	int result = -1;
	string replyStr;

	if (m_UcMsg.parse(MSG_TYPE_STR) == MSG_TYPE_SET_LOCK_STR)
	{
		replyStr = m_UcMsg.parse(DATA_STR);
		if (replyStr == string("UNLOCK"))
		{
			result = 0;
			lockCmd = 0;
		}
		else if (replyStr == string("LOCK"))
		{
			result = 0;
			lockCmd = 1;
		}
	}
	return result;
}
void Message::CreateSetLockReply(bool isOK)
{
	string replyStr;

	m_UcMsg.append(MSG_TYPE_STR, MSG_TYPE_SET_LOCK_REPLY_STR);

	if (isOK)
		replyStr = "OK";
	else
		replyStr = "NG";
	m_UcMsg.append(DATA_STR, replyStr);
}

int Message::ParseSetLockReply(bool& isOK)
{
	string replyStr;
	int result = -1;

	if (MSG_TYPE_SET_LOCK_REPLY_STR == m_UcMsg.parse(MSG_TYPE_STR))
	{
		replyStr = m_UcMsg.parse(DATA_STR);
		if (replyStr == string("OK"))
		{
			result = 0;
			isOK = true;
		}
		else if (replyStr == string("NG"))
		{
			result = 0;
			isOK = false;
		}
	}
	return result;
}

/* GET_CARINFO相关 */
void Message::CreateGetCarInfoRequest()
{
	m_UcMsg.append(MSG_TYPE_STR, MSG_TYPE_GET_CARINFO_STR);
}

int Message::ParseGetCarInfoRequest()
{
	int result = -1;

	if (MSG_TYPE_GET_CARINFO_STR == m_UcMsg.parse(MSG_TYPE_STR))
	{
		result = 0;
	}
	return result;
}

void Message::CreateGetCarInfoReply(const SUpCarInfo& carInfo)
{
	m_UcMsg.append(MSG_TYPE_STR, MSG_TYPE_GET_CARINFO_REPLY_STR);

	m_UcMsg.append(CARINFO_TYPE_STR, Utils::intToStr(carInfo.type));

	if (carInfo.type != CARINFO_TYPE_NOTHING)
	{
		m_UcMsg.append(ID_STR, Utils::intToStr(carInfo.ID));
		m_UcMsg.append(CARTYPE_INT_STR, Utils::intToStr(carInfo.carType_int));
		m_UcMsg.append(CARTYPE_STR, Utils::intToStr(carInfo.carType));
		m_UcMsg.append(CARTYPE_STR_STR, carInfo.carTypeStr);
		m_UcMsg.append(CARLENGTH_STR, Utils::intToStr(carInfo.carLength));
		m_UcMsg.append(CARHEIGHT_STR, Utils::intToStr(carInfo.carHeight));
		m_UcMsg.append(AXLE_TYPE_STR, carInfo.szAxleType);
		m_UcMsg.append(PLATE_NUMP_STR, carInfo.plateNump);
		m_UcMsg.append(PLATE_COLOR_STR, carInfo.plateColor);
		dbout("imgSize = %d\n", carInfo.imgSize);
		m_UcMsg.append(IMG_SIZE_STR, Utils::intToStr(carInfo.imgSize));
		m_UcMsg.append(UP_DOWN_FLAG_STR, Utils::intToStr(int(carInfo.carTypeUpDownFlag)));
		m_UcMsg.append(LKYW_STR, Utils::intToStr(int(carInfo.nLKYW)));
		//图片
		if (carInfo.imgSize > 0)
		{
			m_UcMsg.append(IMG_DATA_STR, (const byte*)carInfo.bigImgData, carInfo.imgSize);
		}
	}
}

int Message::ParseGetCarInfoReply(SUpCarInfo& carInfo)
{
	int result = -1;

	if (MSG_TYPE_GET_CARINFO_REPLY_STR == m_UcMsg.parse(MSG_TYPE_STR))
	{
		//只有有车型信息时才有如下字段
		carInfo.type = atoi(m_UcMsg.parse(CARINFO_TYPE_STR).c_str());
		if (carInfo.type != CARINFO_TYPE_NOTHING)
		{
			carInfo.ID = atoi(m_UcMsg.parse(ID_STR).c_str());
			carInfo.carType_int = atoi(m_UcMsg.parse(CARTYPE_INT_STR).c_str());
			carInfo.carType = atoi(m_UcMsg.parse(CARTYPE_STR).c_str());
			strncpy(carInfo.carTypeStr, m_UcMsg.parse(CARTYPE_STR_STR).c_str(), sizeof(carInfo.carTypeStr));
			carInfo.carLength = atoi(m_UcMsg.parse(CARLENGTH_STR).c_str());
			carInfo.carHeight = atoi(m_UcMsg.parse(CARHEIGHT_STR).c_str());
			strncpy(carInfo.szAxleType, m_UcMsg.parse(AXLE_TYPE_STR).c_str(), sizeof(carInfo.szAxleType));
			strncpy(carInfo.plateNump, m_UcMsg.parse(PLATE_NUMP_STR).c_str(), sizeof(carInfo.plateNump));
			strncpy(carInfo.plateColor, m_UcMsg.parse(PLATE_COLOR_STR).c_str(), sizeof(carInfo.plateColor));
			carInfo.imgSize = atoi(m_UcMsg.parse(IMG_SIZE_STR).c_str());
			carInfo.carTypeUpDownFlag = atoi(m_UcMsg.parse(UP_DOWN_FLAG_STR).c_str());
			carInfo.nLKYW = atoi(m_UcMsg.parse(LKYW_STR).c_str());
			//图片
			size_t maxImgSize = sizeof(carInfo.bigImgData);
			if (carInfo.imgSize > 0)
			{
				int pic_ret = m_UcMsg.parse(IMG_DATA_STR, (byte*)carInfo.bigImgData, maxImgSize);
				dbout("parse pic ret = %d, imgSize = %d\n", pic_ret, maxImgSize);
			}
		}
		result = 0;
	}
	return result;
}

