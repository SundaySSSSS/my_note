#ifndef	_LOAD_CLIENT_DLL_H_
#define	_LOAD_CLIENT_DLL_H_

#include <stdlib.h>
#include "../interface/interface.h"

typedef int (*lfLaneCtrl_Connect) (const char * deviceIP, int deviceType);
typedef int (*lfLaneCtrl_DisConnect) (int devId);
typedef int (*lfLaneCtrl_GetVersion)(int devId,char * ver);
typedef int (*lfLaneCtrl_GetTime)(int devId,char * time);
typedef int (*lfLaneCtrl_SetTime)(int devId,const char * time);
typedef int (*lfLaneCtrl_GetCarInfo)(int devId, SUpCarInfo * carInfo);
typedef int (*lfLaneCtrl_Unlock)(int devId);
typedef void (*lfLaneCtrl_RegLogCallback)(void (*printLogCallback)(const char* log));
////////////////////////////////////////////////////////////////////
//函数功能：	动态库加载
//DllPath	动态库所在路径，结束不要有“\”
//返回值：	0成功，1加载动态库失败，2在动态库中找函数失败
int	LaneCtrlClientDll_Init(const char *DllPath);

//函数功能：	动态库释放
void LaneCtrlClientDll_Free();

/********************************数据同步节点接口*****************************************/
extern lfLaneCtrl_Connect			LaneCtrlDll_Connect;
extern lfLaneCtrl_DisConnect		LaneCtrlDll_DisConnect;
extern lfLaneCtrl_GetVersion		LaneCtrlDll_GetVersion;
extern lfLaneCtrl_GetTime			LaneCtrlDll_GetTime;
extern lfLaneCtrl_SetTime			LaneCtrlDll_SetTime;
extern lfLaneCtrl_GetCarInfo		LaneCtrlDll_GetCarInfo;
extern lfLaneCtrl_Unlock			LaneCtrlDll_Unlock;
extern lfLaneCtrl_RegLogCallback    LaneCtrlDll_RegLogCallback;
#endif	/* _LOAD_CLIENT_DLL_H_ */
