#include <iostream>
#include <stdio.h>
#include <string>
#include <string.h>
#include <sys/time.h>
#include <unistd.h>
#include "load_server_dll.h"
#include "gb2312_str.h"
using namespace std;

//从硬盘上读取一张图片放入buffer中
void readPic(int count, char* buf, size_t* pSize)
{
	char file_path[128] = {0};

	if (buf == NULL || pSize == NULL)
	{
		printf("readPic: input param error\n");
		return;
	}

	snprintf(file_path, sizeof(file_path), "../pic/%d.bmp", count);
	FILE* fp = fopen(file_path, "rb");
	if (fp != NULL)
	{
		fseek(fp, 0, SEEK_END);
		size_t fileSize = ftell(fp);
		rewind(fp);
		int read_len = fread(buf, 1, fileSize, fp);
		printf("read_len = %d, fileSize = %d\n", read_len, fileSize);
		*pSize = read_len;
		fclose(fp);
	}
	else
		printf("readPic: read pic %s error\n", file_path);
}

//将时间字符串转化为UTC时间(时间字符串格式为"2017-09-10 10:00:00")
//返回值: -1-失败, >0-utc时间
time_t timeStr2Utc(const char* time_str)
{
	char year_str[5] = {0};
	char mon_str[3] = {0};
	char day_str[3] = {0};
	char hour_str[3] = {0};
	char min_str[3] = {0};
	char sec_str[3] = {0};

	if (strlen(time_str) != 19)
	{
		cout << "time_str len error: " << strlen(time_str) << endl;
		return -1;
	}
	int offset = 0;
	memcpy(year_str, &(time_str[offset]), 4);
	offset += 5;
	memcpy(mon_str, &(time_str[offset]), 2);
	offset += 3;
	memcpy(day_str, &(time_str[offset]), 2);
	offset += 3;
	memcpy(hour_str, &(time_str[offset]), 2);
	offset += 3;
	memcpy(min_str, &(time_str[offset]), 2);
	offset += 3;
	memcpy(sec_str, &(time_str[offset]), 2);

	struct tm time_tm = {0};
	time_tm.tm_year = atoi(year_str) - 1900;
	time_tm.tm_mon = atoi(mon_str) - 1;
	time_tm.tm_mday = atoi(day_str);
	time_tm.tm_hour = atoi(hour_str);
	//cout << time_tm.tm_hour << endl;
	time_tm.tm_min = atoi(min_str);
	time_tm.tm_sec = atoi(sec_str);
	time_tm.tm_isdst = 0;	//忽略夏令时
	time_t ret = mktime(&time_tm);
	if (ret == -1)
	{
		cout << "mktime return -1" << endl;
	}
	return ret;
}

int utc2TimeStr(time_t time, char* time_str)
{
	if (time_str == NULL)
		return -1;
	struct tm* time_tm = localtime(&time);//gmtime(&time);
	if (time_tm == NULL)
	{
		return -1;
	}
	sprintf(time_str, "%04d-%02d-%02d %02d:%02d:%02d", time_tm->tm_year + 1900,
			time_tm->tm_mon + 1, time_tm->tm_mday,
			time_tm->tm_hour, time_tm->tm_min, time_tm->tm_sec);
	return 0;
}

//设置时间
int Timer_Set(time_t timex)
{
	int ret=-1;
	struct timeval tv;
	struct timezone tz;
	struct tm * p;
	tv.tv_sec = timex;  //totil sec
	tv.tv_usec   =   0;
	tz.tz_minuteswest = -480; //和GreenWich差了多少分钟 北京时间 8小时*60=480分钟
	tz.tz_dsttime = 0;        //日光时间节约状态
	settimeofday(&tv,&tz);	  //设置系统时间

	return 0;
}

//获取时间
time_t Timer_Get(void)
{
	time_t cur_time = time(NULL);
	return cur_time;
}


int getTime_callback(char* time_str)
{
	time_t current_time = Timer_Get();
	return utc2TimeStr(current_time, time_str);
}
int setTime_callback(const char* time_str)
{
	time_t set_time = timeStr2Utc(time_str);
	return Timer_Set(set_time);
}
int getCarInfo_callback(SUpCarInfo* carinfo)
{
	static int count = 0;
	if (carinfo == NULL)
	{
		return -1;
	}
	carinfo->ID = count;
	carinfo->type = CARINFO_TYPE_NORMAL;
	snprintf(carinfo->plateNump, sizeof(carinfo->plateNump), "%sA%04d", plate_head_gb2312, count);

	size_t imgSize = sizeof(carinfo->bigImgData);
	readPic(count % 5, carinfo->bigImgData, &imgSize);
	carinfo->imgSize = imgSize;

	count++;
	return 0;
}
int unlock_callback(void)
{
	cout << "unlock_callback called" << endl;
	return 0;
}

void logCallback(const char* log)
{
	printf("%s", log);
}

int main(int argc, char** argv)
{
	if (LaneCtrlServerDll_Init(".") != 0)
	{
		cout << "Init Dll Error" << endl;
		return 1;
	}

	if (argc >= 2)
	{
		if (argv[1] == string("--help"))
		{
			cout << "Usage: ./client_server" << endl;
			return 0;
		}
	}

	//注册回调函数
	LaneCtrlServerDll_RegGetTimeCallback(getTime_callback);
	LaneCtrlServerDll_RegSetTimeCallback(setTime_callback);
	LaneCtrlServerDll_RegGetCarInfoCallback(getCarInfo_callback);
	LaneCtrlServerDll_RegUnlockCallback(unlock_callback);

	LaneCtrlDll_RegLogCallback(logCallback);

	if (LaneCtrlServerDll_Start() != 0)
	{
		cout << "Server Start Failed" << endl;
		return 1;
	}
	/* 测试时间转换函数 */
	//time_t current_time = time(NULL);
	//char current_time_str[32] = {0};
	//utc2TimeStr(current_time, current_time_str);
	//cout << current_time_str << endl;

	//time_t temp_time = timeStr2Utc("1990-05-19 14:15:16");
	//char temp_time_str[32] = {0};
	//utc2TimeStr(temp_time, temp_time_str);
	//cout << temp_time_str << endl;

	while(1)
		sleep(1);

	LaneCtrlServerDll_Stop();
	LaneCtrlServerDll_Free();

	return 0;
}
