#include <iostream>
#include <string>
#include <vector>
#include "load_client_dll.h"
#include "stdio.h"
using namespace std;

void savePic(int count, char* buf, size_t size)
{
	char imgPath[64] = {0};
	snprintf(imgPath, sizeof(imgPath), "%d.bmp", count);

	FILE* fp = fopen(imgPath, "wb");
	if (fp != NULL)
	{
		fwrite(buf, size, 1, fp);
		fclose(fp);
	}
	else
	{
		printf("savePic: open file error\n");
	}
}

void logCallback(const char* log)
{
	printf("%s", log);
}

void processGetCarInfo(int devId)
{
	SUpCarInfo carInfo = {0};
	int type = -1;
	int ret = LaneCtrlDll_GetCarInfo(devId, &carInfo);
	cout << "get carinfo ret = " << ret << endl;
	if (ret == 0)
	{
		cout << "carinfo.type = " << carInfo.type << endl;
		cout << "carinfo.id = " << carInfo.ID << endl;
		cout << "imgSize = " << carInfo.imgSize << endl;
		cout << "plate: " << carInfo.plateNump << endl;
		cout << "carType = " << carInfo.carType << endl;
		if (carInfo.imgSize > 0)
			savePic(carInfo.ID, carInfo.bigImgData, carInfo.imgSize);
	}
	else if (ret == 1)
	{
		cout << "no carinfo now" << endl;
	}
	else
	{
		cout << "get carinfo error" << endl;
	}
}

void procesGetTime(int devId)
{
	char get_time[64] = {0};
	int ret = LaneCtrlDll_GetTime(devId, get_time);
	cout << "get time ret = " << ret << endl;
	cout << "device time : " << get_time << endl;
}

int main(int argc, char** argv)
{
	if (LaneCtrlClientDll_Init(".") != 0)
	{
		cout << "Init Dll Error" << endl;
		return 1;
	}

	if (argc < 2)
	{
		cout << "input param error" << endl;
		cout << "use --help for help" << endl;
		return 1;
	}
	if (argv[1] == string("--help"))
	{
		cout << "Usage: ./client_demo server_ip" << endl;
		cout << "e.g.: ./client_demo 172.16.4.77" << endl;
		return 0;
	}

	//遍历参数, 将所有要链接的ip存入vector
	vector<string> serverIPList;
	int i = 1;
	for ( ; i < argc; ++i)
	{
		serverIPList.push_back(argv[i]);
	}

	//连接所有服务器
	vector<int> serverDevIDList;
	for (vector<string>::iterator iter = serverIPList.begin(); iter != serverIPList.end(); iter++)
	{
		string ip = (*iter);
		int devId = LaneCtrlDll_Connect(ip.c_str(), 0);
		if (devId < 0)
		{
			cout << "Connect " << ip << " error" << endl;
			return -1;
		}
		serverDevIDList.push_back(devId);
	}
	LaneCtrlDll_RegLogCallback(logCallback);

	string cmd;
	while(1)
	{
		cout << "#########please input command" << endl;
		cin >> cmd;
		if (cmd == "ver")
		{
			char version[64] = {0};
			for (vector<int>::iterator iter = serverDevIDList.begin(); iter != serverDevIDList.end(); iter++)
			{
				int devId = *iter;
				int ret = LaneCtrlDll_GetVersion(devId, version);
				cout << "get version: " << version << endl;
			}
		}
		else if (cmd == "settime")
		{
			cout << "input time (time format: yyyy-mm-dd hh:mm:ss)" << endl;
			string set_date;
			cin >> set_date;
			string set_time;
			cin >> set_time;
			string temp = set_date + " " + set_time;

			for (vector<int>::iterator iter = serverDevIDList.begin(); iter != serverDevIDList.end(); iter++)
			{
				int devId = *iter;
				int ret = LaneCtrlDll_SetTime(devId, temp.c_str());
				cout << "set time ret = " << ret << endl;
			}
		}
		else if (cmd == "gettime")
		{
			for (vector<int>::iterator iter = serverDevIDList.begin(); iter != serverDevIDList.end(); iter++)
			{
				int devId = *iter;
				procesGetTime(devId);
			}
		}
		else if (cmd == "carinfo")
		{
			for (vector<int>::iterator iter = serverDevIDList.begin(); iter != serverDevIDList.end(); iter++)
			{
				int devId = *iter;
				processGetCarInfo(devId);
			}
		}
		else if (cmd == "unlock")
		{
			for (vector<int>::iterator iter = serverDevIDList.begin(); iter != serverDevIDList.end(); iter++)
			{
				int devId = *iter;
				int ret = LaneCtrlDll_Unlock(devId);
				cout << "unlock ret = " << ret << endl;
			}
		}
		else if (cmd == "auto")
		{
			while (1)
			{
				for (vector<int>::iterator iter = serverDevIDList.begin(); iter != serverDevIDList.end(); iter++)
				{
					int devId = *iter;
					processGetCarInfo(devId);
					sleep(1);
					procesGetTime(devId);
					sleep(1);
				}
			}
		}
		else if (cmd == "exit")
		{
			cout << "Bye" << endl;
			break;
		}
		else
		{
			cout << "Unknown command" << endl;
		}
	}

	for (vector<int>::iterator iter = serverDevIDList.begin(); iter != serverDevIDList.end(); iter++)
	{
		int devId = *iter;
		LaneCtrlDll_DisConnect(devId);
	}
	LaneCtrlClientDll_Free();

	return 0;
}
