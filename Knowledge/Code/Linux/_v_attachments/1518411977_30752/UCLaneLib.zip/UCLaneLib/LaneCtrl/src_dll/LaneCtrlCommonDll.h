/**********************************
 * 车道动态库通用接口
 *********************************/
#ifndef _LANE_CTRL_COMMON_DLL_H_
#define _LANE_CTRL_COMMON_DLL_H_

#ifdef __cplusplus
extern "C" {
#endif

/*
 * 功能: 注册日志回调函数, 如果不注册, 则动态库不会写日志
 * 参数:
 * void (*printLogCallback)(const char* log) : 注册的回调函数
 * 返回值: 无
 * */
void LaneCtrl_RegLogCallback(void (*printLogCallback)(const char* log));

#ifdef __cplusplus
}
#endif

#endif /* _LANE_CTRL_COMMON_DLL_H_ */
