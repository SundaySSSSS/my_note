/**********************************
 * 车道客户端动态库
 *********************************/
#ifndef _LANE_CTRL_CLIENT_DLL_H_
#define _LANE_CTRL_CLIENT_DLL_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "../interface/interface.h"

/*
 * 功能: 连接车道服务器
 * 参数:
 * const char * deviceIP: [in]设备ip, 必须为"127.0.0.1"格式, 结尾必须有\0
 * int deviceType: [in]设备类型（1-车道控制器 2-鹰眼） 目前忽略此参数
 * 返回值: >=0:连接成功,具体数值表示对应设备连接号 其他-失败
 * */
int LaneCtrl_Connect(const char * deviceIP, int deviceType);
/*
 * 功能: 断开车道服务器
 * 参数:
 * int devId: [in]设备id, 应该输入LanCtrl_Connect的返回值
 * 返回值: 0-成功 其他-失败
 * */
int LaneCtrl_DisConnect(int devId);
/*
 * 功能: 获取动态库版本号
 * 参数:
 * int devId: [in]设备id, 应该输入LanCtrl_Connect的返回值
 * char * ver: [out]版本号, 要保证64个byte以上
 * 返回值: 0-成功 其他-失败
 * */
int LaneCtrl_GetVersion(int devId,char * ver);
/*
 * 功能: 获取服务器时间
 * 参数:
 * int devId: [in]设备id, 应该输入LanCtrl_Connect的返回值
 * char * time: [out]服务器时间字符串, 格式为"2017-09-10 10:00:00", 要保证能够存下此字符串
 * 返回值: 0-成功 其他-失败
 * */
int LaneCtrl_GetTime(int devId,char * time);
/*
 * 功能: 设置服务器时间
 * 参数:
 * int devId: [in]设备id, 应该输入LanCtrl_Connect的返回值
 * char * time: [in]要设置的服务器时间字符串, 格式为"2017-09-10 10:00:00"
 * 返回值: 0-成功 其他-失败
 * */
int LaneCtrl_SetTime(int devId,const char * time);
/*
 * 功能: 获取服务器过车信息
 * 参数:
 * int devId: [in]设备id, 应该输入LanCtrl_Connect的返回值
 * SUpCarInfo * carInfo: [out]车辆信息, 仅在返回值为0时有效
 * 返回值: 0-成功 1-当前没有车型信息, 其他-失败
 * */
int LaneCtrl_GetCarInfo(int devId, SUpCarInfo * carInfo);
/*
 * 功能: 对服务器解锁
 * 参数:
 * int devId: [in]设备id, 应该输入LanCtrl_Connect的返回值
 * 返回值: 0-成功 其他-失败
 * */
int LaneCtrl_Unlock(int devId);

#ifdef __cplusplus
}
#endif

#endif /* _LANE_CTRL_CLIENT_DLL_H_ */
