/**********************************
 * 车道客户端动态库
 *********************************/
#ifndef _LANE_CTRL_SERVER_DLL_H_
#define _LANE_CTRL_SERVER_DLL_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "../interface/interface.h"

/*
 * 功能: 启动车道动态库服务器
 * 参数: 无
 * 返回值: 0-成功 其他-失败
 * */
int LaneCtrlServer_Start(void);

/*
 * 功能: 关闭车道动态库服务器
 * 参数: 无
 * 返回值: 0-成功 其他-失败
 * */
int LaneCtrlServer_Stop(void);

/*
 * 功能: 注册获取时间回调
 * 参数: int (*getTime_callback)(char* time): 回调函数, 在客户端需要获得服务器时间时回调
 * 		char* time: 将时间写入此指针内, 格式为"2017-09-10 10:00:00"
 * 		回调返回值: 0-成功 其他-失败
 * */
void LaneCtrlServer_RegGetTimeCallback(int (*getTime_callback)(char* time));

/*
 * 功能: 注册设置时间回调
 * 参数: int (*setTime_callback)(const char* time): 回调函数, 在客户端需要设置服务器时间时回调
 * 		const char* time: 要设置的时间, 格式为"2017-09-10 10:00:00"
 * 		回调返回值: 0-成功 其他-失败
 * */
void LaneCtrlServer_RegSetTimeCallback(int (*setTime_callback)(const char* time));

/*
 * 功能: 注册设置时间回调
 * 参数: int (*getCarInfo_callback)(SUpCarInfo* carinfo): 回调函数, 在客户端需要获取车型时回调
 * 		SUpCarInfo* carinfo: 将当前车型写入此指针内
 * 		回调返回值: 0-成功 其他-失败
 * */
void LaneCtrlServer_RegGetCarInfoCallback(int (*getCarInfo_callback)(SUpCarInfo* carinfo));
/*
 * 功能: 解锁回调
 * 参数: int (*unlock_callback)(void): 回调函数, 在客户端解锁时回调
 * 		回调返回值: 0-成功 其他-失败
 * */
void LaneCtrlServer_RegUnlockCallback(int (*unlock_callback)(void));

#ifdef __cplusplus
}
#endif

#endif /* _LANE_CTRL_SERVER_DLL_H_ */
