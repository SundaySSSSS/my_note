#include "server_comm.h"
#include "server.h"
#include "../utils/utils.h"
#include "../msg/msg.h"

void* do_comm_server(void* pthis)
{
	LaneCtrlServer* self = (LaneCtrlServer*) pthis;
	int sock = self->m_sock;

	while (self->m_run_flag)
	{
		Message msg_recv;
		Message msg_send;
		if (Utils::Msg_Recv(sock, msg_recv, MSG_RECV_FOREVER_WAIT) != 0)
		{
			dbout("recv failed\n");
			continue;
		}

		/* 解析收到的数据 */
		string msg_type = msg_recv.GetType();
		dbout("msg_type = %s\n", msg_type.c_str());
		if (msg_type == MSG_TYPE_UNINIT_STR || msg_type == MSG_TYPE_UNKNOWN_STR)
		{
			dbout("recv invalid msg\n");
		}
		else if (msg_type == MSG_TYPE_GET_TIME_STR)
		{
			if (msg_recv.ParseGetTimeRequest() == 0)
			{
				char current_time[64] = {0};
				int ret = self->m_getTime_callback(current_time);
				if (ret != 0)
				{
					dbout("m_getTime_callback return error, %d\n", ret);
				}
				else
					msg_send.CreateGetTimeReply(current_time);
			}
			else
				dbout("parse get time request error\n");
		}
		else if (msg_type == MSG_TYPE_SET_TIME_STR)
		{
			string timeStr;
			if (msg_recv.ParseSetTimeRequest(timeStr) == 0)
			{
				dbout("set time %s\n", timeStr.c_str());
				if (self->m_setTime_callback(timeStr.c_str()) == 0)
				{
					msg_send.CreateSetTimeReply(true);
				}
				else
				{
					dbout("set time error\n");
					msg_send.CreateSetTimeReply(false);
				}
			}
			else
				dbout("parse set time request error\n");
		}
		else if (msg_type == MSG_TYPE_SET_LOCK_STR)
		{
			int lockCmd = 0;
			if (msg_recv.ParseSetLockRequest(lockCmd) == 0)
			{
				//这里暂不区分解锁还是锁定, 都当作解锁
				if (lockCmd == 0)
				{
					dbout("UnLock!!!\n");
				}
				else
				{
					dbout("Lock!!!\n");
				}
				if (self->m_unlock_callback() == 0)
				{
					dbout("unlock callback ok\n");
					msg_send.CreateSetLockReply(true);
				}
				else
				{
					dbout("unlock callback ng\n");
					msg_send.CreateSetLockReply(false);
				}
			}
			else
				dbout("parse set lock request error\n");
		}
		else if (msg_type == MSG_TYPE_GET_CARINFO_STR)
		{
			if (msg_recv.ParseGetCarInfoRequest() == 0)
			{
				SUpCarInfo carInfo = {0};
				int callback_ret = self->m_getCarInfo_callback(&carInfo);
				if (callback_ret != 0)
				{
					dbout("m_getCarInfo_callback return error: %d\n", callback_ret);
				}
				msg_send.CreateGetCarInfoReply(carInfo);
			}
			else
				dbout("parse get carInfo request error\n");
		}
		/* 回复数据 */
		if (Utils::Msg_Send(sock, msg_send) != 0)
		{
			dbout("reply failed\n");
		}
	}

	return (void*)0;
}
