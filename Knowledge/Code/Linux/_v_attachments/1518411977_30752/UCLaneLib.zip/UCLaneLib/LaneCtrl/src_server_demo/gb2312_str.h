#ifndef _GB2312_STR_H_
#define _GB2312_STR_H_

const char* plate_head_gb2312 = "��";

#endif /* _GB2312_STR_H_ */
