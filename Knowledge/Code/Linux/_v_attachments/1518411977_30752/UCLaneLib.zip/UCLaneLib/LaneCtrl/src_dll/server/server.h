#ifndef _LANE_CTRL_CENTER_H_
#define _LANE_CTRL_CENTER_H_

#include "../global.h"
#include "server_comm.h"
#include "../../interface/interface.h"

class LaneCtrlServer
{
private:
	/* 端口 */
	int m_port;

	/* socket */
	int m_sock;

	int CreateSocket(void);	//创建socket
	int StartComm(void);	//开始进行通信

	/* 线程句柄 */
	pthread_t m_comm_handle;

	/* 通信处理函数 */
	friend void* do_comm_server(void* pthis);

	/* 回调函数 */
	int (*m_getTime_callback)(char* time);
	int (*m_setTime_callback)(const char* time);
	int (*m_getCarInfo_callback)(SUpCarInfo* carinfo);	//返回值: 0-成功 其他-失败
	int (*m_unlock_callback)(void);

	int m_run_flag;	//运行标记

public:
	LaneCtrlServer();
	~LaneCtrlServer();
	void SetPort(int port) { m_port = port; };
	void RegGetTimeCallback(int (*getTime_callback)(char* time))
	{
		m_getTime_callback = getTime_callback;
	}

	void RegSetTimeCallback(int (*setTime_callback)(const char* time))
	{
		m_setTime_callback = setTime_callback;
	}

	void RegGetCarInfoCallback(int (*getCarInfo_callback)(SUpCarInfo* carinfo))
	{
		m_getCarInfo_callback = getCarInfo_callback;
	}

	void RegUnlockCallback(int (*unlock_callback)(void))
	{
		m_unlock_callback = unlock_callback;
	}

	//启动连接
	int Start();
	//停止服务
	int Stop();
};


#endif /* _LANE_CTRL_CENTER_H_ */

