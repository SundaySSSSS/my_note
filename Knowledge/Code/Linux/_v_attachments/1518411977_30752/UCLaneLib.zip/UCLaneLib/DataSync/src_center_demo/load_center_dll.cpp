#include <stdlib.h>
#include <dlfcn.h>
#include <string.h>
#include <stdio.h>
#include "load_center_dll.h"


//动态库函数定义

/********************************数据同步接口*****************************************/
lfDataSyncCenter_GetVersion						DataSyncCenterDll_GetVersion;
lfDataSyncCenter_SetPort						DataSyncCenterDll_SetPort;
lfDataSyncCenter_RegGetAllDataCallback			DataSyncCenterDll_RegGetAllDataCallback;
lfDataSyncCenter_RegGetFeatureCallback			DataSyncCenterDll_RegGetFeatureCallback;
lfDataSyncCenter_RegReceiveUploadDataCallback	DataSyncCenterDll_RegReceiveUploadDataCallback;
lfDataSyncCenter_SendMsg_AdjustDataCmd			DataSyncCenterDll_SendMsg_AdjustDataCmd;
lfDataSyncCenter_Sync							DataSyncCenterDll_Sync;
lfDataSyncCenter_Start							DataSyncCenterDll_Start;
lfDataSync_RegLogCallback                       DataSyncDll_RegLogCallback;


#define DLL_FILENAME "libdatasync.so"

//本文件全局变量
//动态库句柄
static void	*m_dllHandle = NULL;

//函数功能：	ndk.dll动态库加载
//DllPath	ndk.dll所在路径，结束不要有“\”
//返回值：	0-成功，其他-失败
int	DataSyncCenterDll_Init(const char *DllPath)
{
	int	result = 0;
	char	FileName[256];
	char	*errorInfo;
	if(DllPath == NULL)
	{
		m_dllHandle = dlopen(DLL_FILENAME, RTLD_LAZY);
	}
	else
	{
		sprintf(FileName,"%s/%s",DllPath, DLL_FILENAME);
		m_dllHandle = dlopen(FileName, RTLD_LAZY);
	}
	if(m_dllHandle == NULL)
	{
		errorInfo = dlerror();
		printf("error info = %s\n",errorInfo);
		return 0;
	}

	/********************************数据同步接口*****************************************/
	DataSyncCenterDll_GetVersion = (lfDataSyncCenter_GetVersion)dlsym(m_dllHandle,"DataSyncCenter_GetVersion");
	if(DataSyncCenterDll_GetVersion == NULL)
	{
		printf("get *DataSyncCenter_GetVersion* address failed\n");
		result = -1;
	}
	DataSyncCenterDll_SetPort = (lfDataSyncCenter_SetPort)dlsym(m_dllHandle,"DataSyncCenter_SetPort");
	if(DataSyncCenterDll_SetPort == NULL)
	{
		printf("get *DataSyncCenter_SetPort* address failed\r\n");
		result = -1;
	}
	DataSyncCenterDll_RegGetAllDataCallback = (lfDataSyncCenter_RegGetAllDataCallback)dlsym(m_dllHandle,"DataSyncCenter_RegGetAllDataCallback");
	if(DataSyncCenterDll_RegGetAllDataCallback == NULL)
	{
		printf("get *DataSyncCenter_RegGetAllDataCallback* address failed\r\n");
		result = -1;
	}
	DataSyncCenterDll_RegGetFeatureCallback = (lfDataSyncCenter_RegGetFeatureCallback)dlsym(m_dllHandle,"DataSyncCenter_RegGetFeatureCallback");
	if(DataSyncCenterDll_RegGetFeatureCallback == NULL)
	{
		printf("get *DataSyncCenter_RegGetFeatureCallback* address failed\r\n");
		result = -1;
	}
	DataSyncCenterDll_RegReceiveUploadDataCallback = (lfDataSyncCenter_RegReceiveUploadDataCallback)dlsym(m_dllHandle,"DataSyncCenter_RegReceiveUploadDataCallback");
	if(DataSyncCenterDll_RegReceiveUploadDataCallback == NULL)
	{
		printf("get *DataSyncCenter_RegReceiveUploadDataCallback* address failed\r\n");
		result = -1;
	}
	DataSyncCenterDll_SendMsg_AdjustDataCmd = (lfDataSyncCenter_SendMsg_AdjustDataCmd)dlsym(m_dllHandle,"DataSyncCenter_SendMsg_AdjustDataCmd");
	if(DataSyncCenterDll_SendMsg_AdjustDataCmd == NULL)
	{
		printf("get *DataSyncCenter_SendMsg_AdjustDataCmd* address failed\r\n");
		result = -1;
	}
	DataSyncCenterDll_Sync = (lfDataSyncCenter_Sync)dlsym(m_dllHandle,"DataSyncCenter_Sync");
	if(DataSyncCenterDll_Sync == NULL)
	{
		printf("get *DataSyncCenter_Sync* address failed\r\n");
		result = -1;
	}
	DataSyncCenterDll_Start = (lfDataSyncCenter_Start)dlsym(m_dllHandle,"DataSyncCenter_Start");
	if(DataSyncCenterDll_Start == NULL)
	{
		printf("get *DataSyncCenter_Start* address failed\r\n");
		result = -1;
	}
	DataSyncDll_RegLogCallback = (lfDataSync_RegLogCallback)dlsym(m_dllHandle,"DataSync_RegLogCallback");
	if(DataSyncDll_RegLogCallback == NULL)
	{
		printf("get *DataSync_RegLogCallback* address failed\r\n");
		result = -1;
	}

	if(result != 0)
	{
		//free so handle
		DataSyncCenterDll_Free();
		return -1;
	}
	printf("DataSyncCenterDll_Init: init dll success\n");
	return result;
}

//函数功能：动态库释放
void DataSyncCenterDll_Free()
{
	if(m_dllHandle != NULL)
	{
		dlclose(m_dllHandle);
		m_dllHandle = NULL;
	}
}




