#!/bin/bash

killall demo_node
killall demo_center

