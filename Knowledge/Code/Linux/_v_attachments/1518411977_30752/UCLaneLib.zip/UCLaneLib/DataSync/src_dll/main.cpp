#include "global.h"
#include "msg/msg.h"

int main(int argc, char** argv)
{
	Message msg;
	string temp;
	//msg.ThisToJson(temp);

	cout << temp << endl;

	Message msg2(temp);

	return 0;
}
