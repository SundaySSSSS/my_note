#include "data_mng.h"

int ParseProtocol(string msg, string flag, string& head, string& content)
{
	int ret = 0;
	size_t found = msg.find_first_of(flag.data());

	if (found != string::npos)
	{	//找到了协议标记
		string protocol_head = msg.substr(0, found);
		string protocol_content = msg.substr(found + 1);
		head = protocol_head;
		content = protocol_content;
	}
	else
	{
		printf("ParseProtocol: not find protocol flag\n");
		ret = -1;
	}

	return ret;
}

string PlateInfoToStr(const PlateInfo plateInfo)
{
	char str[128] = {0};
	sprintf(str, "%s:%d", plateInfo.plate, (int)(plateInfo.time));
	return string(str);
}

void StrToPlateInfo(string str, PlateInfo& plateInfo)
{
	string plate;
	string time;

	ParseProtocol(str, ":", plate, time);
	strcpy(plateInfo.plate, plate.c_str());
	plateInfo.time = atoi(time.c_str());
}

int GetAllDataFromVector(char* all_data, size_t* size, vector<PlateInfo>& v)
{
	string all_data_str;

	for (vector<PlateInfo>::iterator iter = v.begin(); iter != v.end(); iter++)
	{
		PlateInfo temp = (*iter);
		all_data_str += PlateInfoToStr(temp);
		all_data_str += "\n";
	}
	all_data_str += "\0";
	if (*size < all_data_str.size() + 1)
	{
		return -1;
	}
	else
	{
		strcpy(all_data, all_data_str.c_str());
		*size = all_data_str.size() + 1;
	}

	return 0;
}

