#ifndef _NODE_COMM_H_
#define _NODE_COMM_H_

#include "../global.h"

void* do_up_comm_node(void* pthis);
void* do_down_comm_node(void* pthis);
void* do_adjust_comm_node(void* pthis);
void* do_sync_comm_node(void* pthis);

#endif /* _NODE_COMM_H_ */
