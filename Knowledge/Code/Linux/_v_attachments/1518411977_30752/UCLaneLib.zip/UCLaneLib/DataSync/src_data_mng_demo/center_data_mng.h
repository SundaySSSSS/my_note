#ifndef _CENTER_DATA_MNG_H_
#define _CENTER_DATA_MNG_H_

#include "data_mng.h"

/* 回调函数 */
int center_get_all_data_callback(char* all_data, size_t* size);
int center_receive_upload_data_callback(const char* data, size_t size);
int center_get_feature_callback(char* feature, size_t* size);
int center_diff_all_data_callback(const char* data, size_t size);

/* 主动调用的函数 */
void CenterShowPlateInfo(void);
void CenterAddPlateInfo(PlateInfo plateInfo);
void CenterDelPlateInfo(PlateInfo plateInfo);

//在查找是否有数据超时, 仅返回第一个超时的数据
//参数:
//const vector<PlateInfo>& v: [in]待检查列表
//int over_time: [in]超时时间, 单位秒
//PlateInfo& overTimeData: [out]找到的超时车牌, 只有在返回值为1时有效
//返回值:
//	1-找到超时车牌, 0-没有找到超时车牌
int CheckOldData(const vector<PlateInfo>& v, int over_time, PlateInfo& overTimeData);

#endif /* _CENTER_DATA_MNG_H_ */
