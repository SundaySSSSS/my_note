#ifndef _DATA_SYNC_GB2312_STR_H_
#define _DATA_SYNC_GB2312_STR_H_

#define PLATE_HEAD "��A"

#endif /* _DATA_SYNC_GB2312_STR_H_ */
