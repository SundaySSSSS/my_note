#!/bin/bash
#this script must under same directory with "bin", and all the demo and dll has been compiled

#delete old log and create the log directory
rm -rf ./log
mkdir ./log

cd ./bin/x86

#start server demo
./demo_center > ../log/center_log.txt &

#start many node demos
./demo_node 172.16.4.77 172.16.4.78 8881 1 > ../../log/node_log_1.txt 2>&1 &
./demo_node 172.16.4.77 172.16.4.78 8882 2 > ../../log/node_log_2.txt 2>&1  &
./demo_node 172.16.4.77 172.16.4.78 8883 3 > ../../log/node_log_3.txt 2>&1  &
./demo_node 172.16.4.77 172.16.4.78 8884 4 > ../../log/node_log_4.txt 2>&1  &
./demo_node 172.16.4.77 172.16.4.78 8885 5 > ../../log/node_log_5.txt 2>&1  &
./demo_node 172.16.4.77 172.16.4.78 8886 6 > ../../log/node_log_6.txt 2>&1  &
./demo_node 172.16.4.77 172.16.4.78 8887 7 > ../../log/node_log_7.txt 2>&1  &
./demo_node 172.16.4.77 172.16.4.78 8888 8 > ../../log/node_log_8.txt 2>&1  &

