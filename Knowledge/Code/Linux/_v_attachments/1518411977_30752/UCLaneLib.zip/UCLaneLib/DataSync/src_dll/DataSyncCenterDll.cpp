#include "DataSyncCenterDll.h"

#include "global.h"
#include "center/center.h"

DataSyncCenter g_Center;

int DataSyncCenter_GetVersion(char* version_str)
{
	if (version_str == NULL)
		return -1;
	strcpy(version_str, VERSION);
	return 0;
}

void DataSyncCenter_SetPort(int port_up, int port_adjust, int port_sync)
{
	g_Center.SetPort(port_up, port_adjust, port_sync);
}

int DataSyncCenter_RegGetAllDataCallback(int (*get_all_data_callback)(char* all_data, size_t* size))
{
	g_Center.RegGetAllDataCallback(get_all_data_callback);
	return 0;
}

int DataSyncCenter_RegGetFeatureCallback(int (*get_all_feature_callback)(char* feature, size_t* size))
{
	return g_Center.RegGetFeatureCallback(get_all_feature_callback);
}

int DataSyncCenter_RegReceiveUploadDataCallback(int (*receive_upload_data_callback)(const char* data, size_t size))
{
	return g_Center.RegReceiveUploadDataCallback(receive_upload_data_callback);
}

int DataSyncCenter_SendMsg_AdjustDataCmd(const char* data, size_t size, int adjust_type)
{
	return g_Center.SendMsg_AdjustDataCmd(data, size, adjust_type);
}

int DataSyncCenter_Sync()
{
	return g_Center.Sync();
}

int DataSyncCenter_Start()
{
	return g_Center.Start();
}

