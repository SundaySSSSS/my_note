#ifndef _CENTER_COMM_H_
#define _CENTER_COMM_H_

#include "../global.h"

void* do_up_comm_center(void* pthis);
void* do_adjust_comm_center(void* pthis);

#endif /* _CENTER_COMM_H_ */
