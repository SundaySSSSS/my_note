#ifndef _NODE_DATA_MNG_H_
#define _NODE_DATA_MNG_H_

#include "data_mng.h"

/* 回调函数 */
int node_update_all_data_cmd_callback(const char*, size_t);
int node_adjust_data_callback(const char*, size_t, int);
int node_get_feature_callback(char* feature, size_t* size);
int node_get_all_data_callback(char* all_data, size_t* size);

/* 主动调用的函数 */
void NodeShowPlateInfo(void);
void NodeAddPlateInfo(PlateInfo plateInfo);

#endif /* _NODE_DATA_MNG_H_ */
