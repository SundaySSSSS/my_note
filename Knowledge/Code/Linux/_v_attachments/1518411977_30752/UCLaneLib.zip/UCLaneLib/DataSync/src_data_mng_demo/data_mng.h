#ifndef _DATA_MNG_H_
#define _DATA_MNG_H_

#include <string>
#include <vector>
#include <iostream>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

using namespace std;

//在这组数据管理中, 每一个车牌都是一个文本串, 具体如下:
//车牌号码#utc时间的整数值   例如: 	冀A12345#5643690
//如果有多条记录, 记录之间用\n间隔

typedef struct _PlateInfo
{
	char plate[20];
	time_t time;
}
PlateInfo;

int GetAllDataFromVector(char* all_data, size_t* size, vector<PlateInfo>& v);

string PlateInfoToStr(const PlateInfo plateInfo);

void StrToPlateInfo(string str, PlateInfo& plateInfo);

int ParseProtocol(string msg, string flag, string& head, string& content);

#endif /* _DATA_MNG_H_ */
