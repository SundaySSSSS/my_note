#include "DataSyncNodeDll.h"

#include "global.h"
#include "node/node.h"

DataSyncNode g_Node;

int DataSyncNode_GetVersion(char* version_str)
{
	if (version_str == NULL)
		return -1;
	strcpy(version_str, VERSION);
	return 0;
}

int DataSyncNode_SetIp(const char* ip_center, const char* ip_node)
{
	return g_Node.SetIp(ip_center, ip_node);
}

void DataSyncNode_SetPort(int port_up, int port_down, int port_adjust, int port_sync)
{
	g_Node.SetPort(port_up, port_down, port_adjust, port_sync);
}

int DataSyncNode_RegUpdateAllDataCmdCallback(int (*update_all_data_cmd_callback)(const char* data, size_t size))
{
	return g_Node.RegUpdateAllDataCmdCallback(update_all_data_cmd_callback);
}

int DataSyncNode_RegAdjustDataCallback(int (*adjust_data_callback)(const char* data, size_t size, int adjust_type))
{
	return g_Node.RegAdjustDataCallback(adjust_data_callback);
}

int DataSyncNode_RegGetFeatureCallback(int (*get_feature_callback)(char* feature, size_t* size))
{
	return g_Node.RegGetFeatureCallback(get_feature_callback);
}

int DataSyncNode_RegGetAllDataCallback(int (*get_all_data_callback)(char* all_data, size_t* size))
{
	return g_Node.RegGetAllDataCallback(get_all_data_callback);
}

int DataSyncNode_UploadData(const char* data, size_t size)
{
	return g_Node.UploadData(data, size);
}

int DataSyncNode_Start(void)
{
	return g_Node.Start();
}
