#include "msg.h"
#include "../utils/utils.h"
#include "../global.h"

void Message::CreateUploadRequest(const string& upload_data)
{
	m_UcMsg.append(MSG_TYPE_STR, MSG_TYPE_UPLOAD_STR);
	m_UcMsg.append(DATA_STR, upload_data);
}

int Message::ParseUploadRequest(string& upload_data)
{
	int result = -1;
	if (m_UcMsg.parse(MSG_TYPE_STR) == MSG_TYPE_UPLOAD_STR)
	{
		upload_data = m_UcMsg.parse(DATA_STR);
		if (upload_data != string(""))
			result = 0;
	}
	return result;
}

void Message::CreateUploadReply(bool isUploadOK)
{
	m_UcMsg.append(MSG_TYPE_STR, MSG_TYPE_UPLOAD_REPLY_STR);
	if (isUploadOK)
		m_UcMsg.append(RET_STR, OK_STR);
	else
		m_UcMsg.append(RET_STR, NG_STR);
}
int Message::ParseUploadReply(bool& isUploadOK)
{
	int result = -1;
	if (m_UcMsg.parse(MSG_TYPE_STR) == MSG_TYPE_UPLOAD_REPLY_STR)
	{
		string ret = m_UcMsg.parse(RET_STR);
		if (ret == OK_STR)
		{
			isUploadOK = true;
			result = 0;
		}
		else if (ret == NG_STR)
		{
			isUploadOK = false;
			result = 0;
		}
	}
	return result;
}

/* UP: Get All Data相关 */
void Message::CreateGetAllDataRequest()
{
	m_UcMsg.append(MSG_TYPE_STR, MSG_TYPE_GETALLDATA_STR);
}

int Message::ParseGetAllDataRequest()
{
	int result = -1;
	if (m_UcMsg.parse(MSG_TYPE_STR) == MSG_TYPE_GETALLDATA_STR)
	{
		result = 0;
	}
	return result;
}

void Message::CreateGetAllDataReply(bool isGetOK, const string& all_data)
{
	m_UcMsg.append(MSG_TYPE_STR, MSG_TYPE_GETALLDATA_REPLY_STR);
	if (isGetOK)
	{
		m_UcMsg.append(RET_STR, OK_STR);
		m_UcMsg.append(DATA_STR, all_data);
	}
	else
		m_UcMsg.append(RET_STR, NG_STR);
}
int Message::ParseGetAllDataReply(bool& isGetOK, string& all_data)
{
	int result = -1;
	if (m_UcMsg.parse(MSG_TYPE_STR) == MSG_TYPE_GETALLDATA_REPLY_STR)
	{
		string ret = m_UcMsg.parse(RET_STR);
		if (ret == OK_STR)
		{
			isGetOK = true;
			all_data = m_UcMsg.parse(DATA_STR);
			result = 0;
		}
		else if (ret == NG_STR)
		{
			isGetOK = false;
			result = 0;
		}
	}
	return result;
}

/* DOWN: Set All Data相关 */
void Message::CreateSetAllDataRequest(const string& all_data)
{
	m_UcMsg.append(MSG_TYPE_STR, MSG_TYPE_SETALLDATA_STR);
	m_UcMsg.append(DATA_STR, all_data);
	return;
}

int Message::ParseSetAllDataRequest(string& all_data)
{
	int result = -1;
	if (m_UcMsg.parse(MSG_TYPE_STR) == MSG_TYPE_SETALLDATA_STR)
	{
		all_data = m_UcMsg.parse(DATA_STR);
		result = 0;
	}
	return result;
}

void Message::CreateSetAllDataMsgReply(bool isSetOK)
{
	m_UcMsg.append(MSG_TYPE_STR, MSG_TYPE_SETALLDATA_REPLY_STR);
	if (isSetOK)
		m_UcMsg.append(RET_STR, OK_STR);
	else
		m_UcMsg.append(RET_STR, NG_STR);
}

int Message::ParseSetAllDataReply(bool& isSetOK)
{
	int result = -1;
	if (m_UcMsg.parse(MSG_TYPE_STR) == MSG_TYPE_SETALLDATA_REPLY_STR)
	{
		if (OK_STR == m_UcMsg.parse(RET_STR))
		{
			isSetOK = true;
			result = 0;
		}
		else if (NG_STR == m_UcMsg.parse(RET_STR))
		{
			isSetOK = false;
			result = 0;
		}
	}
	return result;
}

/* ADJUST相关 */
/*
 * 根据输入数组构建调整消息
 * 消息格式为:
 * msg_type: ADJUST
 * adjust_add_num: 3
 * adjust_del_num: 2
 * adjust_del_1: 冀A12345
 * adjust_add_1: 冀A54321
 * adjust_add_2: 冀A55555
 * adjust_add_3: 冀A66666
 * adjust_del_2: 冀A11111
 * */
void Message::CreateAdjustRequest(const vector<AdjustRequest>& adjust_requests)
{
	string key_base = "adjust";
	int add_num = 0;
	int del_num = 0;
	int cur_num = 0;

	m_UcMsg.append(MSG_TYPE_STR, MSG_TYPE_ADJUST_STR);
	for (vector<AdjustRequest>::const_iterator iter = adjust_requests.begin(); iter != adjust_requests.end(); iter++)
	{
		string operate_str = "";
		if ((*iter).adjust_type == ADJUST_TYPE_DEL)
		{
			operate_str = "_del";
			cur_num = ++del_num;
		}
		else
		{
			operate_str = "_add";
			cur_num = ++add_num;
		}
		string num = Utils::Int2String(cur_num);
		m_UcMsg.append(key_base + operate_str + num, (*iter).data);
	}
	//追加增删数量
	m_UcMsg.append(ADJUST_ADD_NUM_STR, Utils::Int2String(add_num));
	m_UcMsg.append(ADJUST_DEL_NUM_STR, Utils::Int2String(del_num));
}

int Message::ParseAdjustRequest(vector<AdjustRequest>& adjust_requests)
{
	int result = -1;

	if (m_UcMsg.parse(MSG_TYPE_STR) == MSG_TYPE_ADJUST_STR)
	{
		int add_num = atoi(m_UcMsg.parse(ADJUST_ADD_NUM_STR).c_str());
		int del_num = atoi(m_UcMsg.parse(ADJUST_DEL_NUM_STR).c_str());
		adjust_requests.clear();
		if (add_num > 0 || del_num > 0)
		{
			string key_base = "adjust";
			string operate_str = "_add";
			int i = 0;
			//追加需要增加的车牌
			for (i = 1; i <= add_num; ++i)
			{
				string key = key_base + operate_str + Utils::Int2String(i);
				string data = m_UcMsg.parse(key);
				AdjustRequest temp = {0};
				temp.adjust_type = ADJUST_TYPE_ADD;
				temp.data = data;
				adjust_requests.push_back(temp);
			}
			operate_str = "_del";
			//追加需要删除的车牌
			for (i = 1; i <= del_num; ++i)
			{
				string key = key_base + operate_str + Utils::Int2String(i);
				string data = m_UcMsg.parse(key);
				AdjustRequest temp = {0};
				temp.adjust_type = ADJUST_TYPE_DEL;
				temp.data = data;
				adjust_requests.push_back(temp);
			}
		}
		result = 0;
	}
	return result;
}

void Message::CreateAdjustReply(bool isAdjustOK)
{
	m_UcMsg.append(MSG_TYPE_STR, MSG_TYPE_ADJUST_REPLY_STR);
	if (isAdjustOK)
		m_UcMsg.append(RET_STR, OK_STR);
	else
		m_UcMsg.append(RET_STR, NG_STR);
}

int Message::ParseAdjustReply(bool& isAdjustOK)
{
	int result = -1;
	if (m_UcMsg.parse(MSG_TYPE_STR) == MSG_TYPE_ADJUST_REPLY_STR)
	{
		if (OK_STR == m_UcMsg.parse(MSG_TYPE_STR))
		{
			isAdjustOK = true;
			result = 0;
		}
		else if (NG_STR == m_UcMsg.parse(MSG_TYPE_STR))
		{
			isAdjustOK = false;
			result = 0;
		}
	}
	return result;
}

/* SYNC相关 */
void Message::CreateSyncRequest(const string& feature)
{
	m_UcMsg.append(MSG_TYPE_STR, MSG_TYPE_SYNC_STR);
	m_UcMsg.append(FEATURE_STR, feature);
}

int Message::ParseSyncRequest(string& feature)
{
	int result = -1;
	if (m_UcMsg.parse(MSG_TYPE_STR) == MSG_TYPE_SYNC_STR)
	{
		feature = m_UcMsg.parse(FEATURE_STR);
		result = 0;
	}
	return result;
}

void Message::CreateSyncReply(const string& ip, int port, const string& feature)
{
	m_UcMsg.append(MSG_TYPE_STR, MSG_TYPE_SYNC_REPLY_STR);
	m_UcMsg.append(IP_STR, ip);
	m_UcMsg.append(PORT_STR, Utils::Int2String(port));
	m_UcMsg.append(FEATURE_STR, feature);
}

int Message::ParseSyncReply(string& ip, int& port, string& feature)
{
	int result = -1;
	if (m_UcMsg.parse(MSG_TYPE_STR) == MSG_TYPE_SYNC_REPLY_STR)
	{
		ip = m_UcMsg.parse(IP_STR);
		port = atoi(m_UcMsg.parse(PORT_STR).c_str());
		feature = m_UcMsg.parse(FEATURE_STR);
		result = 0;
	}
	return result;
}

