/**********************************
 * 数据同步节点动态库
 *********************************/
#ifndef _DATA_SYNC_NODE_DLL_H_
#define _DATA_SYNC_NODE_DLL_H_

#ifdef __cplusplus
extern "C" {
#endif

#include <unistd.h>
#include <time.h>

//函数功能: 获取动态库版本号
//参数: version_str: [out]取出的版本号, 要保证version_str指向的内存长度超过16
//返回值: 0-成功 1-失败
int DataSyncNode_GetVersion(char* version_str);

//函数功能:
//输入参数:
//ip_center - 中心IP
//ip_node - 当前节点IP
//返回值: 0-成功 其他-失败
int DataSyncNode_SetIp(const char* ip_center, const char* ip_node);

//函数功能：设置通信端口(通常不需要设置, 只有在默认端口被占用时才需要调用)
//(当前默认通信端口: 数据上行通信端口-9987, 数据上行通信端口-9986, 数据调整通信端口-9985, 数据同步通信端口-9984)
//输入参数：
//port_up - 数据上行通信端口
//port_down - 数据下行通信端口
//port_adjust - 数据调整通信端口
//port_sync - 数据同步通信端口
//返回值：无
void DataSyncNode_SetPort(int port_up, int port_down, int port_adjust, int port_sync);

//函数功能：注册回调函数. 当中心要求节点更新自己的全数据时回调
//输入参数：	int (*)(const char* data, size_t size) - 回调函数
//返回值：0-成功 其他-失败
//回调函数要求:
//回调函数声明: int (*)(const char* data, size_t size)
//参数:
//data - [in]中心发来的全数据
//size - [in]中心发来全数据的长度
//返回值: 0-成功, 其他-失败
int DataSyncNode_RegUpdateAllDataCmdCallback(int (*)(const char* data, size_t size));

//函数功能：注册数据调整回调. 当中心命令此节点进行数据调整时, 进行回调
//输入参数：	int (*)(const char* data, size_t size, int adjust_type) - 回调函数
//返回值：0-成功 其他-失败
//回调函数要求:
//回调函数声明: int (*)(const char* data, size_t size, int adjust_type)
//参数:
//data - [in]调整数据
//size - [in]调整数据的长度
//adjust_type - [in] 调整类型 0-删除 1-追加
//返回值: 0-成功, 其他-失败
int DataSyncNode_RegAdjustDataCallback(int (*)(const char* data, size_t size, int adjust_type));

//函数功能：注册获取全数据特征的回调函数. 当需要知道当前全数据特征时,进行回调
//输入参数：	int (*)(char* feature, size_t* size) - 回调函数
//返回值：0 - 成功 其他 - 失败
//回调函数要求:
//回调函数声明: int (*)(char* feature, size_t* size)
//参数:
//feature - [out]回调函数内部将特征字串拷贝到此指针指向的地址中
//size - [in/out] in: feature指向buffer的长度, 如果发现要写入数据大于此输入值, 则应返回非0值. Out: 写入数据的长度
//返回值: 0-成功, 其他-失败
//备注: 计算出的特征字符串中不能存在字符'#'
int DataSyncNode_RegGetFeatureCallback(int (*)(char* feature, size_t* size));

//函数功能：注册获取全数据的回调函数. 当需要知道当前节点全数据时,进行回调
//输入参数：	int (*)(char* all_data, size_t* size) - 回调函数
//返回值：0 - 成功 其他 - 失败
//回调函数要求:
//回调函数声明: int (*)(char* all_data, size_t* size)
//参数:
//all_data - [out]回调函数内部将全数据拷贝到此指针指向的地址中
//size - [in/out] in: all_data指向buffer的长度, 如果发现要写入数据大于此输入值, 则应返回非0值. Out: 写入数据的长度
//返回值: 0-成功, 其他-失败
int DataSyncNode_RegGetAllDataCallback(int (*)(char* all_data, size_t* size));

//函数功能：向中心上报数据
//输入参数：
//data - 要发送的数据
//size - 发送数据长度
//返回值： 0 - 成功 其他 - 失败
//备注:此函数返回0, 仅表示加入了发送缓冲队列成功, 并不表示中心真正收到此请求
int DataSyncNode_UploadData(const char* data, size_t size);

//函数功能：启动连接, 在所有回调函数注册完毕, 参数设置完毕后, 调用此函数启动, 启动后, 再注册回调函数, 设置参数将不起任何作用
//输入参数：无
//返回值：0 - 成功 其他 - 失败
int DataSyncNode_Start(void);

#ifdef __cplusplus
}
#endif

#endif /* _DATA_SYNC_NODE_DLL_H_ */
