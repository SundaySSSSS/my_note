#ifndef _DATA_SYNC_COMMON_DLL_H_
#define _DATA_SYNC_COMMON_DLL_H_

//此文件存放一些中心和节点共用的接口
#ifdef __cplusplus
extern "C" {
#endif

/*
 * 功能: 注册日志回调函数, 如果不注册, 则动态库不会写日志
 * 参数:
 * void (*printLogCallback)(const char* log) : 注册的回调函数
 * 返回值: 无
 * */
void DataSync_RegLogCallback(void (*printLogCallback)(const char* log));

#ifdef __cplusplus
}
#endif

#endif /* _DATA_SYNC_COMMON_DLL_H_ */
