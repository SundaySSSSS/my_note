#ifndef _UC_MSG_INTERFACE_H_
#define _UC_MSG_INTERFACE_H_

#include <string>
#include <map>
#include <vector>
#include <iostream>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

namespace ucmsg
{

typedef unsigned char byte;
typedef unsigned int uint32_t;
typedef unsigned long uint64_t;
typedef unsigned short uint16_t;

#define BB_DEFAULT_SIZE (4096)

class ByteBuffer {
public:
	ByteBuffer(size_t size = BB_DEFAULT_SIZE);
	ByteBuffer(const byte* arr, size_t size);

	size_t bytesRemaining(); // Number of uint8_ts from the current read position till the end of the buffer
	void clear(); // Clear our the vector and reset read and write positions
	bool equals(ByteBuffer* other); // Compare if the contents are equivalent
	void resize(size_t newSize);
	size_t size() const ; // Size of internal vector

	// Read
	byte get() const; // Relative get method. Reads the uint8_t at the buffers current position then increments the position
	byte get(int index) const; // Absolute get method. Read uint8_t at index
	void getBytes(byte* buf, size_t len) const; // Absolute read into array buf of length len
	char getChar() const; // Relative
	char getChar(int index) const; // Absolute
	double getDouble() const;
	double getDouble(int index) const;
	float getFloat() const;
	float getFloat(int index) const;
	uint32_t getInt() const;
	uint32_t getInt(int index) const;
	uint64_t getLong() const;
	uint64_t getLong(int index) const;
	uint16_t getShort() const;
	uint16_t getShort(int index) const;

	const byte* getAllData();	//获取全数据的起始地址

	// Write

	void put(const ByteBuffer* src); // Relative write of the entire contents of another ByteBuffer (src)
	void put(byte b); // Relative write
	void put(byte b, uint32_t index); // Absolute write at index
	void putBytes(const byte* b, uint32_t len); // Relative write
	void putBytes(const byte* b, uint32_t len, uint32_t index); // Absolute write starting at index
	void putChar(char value); // Relative
	void putChar(char value, uint32_t index); // Absolute
	void putDouble(double value);
	void putDouble(double value, uint32_t index);
	void putFloat(float value);
	void putFloat(float value, uint32_t index);
	void putInt(uint32_t value);
	void putInt(uint32_t value, uint32_t index);
	void putLong(uint64_t value);
	void putLong(uint64_t value, uint32_t index);
	void putShort(uint16_t value);
	void putShort(uint16_t value, uint32_t index);

	void printAscii();
	void printHex();

	// Buffer Position Accessors & Mutators

	void setReadPos(uint32_t r) {
		rpos = r;
	}

	uint32_t getReadPos() const {
		return rpos;
	}

	void setWritePos(uint32_t w) {
		wpos = w;
	}

	uint32_t getWritePos() const {
		return wpos;
	}

private:
	int wpos;
	mutable int rpos;
	std::vector<byte> buf;

	template<typename T> T read() const {
		T data = read<T>(rpos);
		rpos += sizeof(T);
		return data;
	}

	template<typename T> T read(int index) const {
		if (index + sizeof(T) <= buf.size())
			return *((T*) &buf[index]);
		return 0;
	}

	template<typename T> void append(T data) {
		size_t s = sizeof(data);

		if (size() < (wpos + s))
			buf.resize(wpos + s);
		memcpy(&buf[wpos], (byte*) &data, s);
		//printf("writing %c to %i\n", (uint8_t)data, wpos);

		wpos += s;
	}

	template<typename T> void insert(T data, uint32_t index) {
		if ((index + sizeof(data)) > size())
			return;
		memcpy(&buf[index], (byte*) &data, sizeof(data));
		wpos = index + sizeof(data);
	}
};

class UcMsg
{
public:
    UcMsg();
    UcMsg(const byte* buf, size_t size);
    ~UcMsg();

    //创建消息的方法
    int append(const string& key, const string& value);    //添加一条序列化数据
    int append(const string& key, const byte* data, size_t size);    //添加一条二进制数据
    //解析消息的方法
    string parse(const string& key);	//返回值: 非空-成功 空-失败
    int parse(const string& key, byte* data, size_t& size);

    const byte* getAllData();    //获取全数据地址
    size_t getAllDataLen();       //获取全数据长度

    void printAllData();	//打印全数据

private:
    map<string, string> m_sData;	//存储所有序列化数据
    map<string, ByteBuffer> m_bData;		//存储所有二进制数据, 内存为动态分配
    bool m_isCreated;	//消息是否创建完毕

    ByteBuffer m_allData;
    int writeTotolData();	//将map中的数据写入m_allData中
    int readToMap();		//将m_allData中的数据解析到map中
    int MapToJson(const map<string, string>& map_data, string& json);	//将map转化为json字符串
    int JsonToMap(const string& json, map<string, string>& map_data);
    /*
     * 取得byte字串的亦或校验值
     * 参数:
     * const byte* input - [in]待计算的byte字串
     * size_t len - [in]待计算的byte字串长度
     * 返回值:
     * 计算后的校验值
     * */
    byte getXorValue(const byte* input, size_t len);
};

}	//namespace ucmsg

#endif /* _UC_MSG_INTERFACE_H_ */
