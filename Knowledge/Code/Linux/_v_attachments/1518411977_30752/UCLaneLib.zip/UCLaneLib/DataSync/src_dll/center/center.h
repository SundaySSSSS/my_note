#ifndef _DATA_SYNC_CENTER_H_
#define _DATA_SYNC_CENTER_H_

#include "../global.h"
#include "center_comm.h"
#include "../msg/msg.h"

#define MAX_CMD_QUEUE (64)

class DataSyncCenter
{
private:
	/* 端口 */
	int m_port_up;
	int m_port_adjust;
	int m_port_sync;

	/* socket */
	int m_sock_up;
	int m_sock_adjust;
	int m_sock_sync;

	int CreateSocket(void);	//创建socket
	int StartComm(void);	//开始进行通信

	/* 线程句柄 */
	pthread_t m_up_handle;
	pthread_t m_adjust_handle;
	/* 队列保护互斥量 */
	pthread_mutex_t m_queue_mutex;
	/* 同步保护互斥量 */
	pthread_mutex_t m_sync_mutex;
	/* 同步条件变量 */
	pthread_cond_t m_sync_cond;
	/* 同步条件 */
	bool isReadyForSync;

	/* 通信处理函数 */
	friend void* do_up_comm_center(void* pthis);
	friend void* do_adjust_comm_center(void* pthis);

	/* 命令队列相关 */
	queue<AdjustRequest> m_cmd_queue;
	int cmd_queue_push(AdjustRequest req);	//入队, 返回值: 0-成功 其他-失败
	int cmd_queue_pop(AdjustRequest& req);	//出队, 返回值: 0-成功 其他-失败
	size_t cmd_queue_size();				//获取队列长度
	/* 同步节点信息 */
	vector<NodeSyncInfo> m_NodeSyncList;

	int m_run_flag;	//运行标记

	/* 回调函数注册 */
	int (*m_get_all_data_callback)(char* all_data, size_t* size);
	int (*m_receive_upload_data_callback)(const char* data, size_t size);

	/* 数据同步相关 */
	int (*m_get_feature_callback)(char* feature, size_t* size);
	int CheckAndSyncData(void);	//对当前数据和各节点数据比较, 如果不同, 则进行同步
	int SendSyncDataCmd(string ip, int port);
	int PushSyncReply(Message& msg_reply);
public:
	DataSyncCenter();
	~DataSyncCenter();
	void SetPort(int port_up, int port_adjust, int port_sync);

	//数据同步
	//返回值: 0-成功 其他-失败
	int Sync();

	//启动连接
	int Start();

	int RegGetFeatureCallback(int (*get_feature_callback)(char* feature, size_t* size))
	{
		if (get_feature_callback == NULL)
			return -1;
		m_get_feature_callback = get_feature_callback;
		return 0;
	}

	//注册回应全数据函数
	//回调函数参数:
	//char* all_data : [out]空的buffer, 用于存放全数据
	//size_t size : [in/out]in:输入空buffer的大小, out:写入数据的大小
	//返回值: 0-成功, 其他-失败
	int RegGetAllDataCallback(int (*get_all_data_callback)(char* all_data, size_t* size))
	{
		if (get_all_data_callback == NULL)
			return -1;
		m_get_all_data_callback = get_all_data_callback;
		return 0;
	}
	//注册收到上报数据后的回调
	//回调函数参数:
	//const char* data : [in]上报的数据
	//size_t size : [in]上报数据的大小
	//返回值: 0-成功, 其他-失败
	int RegReceiveUploadDataCallback(int (*receive_upload_data_callback)(const char* data, size_t size))
	{
		if (receive_upload_data_callback == NULL)
			return -1;
		m_receive_upload_data_callback = receive_upload_data_callback;
		return 0;
	}

	//向所有节点发送数据调整命令
	//参数:
	//const char* data: [in]待调整的数据
	//size_t size: [in]待调整数据长度
	//int adjust_type: 调整种类 0-删除 1-追加
	int SendMsg_AdjustDataCmd(const char* data, size_t size, int adjust_type);

};


#endif /* _DATA_SYNC_CENTER_H_ */

