#include <string>
#include <unistd.h>
#include "load_node_dll.h"
#include "../src_data_mng_demo/node_data_mng.h"
#include "../src_data_mng_demo/data_mng.h"
#include "../src_dll/utils/gb2312_str.h"

#define DEFAULT_CENTER_IP "127.0.0.1"
#define DEFAULT_PORT_UP (9987)
#define DEFAULT_PORT_DOWN (9986)
#define DEFAULT_PORT_ADJUST (9985)
#define DEFAULT_PORT_SYNC (9984)

#define DLL_PATH "."

void RandomCreatePlate(int num_base, char* plate)
{
	int num = num_base * 10000 + (int)(9999.0 * rand() / (RAND_MAX + 1.0));
	sprintf(plate, "%s%d", PLATE_HEAD, num);
}

void printLogCallback(const char* log)
{
	printf("%s", log);
}

int main(int argc, char** argv)
{
	if (argc < 2)
	{
		printf("param error, use --help can give some advice\n");
		return 1;
	}

	if (strcmp(argv[1], "--help") == 0)
	{
		printf("Usage: demo_node center_ip local_ip down_port plate_num_base\n");
		printf("e.g. ./demo_node 172.16.4.78 172.16.4.77 8885 1");
		return 0;
	}

	if (argc != 5)
	{
		printf("Not correct param for node\n");
		return 1;
	}
	char server_ip[20] = {0};
	char local_ip[20] = {0};
	int down_port = 0;
	int num_base = 0;
	strcpy(server_ip, argv[1]);
	strcpy(local_ip, argv[2]);
	down_port = atoi(argv[3]);
	num_base = atoi(argv[4]);

	if (DataSyncNodeDll_Init(DLL_PATH) != 0)
		return -1;

	DataSyncNodeDll_SetIp(server_ip, local_ip);
	DataSyncNodeDll_SetPort(DEFAULT_PORT_UP, down_port, DEFAULT_PORT_ADJUST, DEFAULT_PORT_SYNC);

	DataSyncNodeDll_RegUpdateAllDataCmdCallback(node_update_all_data_cmd_callback);
	DataSyncNodeDll_RegAdjustDataCallback(node_adjust_data_callback);
	DataSyncNodeDll_RegGetAllDataCallback(node_get_all_data_callback);
	DataSyncNodeDll_RegGetFeatureCallback(node_get_feature_callback);

	DataSyncDll_RegLogCallback(printLogCallback);

	DataSyncNodeDll_Start();

	while(1)
	{	//每隔一段时间, 发送一个上报车牌
		sleep(5);
		PlateInfo plateInfo;
		RandomCreatePlate(num_base, plateInfo.plate);
		time_t now = time((time_t*)NULL);
		plateInfo.time = now;
		string plateStr = PlateInfoToStr(plateInfo);
		printf("Node: upload data: %s\n", plateStr.c_str());
		DataSyncNodeDll_UploadData(plateStr.c_str(), plateStr.size() + 1);
	}


	DataSyncNodeDll_Free();
	return 0;
}

