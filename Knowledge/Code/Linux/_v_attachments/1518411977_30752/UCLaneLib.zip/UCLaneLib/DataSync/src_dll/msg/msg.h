#ifndef _DATA_SYNC_MSG_H_
#define _DATA_SYNC_MSG_H_

#include "../global.h"

#include "UcMsgInterface.h"
using namespace ucmsg;
/*
 * Json构建规则
 * UPLOAD: { "msg_type": "UPLOAD", "data": "上报数据" }
 * UPLOAD_REPLY: { "msg_type": "UPLOAD_REPLY", "ret": "OK/NG" }
 * GETALLDATA:  { "msg_type": "GETALLDATA" }
 * GETALLDATA_REPLY:  { "msg_type": "GETALLDATA_REPLY", "ret": "OK", "data": "全数据" }
 * GETALLDATA_REPLY:  { "msg_type": "GETALLDATA_REPLY", "ret": "NG" }
 * ADJUST: { "msg_type": "ADJUST", "adjust_data": [ { "adjust_type": "ADD/DEL", "adjust_data": "待调整数据" }, { "adjust_type": "ADD/DEL", "adjust_data": "待调整数据" } ] }
 * OLD -> ADJUST: { "msg_type": "ADJUST", "adjust_type1": "ADD/DEL", "adjust_data1": "待调整数据", "adjust_type2": "ADD/DEL", "adjust_data2": "待调整数据" ...}
 * ADJUST_REPLY: { "msg_type": "ADJUST_REPLY", "ret": "OK/NG" }
 * SYNC: { "msg_type": "SYNC", "feature": "特征" }
 * SYNC_REPLY: 	{ "msg_type": "SYNC_REPLY", "ret": "UNKNOWN", "ip": "节点ip", "port": "节点端口"}
 * 				{ "msg_type": "SYNC_REPLY", "ret": "SAME"	, "ip": "节点ip", "port": "节点端口", "feature": "特征" }
 * 				{ "msg_type": "SYNC_REPLY", "ret": "DIFF"	, "ip": "节点ip", "port": "节点端口", "feature": "特征", "data" : "全数据" }
 * SETALLDATA:  { "msg_type": "SETALLDATA", "data": "全数据" }
 * SETALLDATA_REPLY:  { "msg_type": "SETALLDATA_REPLY", "ret": "OK/NG" }
 * */

typedef enum
{
	SYNC_SAME,
	SYNC_DIFF,
	SYNC_UNKNOWN,
} SyncReply;


/* 调整数据的整包发送机制:
 * 如果每一个调整命令都发送一次调整广播, 广播效率过低, 故采用将需要广播的数据打包发送
 * 当满足如下两个条件之一发送数据包
 * 1, 待发送数据个数大于等于ADJUST_BLOCK_SIZE(目前此值最大支持到5)
 * 2, 达到超时时间ADJUST_TIME_OUT, 且存在待发送数据
 *  */
#define ADJUST_BLOCK_SIZE (32)	//当积累多少个数据时, 进行一次调整(在不超时的情况下)
#define ADJUST_TIME_OUT (10)	//调整的超时时间(单位: 秒), 达到此数值后, 会发送一次adjust数据包

//反馈字符串
#define OK_STR "OK"
#define NG_STR "NG"
//调整命令字串
#define ADD_STR "ADD"
#define DEL_STR "DEL"

//数据集Key
//Map用
#define MSG_TYPE_STR "msg_type"
#define RET_STR "ret"
#define IP_STR "ip"
#define PORT_STR "port"
#define FEATURE_STR "feature"
#define DATA_STR "data"
//调整数据用
#define ADJUST_ADD_NUM_STR "adjust_add_num"
#define ADJUST_DEL_NUM_STR "adjust_del_num"

//消息类型字符串
#define MSG_TYPE_UNINIT_STR "UNINIT"	//未初始化
#define MSG_TYPE_UNKNOWN_STR "UNKNOWN"	//未知类型(初始化过了, 但是不知道是什么类型的消息)
#define MSG_TYPE_UPLOAD_STR "UPLOAD"						//node -> center
#define MSG_TYPE_UPLOAD_REPLY_STR "UPLOAD_REPLY"			//center -> node
#define MSG_TYPE_GETALLDATA_STR "GETALLDATA"				//node -> center
#define MSG_TYPE_GETALLDATA_REPLY_STR "GETALLDATA_REPLY"	//center -> node
#define MSG_TYPE_ADJUST_STR "ADJUST"						//center -> node
#define MSG_TYPE_ADJUST_REPLY_STR "ADJUST_REPLY"			//node -> center
#define MSG_TYPE_SYNC_STR "SYNC"							//center -> node
#define MSG_TYPE_SYNC_REPLY_STR "SYNC_REPLY"				//node -> center
#define MSG_TYPE_SETALLDATA_STR "SETALLDATA"				//center -> node
#define MSG_TYPE_SETALLDATA_REPLY_STR "SETALLDATA_REPLY"	//node -> center

class Message
{
private:
	UcMsg m_UcMsg;
public:
	Message() { ; };
	Message(const byte* buf, size_t size) { m_UcMsg = UcMsg(buf, size); };
	~Message() { ; };

	string GetType() { return m_UcMsg.parse(MSG_TYPE_STR); }

	const byte* getAllData() { return m_UcMsg.getAllData(); }
	size_t getAllDataLen() { return m_UcMsg.getAllDataLen(); }
	void printAllData() { m_UcMsg.printAllData(); }

	/* UP: upload相关 */
	void CreateUploadRequest(const string& upload_data);
	int ParseUploadRequest(string& upload_data);
	void CreateUploadReply(bool isUploadOK);
	int ParseUploadReply(bool& isUploadOK);

	/* UP: Get All Data相关 */
	void CreateGetAllDataRequest();
	int ParseGetAllDataRequest();
	void CreateGetAllDataReply(bool isGetOK, const string& all_data);
	int ParseGetAllDataReply(bool& isGetOK, string& all_data);

	/* DOWN: Set All Data相关 */
	void CreateSetAllDataRequest(const string& all_data);
	int ParseSetAllDataRequest(string& all_data);
	void CreateSetAllDataMsgReply(bool isSetOK);
	int ParseSetAllDataReply(bool& isSetOK);

	/* ADJUST相关 */
	void CreateAdjustRequest(const vector<AdjustRequest>& adjust_requests);
	int ParseAdjustRequest(vector<AdjustRequest>& adjust_requests);
	void CreateAdjustReply(bool isAdjustOK);
	int ParseAdjustReply(bool& isAdjustOK);

	/* SYNC相关 */
	void CreateSyncRequest(const string& feature);
	int ParseSyncRequest(string& feature);
	void CreateSyncReply(const string& ip, int port, const string& feature);
	int ParseSyncReply(string& ip, int& port, string& feature);
};


#endif /* _DATA_SYNC_MSG_H_ */
