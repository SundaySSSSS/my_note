#include <string>
#include <unistd.h>
#include "load_center_dll.h"
#include "../src_data_mng_demo/center_data_mng.h"
#include "../src_data_mng_demo/data_mng.h"
#include "../src_dll/utils/gb2312_str.h"
#include <signal.h>

#define DLL_PATH "."

extern vector<PlateInfo> g_centerPlateList;

void sig_proc(int signo)
{
    printf("signo = %d\n", signo);
}

void printLogCallback(const char* log)
{
	printf("%s", log);
}

int main(int argc, char** argv)
{
	signal(SIGPIPE, sig_proc);

	if (DataSyncCenterDll_Init(DLL_PATH) != 0)
		return -1;

	DataSyncCenterDll_RegReceiveUploadDataCallback(center_receive_upload_data_callback);
	DataSyncCenterDll_RegGetAllDataCallback(center_get_all_data_callback);
	DataSyncCenterDll_RegGetFeatureCallback(center_get_feature_callback);

	DataSyncDll_RegLogCallback(printLogCallback);

	DataSyncCenterDll_Start();
	time_t last_sync_time = time(NULL);
	while(1)
	{
		//检查是否有数据需要删除
		PlateInfo overTimeData;
		while (CheckOldData(g_centerPlateList, 180, overTimeData) == 1)
		{
			CenterDelPlateInfo(overTimeData);
			string plateStr = PlateInfoToStr(overTimeData);
			printf("Center: Data overtime: %s\n", plateStr.c_str());
			DataSyncCenterDll_SendMsg_AdjustDataCmd(plateStr.c_str(), plateStr.size() + 1, 0);
		}

		time_t now = time(NULL);
		if (now - last_sync_time > 180)
		{
			printf("##################SYNC BEGIN!!!!!!!!\n");
			if (DataSyncCenterDll_Sync() != 0)
			{
				printf("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!SYNC ERROR!!!!!!!!\n");
			}
			else
			{
				printf("##################SYNC SUCCESS\n");
			}
			last_sync_time = time(NULL);
		}

		usleep(100000);
	}

	DataSyncCenterDll_Free();
	return 0;
}

