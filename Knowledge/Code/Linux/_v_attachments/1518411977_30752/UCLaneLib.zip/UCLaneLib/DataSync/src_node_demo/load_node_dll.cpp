#include <stdlib.h>
#include <dlfcn.h>
#include <string.h>
#include <stdio.h>
#include "load_node_dll.h"


//动态库函数定义

/********************************数据同步接口*****************************************/
lfDataSyncNode_GetVersion						DataSyncNodeDll_GetVersion;
lfDataSyncNode_SetIp							DataSyncNodeDll_SetIp;
lfDataSyncNode_SetPort					        DataSyncNodeDll_SetPort;
lfDataSyncNode_RegUpdateAllDataCmdCallback		DataSyncNodeDll_RegUpdateAllDataCmdCallback;
lfDataSyncNode_RegAdjustDataCallback			DataSyncNodeDll_RegAdjustDataCallback;
lfDataSyncNode_RegGetFeatureCallback	        DataSyncNodeDll_RegGetFeatureCallback;
lfDataSyncNode_RegGetAllDataCallback			DataSyncNodeDll_RegGetAllDataCallback;
lfDataSyncNode_UploadData			            DataSyncNodeDll_UploadData;
lfDataSyncNode_Start							DataSyncNodeDll_Start;
lfDataSync_RegLogCallback                       DataSyncDll_RegLogCallback;

#define DLL_FILENAME "libdatasync.so"

//本文件全局变量
//动态库句柄
static void	*m_dllHandle = NULL;

//函数功能：	ndk.dll动态库加载
//DllPath	ndk.dll所在路径，结束不要有“\”
//返回值：	0-成功，其他-失败
int	DataSyncNodeDll_Init(const char *DllPath)
{
	int	result = 0;
	char	FileName[256];
	char	*errorInfo;
	if(DllPath == NULL)
	{
		m_dllHandle = dlopen(DLL_FILENAME, RTLD_LAZY);
	}
	else
	{
		sprintf(FileName,"%s/%s",DllPath, DLL_FILENAME);
		m_dllHandle = dlopen(FileName, RTLD_LAZY);
	}
	if(m_dllHandle == NULL)
	{
		errorInfo = dlerror();
		printf("error info = %s\n",errorInfo);
		return 0;
	}

	/********************************数据同步接口*****************************************/
	DataSyncNodeDll_GetVersion = (lfDataSyncNode_GetVersion)dlsym(m_dllHandle,"DataSyncNode_GetVersion");
	if(DataSyncNodeDll_GetVersion == NULL)
	{
		printf("get *DataSyncNode_GetVersion* address failed\n");
		result = -1;
	}
	DataSyncNodeDll_SetIp = (lfDataSyncNode_SetIp)dlsym(m_dllHandle,"DataSyncNode_SetIp");
	if(DataSyncNodeDll_SetIp == NULL)
	{
		printf("get *DataSyncNode_SetIp* address failed\r\n");
		result = -1;
	}
	DataSyncNodeDll_SetPort = (lfDataSyncNode_SetPort)dlsym(m_dllHandle,"DataSyncNode_SetPort");
	if(DataSyncNodeDll_SetPort == NULL)
	{
		printf("get *DataSyncNode_SetPort* address failed\r\n");
		result = -1;
	}
	DataSyncNodeDll_RegUpdateAllDataCmdCallback = (lfDataSyncNode_RegUpdateAllDataCmdCallback)dlsym(m_dllHandle,"DataSyncNode_RegUpdateAllDataCmdCallback");
	if(DataSyncNodeDll_RegUpdateAllDataCmdCallback == NULL)
	{
		printf("get *DataSyncNode_RegUpdateAllDataCmdCallback* address failed\r\n");
		result = -1;
	}
	DataSyncNodeDll_RegAdjustDataCallback = (lfDataSyncNode_RegAdjustDataCallback)dlsym(m_dllHandle,"DataSyncNode_RegAdjustDataCallback");
	if(DataSyncNodeDll_RegAdjustDataCallback == NULL)
	{
		printf("get *DataSyncNode_RegAdjustDataCallback* address failed\r\n");
		result = -1;
	}
	DataSyncNodeDll_RegGetFeatureCallback = (lfDataSyncNode_RegGetFeatureCallback)dlsym(m_dllHandle,"DataSyncNode_RegGetFeatureCallback");
	if(DataSyncNodeDll_RegGetFeatureCallback == NULL)
	{
		printf("get *DataSyncNode_RegGetFeatureCallback* address failed\r\n");
		result = -1;
	}
	DataSyncNodeDll_RegGetAllDataCallback = (lfDataSyncNode_RegGetAllDataCallback)dlsym(m_dllHandle,"DataSyncNode_RegGetAllDataCallback");
	if(DataSyncNodeDll_RegGetAllDataCallback == NULL)
	{
		printf("get *DataSyncNode_RegGetAllDataCallback* address failed\r\n");
		result = -1;
	}
	DataSyncNodeDll_UploadData = (lfDataSyncNode_UploadData)dlsym(m_dllHandle,"DataSyncNode_UploadData");
	if(DataSyncNodeDll_UploadData == NULL)
	{
		printf("get *DataSyncNode_UploadData* address failed\r\n");
		result = -1;
	}
	DataSyncNodeDll_Start = (lfDataSyncNode_Start)dlsym(m_dllHandle,"DataSyncNode_Start");
	if(DataSyncNodeDll_Start == NULL)
	{
		printf("get *DataSyncNode_Start* address failed\r\n");
		result = -1;
	}
	DataSyncDll_RegLogCallback = (lfDataSync_RegLogCallback)dlsym(m_dllHandle,"DataSync_RegLogCallback");
	if(DataSyncDll_RegLogCallback == NULL)
	{
		printf("get *DataSync_RegLogCallback* address failed\r\n");
		result = -1;
	}

	if(result != 0)
	{
		//free so handle
		DataSyncNodeDll_Free();
		return -1;
	}
	printf("DataSyncNodeDll_Init: init dll success\n");
	return result;
}

//函数功能：动态库释放
void DataSyncNodeDll_Free()
{
	if(m_dllHandle != NULL)
	{
		dlclose(m_dllHandle);
		m_dllHandle = NULL;
	}
}




