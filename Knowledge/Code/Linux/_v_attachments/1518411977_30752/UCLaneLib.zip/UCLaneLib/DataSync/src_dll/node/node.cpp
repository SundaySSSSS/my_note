#include "node.h"
#include "../utils/utils.h"

#define SYNC "SYNC"

DataSyncNode::DataSyncNode()
{
	strncpy(m_ip_center, DEFAULT_CENTER_IP, sizeof(m_ip_center));
	m_port_up = DEFAULT_PORT_UP;
	m_port_down = DEFAULT_PORT_DOWN;
	m_port_adjust = DEFAULT_PORT_ADJUST;
	m_port_sync = DEFAULT_PORT_SYNC;

	pthread_mutex_init(&m_queue_mutex, NULL);
	m_update_all_data_cmd_callback = NULL;
	m_adjust_data_callback = NULL;
	m_get_feature_callback = NULL;
	m_get_all_data_callback = NULL;
	m_run_flag = 0;
}

DataSyncNode::~DataSyncNode()
{
	nn_shutdown(m_sock_up, 0);
	nn_shutdown(m_sock_down, 0);
	nn_shutdown(m_sock_adjust, 0);
	nn_shutdown(m_sock_sync, 0);
	pthread_mutex_destroy(&m_queue_mutex);
}

int DataSyncNode::SetIp(const char* ip_center, const char* ip_node)
{
	if (ip_center == NULL || ip_node == NULL)
		return -1;
	strcpy(m_ip_center, ip_center);
	strcpy(m_ip_node, ip_node);
	return 0;
}
void DataSyncNode::SetPort(int port_up, int port_down, int port_adjust, int port_sync)
{
	m_port_up = port_up;
	m_port_down = port_down;
	m_port_adjust = port_adjust;
	m_port_sync = port_sync;
}

int DataSyncNode::CreateSocket(void)
{
	int ret = 0;
	int sock_up = 0;
	int sock_down = 0;
	int sock_adjust = 0;
	int sock_sync = 0;

	sock_up = Utils::CreateSocket_Request(m_ip_center, m_port_up);
	sock_down = Utils::CreateSocket_Reply(m_port_down);
	sock_adjust = Utils::CreateSocket_SurveyNode(m_ip_center, m_port_adjust);
	sock_sync = Utils::CreateSocket_SurveyNode(m_ip_center, m_port_sync);

	if (sock_up < 0 || sock_sync < 0 || sock_down < 0 || sock_adjust < 0)
	{
		dbout("init socket error\n");
		ret = -1;
	}
	else
	{
		m_sock_up = sock_up;
		m_sock_down = sock_down;
		m_sock_adjust = sock_adjust;
		m_sock_sync = sock_sync;
		ret = 0;
	}
	return ret;
}

int DataSyncNode::StartComm(void)
{
	int ret = 0;

	if((pthread_create(&m_up_handle, NULL, do_up_comm_node, this)) != 0)
	{	//创建线程失败
		dbout("create up comm thread error\n");
		ret = -1;
	}
	else
		pthread_detach(m_up_handle);

	if((pthread_create(&m_down_handle, NULL, do_down_comm_node, this)) != 0)
	{	//创建线程失败
		dbout("create down comm thread error\n");
		ret = -1;
	}
	else
		pthread_detach(m_down_handle);

	if((pthread_create(&m_adjust_handle, NULL, do_adjust_comm_node, this)) != 0)
	{	//创建线程失败
		dbout("create adjust comm thread error\n");
		ret = -1;
	}
	else
		pthread_detach(m_adjust_handle);

	if((pthread_create(&m_sync_handle, NULL, do_sync_comm_node, this)) != 0)
	{	//创建线程失败
		dbout("create sync comm thread error\n");
		ret = -1;
	}
	else
		pthread_detach(m_sync_handle);

	return ret;
}

int DataSyncNode::Start()
{
	if (CreateSocket() < 0)
	{
		dbout("create socket error\n");
		return -1;
	}

	m_run_flag = 1;
	if (StartComm() < 0)
	{
		dbout("start communication error\n");
		return -1;
	}

	return 0;
}

int DataSyncNode::UploadData(const char* data, size_t size)
{
	char* pData = NULL;
	int ret = 0;

	if (data == NULL || size == 0)
	{
		dbout("input param error\n");
		return -1;
	}

	pData = new char[size];
	if (pData == NULL)
	{
		dbout("can not get more heap memory\n");
		return -1;
	}
	strncpy(pData, data, size);
	string temp(pData);

	if (send_queue_push(temp) < 0)
	{
		dbout("send queue full\n");
		ret = -1;
	}
	delete[] pData;
	return ret;
}

int DataSyncNode::send_queue_push(string msg)
{
	int ret = 0;

	pthread_mutex_lock(&m_queue_mutex);
	if (m_send_queue.size() >= MAX_SEND_QUEUE)
	{
		ret = -1;
	}
	else
	{
		m_send_queue.push(msg);
	}
	pthread_mutex_unlock(&m_queue_mutex);
	return ret;
}

int DataSyncNode::send_queue_pop(string& msg)
{
	int ret = 0;

	pthread_mutex_lock(&m_queue_mutex);
	if (m_send_queue.size() > 0)
	{
		msg = m_send_queue.front();
		m_send_queue.pop();
	}
	else
	{
		ret = -1;
	}
	pthread_mutex_unlock(&m_queue_mutex);
	return ret;
}



