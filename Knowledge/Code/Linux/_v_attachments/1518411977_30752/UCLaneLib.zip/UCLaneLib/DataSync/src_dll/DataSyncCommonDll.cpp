#include "DataSyncCommonDll.h"
#include "utils/utils.h"

void DataSync_RegLogCallback(void (*printLogCallback)(const char* log))
{
	m_datasync_log_callback = printLogCallback;
}

