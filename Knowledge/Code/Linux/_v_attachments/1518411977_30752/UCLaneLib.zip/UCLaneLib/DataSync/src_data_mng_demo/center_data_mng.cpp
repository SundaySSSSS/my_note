#include "center_data_mng.h"
#include "../src_center_demo/load_center_dll.h"
#include <pthread.h>

vector<PlateInfo> g_centerPlateList;
pthread_mutex_t g_plate_mutex = PTHREAD_MUTEX_INITIALIZER;


int center_get_all_data_callback(char* all_data, size_t* size)
{
	pthread_mutex_lock(&g_plate_mutex);
	int ret = GetAllDataFromVector(all_data, size, g_centerPlateList);
	pthread_mutex_unlock(&g_plate_mutex);
	return ret;
}
int center_receive_upload_data_callback(const char* data, size_t size)
{
	PlateInfo plateInfo;
	StrToPlateInfo(string(data), plateInfo);

	printf("send adjust cmd: %s\n", plateInfo.plate);
	DataSyncCenterDll_SendMsg_AdjustDataCmd(data, size, 1);
	CenterAddPlateInfo(plateInfo);

	return 0;
}
int center_get_feature_callback(char* feature, size_t* size)
{
	pthread_mutex_lock(&g_plate_mutex);
	sprintf(feature, "FEATURE:%d", g_centerPlateList.size());
	*size = strlen(feature) + 1;
	pthread_mutex_unlock(&g_plate_mutex);
	return 0;
}
int center_diff_all_data_callback(const char* data, size_t size)
{
	return 0;
}

void CenterShowPlateInfo(void)
{
	pthread_mutex_lock(&g_plate_mutex);
	for (vector<PlateInfo>::iterator iter = g_centerPlateList.begin(); iter != g_centerPlateList.end(); iter++)
	{
		PlateInfo temp = (*iter);
		cout<< "**********plate: " << temp.plate << " --- time: " << temp.time << endl;
	}
	pthread_mutex_unlock(&g_plate_mutex);
}
void CenterAddPlateInfo(PlateInfo plateInfo)
{
	int is_need_add = 1;

	pthread_mutex_lock(&g_plate_mutex);
	for (vector<PlateInfo>::iterator iter = g_centerPlateList.begin();
			iter != g_centerPlateList.end(); iter++)
	{
		if (strcmp((*iter).plate, plateInfo.plate) == 0)
		{
			printf("CenterAddPlateInfo: already have this plate, ignore\n");
			is_need_add = 0;
			break;
		}
	}
	if (is_need_add == 1)
	{
		g_centerPlateList.push_back(plateInfo);
		printf("CenterAddPlateInfo: add plate: %s, current list size = %d\n",
							plateInfo.plate, g_centerPlateList.size());
	}
	pthread_mutex_unlock(&g_plate_mutex);
}

void CenterDelPlateInfo(PlateInfo plateInfo)
{
	pthread_mutex_lock(&g_plate_mutex);
	vector<PlateInfo>::iterator iter = g_centerPlateList.begin();
	while (iter != g_centerPlateList.end())
	{
		if (strcmp((*iter).plate, plateInfo.plate) == 0)
		{
			iter = g_centerPlateList.erase(iter);
		}
		else
		{
			++iter;
		}
	}
	pthread_mutex_unlock(&g_plate_mutex);
}

int CheckOldData(const vector<PlateInfo>& v, int over_time, PlateInfo& overTimeData)
{
	pthread_mutex_lock(&g_plate_mutex);
	PlateInfo temp;
	int isFoundOldData = 0;

	if (v.size() > 300)
	{
		isFoundOldData = 1;
		temp = v[0];
	}
#if 0
	for (vector<PlateInfo>::const_iterator iter = v.begin(); iter != v.end(); iter++)
	{
		temp = (*iter);
		time_t now = time((time_t*)NULL);
		if (now - temp.time > over_time)
		{	//数据超时
			isFoundOldData = 1;
			break;
		}
	}
#endif /* 0 */
	pthread_mutex_unlock(&g_plate_mutex);
	if (isFoundOldData == 1)
	{
		overTimeData = temp;
		return 1;
	}
	return 0;
}
