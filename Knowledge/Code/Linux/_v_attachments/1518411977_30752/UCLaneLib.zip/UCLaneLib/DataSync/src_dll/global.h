#ifndef _DATA_SYNC_GLOBAL_H_
#define _DATA_SYNC_GLOBAL_H_

#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <assert.h>
#include <time.h>
#include <stdlib.h>
#include <pthread.h>
#include <iostream>
#include <vector>
#include <map>
#include <queue>
#include <string>
#include "nanomsg/nn.h"
#include "nanomsg/reqrep.h"
#include "nanomsg/survey.h"

using namespace std;

// 版本号, 正常情况下, 版本号在Makefile文件中写定
#ifndef VERSION
#define VERSION "1.0.0"
#endif

#define DEFAULT_CENTER_IP "127.0.0.1"
#define DEFAULT_PORT_UP (9987)
#define DEFAULT_PORT_DOWN (9986)
#define DEFAULT_PORT_ADJUST (9985)
#define DEFAULT_PORT_SYNC (9984)

#define ALL_DATA_MAX_SIZE (300 * 1024)
#define FEATURE_MAX (128)

//#define dbout(arg...) do { if (g_isLogOpen) dzlog_debug(arg);} while(0)
//#define dbout(arg...) do { printf("<%s-%d> : ", __FUNCTION__, __LINE__); printf(arg);} while(0)
#define dbout(arg...) do { Utils::writeLog("<%s-%d> : ", __FUNCTION__, __LINE__); Utils::writeLog(arg);} while(0)

typedef struct _AdjustRequest
{
	int adjust_type;
	string data;
}AdjustRequest;

#define ADJUST_TYPE_DEL 0
#define ADJUST_TYPE_ADD 1

typedef struct _NodeSyncInfo
{
	string ip;
	int port;
	string feature;
}
NodeSyncInfo;

//自动化get/set生成器
#define PropertyBuilderByName(type, name, access_permission)\
    access_permission:\
        type m_##name;\
    public:\
    inline void set##name(type v) {\
        m_##name = v;\
    }\
    inline type get##name() {\
        return m_##name;\
    }\


#endif /* _DATA_SYNC_GLOBAL_H_ */
