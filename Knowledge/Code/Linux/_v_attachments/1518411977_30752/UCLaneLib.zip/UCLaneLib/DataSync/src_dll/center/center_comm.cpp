#include "center_comm.h"
#include "center.h"
#include "../utils/utils.h"
#include "../msg/msg.h"

void* do_up_comm_center(void* pthis)
{
	DataSyncCenter* self = (DataSyncCenter*) pthis;
	int sock = self->m_sock_up;
	char* all_data_buf = new char[ALL_DATA_MAX_SIZE];
	if (all_data_buf == NULL)
	{
		dbout("malloc buf failed");
		return (void*) 1;
	}
	if (self->m_receive_upload_data_callback == NULL || self->m_get_all_data_callback == NULL)
	{
		dbout("callback not regist\n");
		return (void*) 1;
	}

	while (1)
	{
		Message msg_recv;
		if (Utils::Msg_Recv(sock, msg_recv) != 0)
		{
			dbout("recv failed\n");
			continue;
		}
		//进行协议解析
		string msg_type = msg_recv.GetType();
		Message msg_send;
		if (msg_type == MSG_TYPE_UPLOAD_STR)
		{
			dbout("upload request\n");
			string upload_data;
			bool isUploadOK = false;
			if (msg_recv.ParseUploadRequest(upload_data) == 0)
			{
				if (self->m_receive_upload_data_callback(upload_data.c_str(), upload_data.size() + 1) == 0)
				{	//处理成功, 返回OK给node
					dbout("upload reply ok\n");
					isUploadOK = true;
				}
				else
					dbout("m_receive_upload_data_callback return failed\n");
			}
			else
				dbout("parse upload request error\n");
			msg_send.CreateUploadReply(isUploadOK);
		}
		else if (msg_type == MSG_TYPE_GETALLDATA_STR)
		{
			dbout("get all data request\n");
			size_t all_data_size = ALL_DATA_MAX_SIZE;
			memset(all_data_buf, 0, ALL_DATA_MAX_SIZE);
			if (self->m_get_all_data_callback(all_data_buf, &all_data_size) == 0)
				msg_send.CreateGetAllDataReply(true, string(all_data_buf));
			else
			{
				dbout("m_get_all_data_callback return error\n");
				msg_send.CreateGetAllDataReply(false, string(""));
			}
		}
		else
		{
			dbout("unknown type: %s\n", msg_type.c_str());
			break;
		}
		/* 回复数据 */
		if (Utils::Msg_Send(sock, msg_send) != 0)
		{
			dbout("reply upload data failed\n");
		}
	}
	delete[] all_data_buf;
	return (void*)0;
}

void* do_adjust_comm_center(void* pthis)
{
	DataSyncCenter* self = (DataSyncCenter*) pthis;
	int sock = self->m_sock_adjust;
	pthread_mutex_t* sync_mutex = &(self->m_sync_mutex);

	vector<AdjustRequest> adjust_requests;
	adjust_requests.clear();
	time_t now = time(NULL);
	time_t last_send_time = time(NULL);

	while (1)
	{
		pthread_mutex_lock(sync_mutex);
		now = time(NULL);
		self->isReadyForSync = false;
		if (self->cmd_queue_size() > ADJUST_BLOCK_SIZE || (now - last_send_time > ADJUST_TIME_OUT))
		{	/* 发送所有数据 */
			dbout("Ready for send adjust data\n");
			AdjustRequest adjust_data;
			while(self->cmd_queue_pop(adjust_data) == 0)
			{
				adjust_requests.push_back(adjust_data);
			}
			/* Send */
			if (adjust_requests.size() > 0)
			{
				Message msg_send;
				dbout("adjust_requests.size() = %d\n", adjust_requests.size());
				msg_send.CreateAdjustRequest(adjust_requests);
				if (Utils::Msg_Send(sock, msg_send) != 0)
				{
					dbout("send request survey failed\n");
					continue;
				}
				/* Receive */
				int reply_count = 0;
				while(1)
				{
					char *buf = NULL;
					int bytes = nn_recv(sock, &buf, NN_MSG, 0);
					if (bytes < 0 && nn_errno() == ETIMEDOUT) break;
					if (bytes >= 0) {
						dbout("receive survey reply\n");
						++reply_count;
						nn_freemsg (buf);
					} else {
						fprintf(stderr, "nn_recv fail: %s\n", nn_strerror(errno));
						break;
					}
				}
				dbout("current receive [%d] survey reply.\n", reply_count);
			}
			else
			{
				dbout("no data, need not adjust\n");
			}
			adjust_requests.clear();
			//满足同步条件
			pthread_cond_signal(&(self->m_sync_cond));
			self->isReadyForSync = true;
			last_send_time = time(NULL);
		}
		else if (self->cmd_queue_size() == 0)
		{
			pthread_cond_signal(&(self->m_sync_cond));
			self->isReadyForSync = true;
		}
		pthread_mutex_unlock(sync_mutex);
		usleep(100000);
	}
	return (void*)0;
}
