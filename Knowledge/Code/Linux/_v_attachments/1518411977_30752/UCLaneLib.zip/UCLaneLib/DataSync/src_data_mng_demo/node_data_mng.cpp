#include "node_data_mng.h"

vector<PlateInfo> g_nodePlateList;


//从内存字符串中获取一行(\n作为标记, 必须以\0结尾)
//返回值:
//非NULL, 下一次需要作为参数送入的指针, 尚未解析完毕
//NULL, 已经全部解析完毕
const char* getLineFromMem(const char* p, string& line)
{
	const char* walker = p;
	const char* ret = NULL;
	size_t size = 0;
	while (1)
	{
		if (*walker == '\n' || *walker == 0)
		{
			size = walker - p;
			char* temp = new char[size + 1];
			memset(temp, 0, size + 1);
			strncpy(temp, p, size);
			line = temp;
			cout << "line: " << line << endl;
			delete[] temp;
			if (*walker == 0)
			{
				ret = NULL;
			}
			else
			{
				ret = ++walker;
			}
			break;
		}
		walker++;
	}
	return ret;
}

void NodeShowPlateInfo(void)
{
	for (vector<PlateInfo>::iterator iter = g_nodePlateList.begin(); iter != g_nodePlateList.end(); iter++)
	{
		PlateInfo temp = (*iter);
		cout<< "**********plate: " << temp.plate << " --- time: " << temp.time << endl;
	}
}

void NodeAddPlateInfo(PlateInfo plateInfo)
{
	g_nodePlateList.push_back(plateInfo);
}

int node_update_all_data_cmd_callback(const char* all_data, size_t size)
{
	g_nodePlateList.clear();

	const char* walker = all_data;
	string line;
	while ((walker = getLineFromMem(walker, line)) != NULL)
	{
		PlateInfo plateInfo;
		StrToPlateInfo(line, plateInfo);
		g_nodePlateList.push_back(plateInfo);
	}
	return 0;
}

int node_adjust_data_callback(const char* data, size_t size, int adjust_type)
{
	string data_str = data;
	string plate;
	string timestr;

	printf("node_adjust_data_callback: adjust cmd come: %s\n", data);

	ParseProtocol(data_str, ":", plate, timestr);

	switch(adjust_type)
	{
	case 0:
		{
			printf("node_adjust_data_callback: delete plate: %s\n", plate.c_str());
			vector<PlateInfo>::iterator iter = g_nodePlateList.begin();
			while (iter != g_nodePlateList.end())
			{
				if ((*iter).plate == plate)
				{
					iter = g_nodePlateList.erase(iter);
					printf("node_adjust_data_callback: delete plate %s success\n", plate.c_str());
				}
				else
				{
					++iter;
				}
			}
		}
		break;
	case 1:
		{
			PlateInfo plateInfo;
			StrToPlateInfo(string(data), plateInfo);
			int is_need_add = 1;
			for (vector<PlateInfo>::iterator iter = g_nodePlateList.begin();
					iter != g_nodePlateList.end(); iter++)
			{
				if (strcmp((*iter).plate, plateInfo.plate) == 0)
				{
					printf("node_adjust_data_callback: already have this plate, ignore\n");
					is_need_add = 0;
					break;
				}
			}
			if (is_need_add == 1)
			{
				g_nodePlateList.push_back(plateInfo);
				printf("node_adjust_data_callback: add plate: %s, current list size = %d\n",
									plateInfo.plate, g_nodePlateList.size());
			}
		}
		break;
	default:
		break;
	}
	return 0;
}

int node_get_feature_callback(char* feature, size_t* size)
{
	sprintf(feature, "FEATURE:%d", g_nodePlateList.size());
	*size = strlen(feature) + 1;
	return 0;
	return 0;
}

int node_get_all_data_callback(char* all_data, size_t* size)
{
	return GetAllDataFromVector(all_data, size, g_nodePlateList);
}

