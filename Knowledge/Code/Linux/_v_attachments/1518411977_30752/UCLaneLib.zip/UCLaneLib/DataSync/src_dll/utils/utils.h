#ifndef _DATA_SYNC_UTILS_H_
#define _DATA_SYNC_UTILS_H_

#include "../global.h"
#include "../msg/msg.h"
using namespace std;

class Utils
{
public:
    //给定ip和端口号制造url, 要保证url足够大
    //返回值: <0:错误 其他:生成的url字符串长度
    static int CreateUrl(char* url, int url_buf_size, const char* ip, int port);

    static int CreateSocket_Request(const char* ip, int port);
    static int CreateSocket_Reply(int port);
    static int CreateSocket_SurveyNode(const char* ip, int port);
    static int CreateSocket_SurveyCenter(int port);
    //发送消息
    //返回值: 0-成功, -1-失败
    static int Msg_Send(int sock, Message& msg);
    //接收消息
    //返回值: 0-成功, <0-失败
    static int Msg_Recv(int sock, Message& msg);


    //协议解析, 将第一个遇到的flag
    //参数:
    //string msg: [in]受到的原始字串
    //string flag: [in]分割字符串
    //string& head: [out]解析出的协议头
    //string& content: [out]解析出的协议内容
    //返回值: 0-成功 其他-错误
    static int ParseProtocol(string msg, string flag, string& head, string& content);

    //分割字符串 (开源代码)
    //参数:
    //const string& s, [in]待分割字符串
    //vector<string>& v, [out]分割后的结果
    //const string& c, [in]分割字符
    static void SplitString(const string& s, vector<string>& v, const string& c);

    //int转string
    //备注: 要求数字为十进制正整数, 且不超过2147483647
    static string Int2String(int i);

    //随机生成一个车牌
    //参数: int num_base, [in] 车牌第一位的数字(用于区分不同地点生成的车牌)
    //	 char* plate, [out]生成的车牌
    static void RandomCreatePlate(int num_base, char* plate);

    static void writeLog(const char* fmt, ...);
};

extern void (*m_datasync_log_callback)(const char* log);

#endif /* _DATA_SYNC_UTILS_H_ */

