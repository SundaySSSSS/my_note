#ifndef _DATA_SYNC_NODE_H_
#define _DATA_SYNC_NODE_H_

#include "../global.h"
#include "node_comm.h"

#define MAX_SEND_QUEUE (64)

class DataSyncNode
{
private:
	/* ip,端口 */
	char m_ip_center[20];
	char m_ip_node[20];

	int m_port_up;
	int m_port_down;
	int m_port_adjust;
	int m_port_sync;

	/* socket */
	int m_sock_up;
	int m_sock_down;
	int m_sock_adjust;
	int m_sock_sync;

	int CreateSocket(void);	//创建socket
	int StartComm(void);	//开始进行通信

	/* 线程句柄 */
	pthread_t m_up_handle;
	pthread_t m_down_handle;
	pthread_t m_adjust_handle;
	pthread_t m_sync_handle;
	/* 队列保护互斥量 */
	pthread_mutex_t m_queue_mutex;

	/* 通信处理函数 */
	friend void* do_up_comm_node(void* pthis);
	friend void* do_down_comm_node(void* pthis);
	friend void* do_adjust_comm_node(void* pthis);
	friend void* do_sync_comm_node(void* pthis);

	/* 发送队列相关 */
	queue<string> m_send_queue;
	int send_queue_push(string msg);	//入队, 返回值: 0-成功 其他-失败
	int send_queue_pop(string& msg);	//出队, 返回值: 0-成功 其他-失败


	int m_run_flag;	//运行标记


	/* 回调函数注册 */
	int (*m_update_all_data_cmd_callback)(const char*, size_t);
	int (*m_adjust_data_callback)(const char*, size_t, int);
	int (*m_get_feature_callback)(char* feature, size_t* size);
	int (*m_get_all_data_callback)(char* all_data, size_t* size);

public:
	DataSyncNode();
	~DataSyncNode();
	/* 可选设置函数, 如果不调用, 则使用默认值 */
	int SetIp(const char* ip_center, const char* ip_node);
	void SetPort(int port_up, int port_down, int port_adjust, int port_sync);
	int Start(void);

	/* 数据控制 */
	//注册全数据获取回调
	int RegUpdateAllDataCmdCallback(int (*update_all_data_cmd_callback)(const char*, size_t))
	{
		if (update_all_data_cmd_callback == NULL)
			return -1;
		m_update_all_data_cmd_callback = update_all_data_cmd_callback;
		return 0;
	}
	//注册数据调整回调
	int RegAdjustDataCallback(int (*adjust_data_callback)(const char*, size_t, int))
	{
		if (adjust_data_callback == NULL)
			return -1;
		m_adjust_data_callback = adjust_data_callback;
		return 0;
	}
	//注册全数据特征计算函数
	//备注: 计算出的特征字符串中不能存在字符'#'
	int RegGetFeatureCallback(int (*get_feature_callback)(char* feature, size_t* size))
	{
		if (get_feature_callback == NULL)
			return -1;
		m_get_feature_callback = get_feature_callback;
		return 0;
	}
	//注册获取全数据回调
	//回调函数参数:
	//char* all_data : [out]空的buffer, 用于存放全数据
	//size_t size : [in/out]in:输入空buffer的大小, out:写入数据的大小
	//返回值: 0-成功, 其他-失败
	int RegGetAllDataCallback(int (*get_all_data_callback)(char* all_data, size_t* size))
	{
		if (get_all_data_callback == NULL)
			return -1;
		m_get_all_data_callback = get_all_data_callback;
		return 0;
	}
	//主动上报一组数据
	int UploadData(const char* data, size_t size);

};

#endif /* _DATA_SYNC_NODE_H_ */
