#include "utils.h"
#include "gb2312_str.h"
#include <stdarg.h>

int Utils::CreateUrl(char* url, int url_buf_size, const char* ip, int port)
{
    if (url == NULL || ip == NULL)
    {
	    dbout("arg error\n");
	    return -1;
    }
    return snprintf(url, url_buf_size, "tcp://%s:%d", ip, port);
}

int Utils::CreateSocket_Request(const char* ip, int port)
{
	char url[128] = {0};
	int sock;

	if ((sock = nn_socket(AF_SP, NN_REQ)) < 0)
	{
		dbout("create socket error\n");
		return -1;
	}
	Utils::CreateUrl(url, sizeof(url), ip, port);

	if (nn_connect(sock, url) < 0)
	{
		dbout("nn_connect socket to %s error\n", url);
		return -1;
	}
	return sock;
}

int Utils::CreateSocket_Reply(int port)
{
	char url[128] = {0};
	int sock;

	if ((sock = nn_socket(AF_SP, NN_REP)) < 0)
	{
		dbout("create socket error\n");
		return -1;
	}
	Utils::CreateUrl(url, sizeof(url), "*", port);
	if (nn_bind(sock, url) < 0)
	{
		dbout("bind socket to %s error\n", url);
		return -1;
	}
	return sock;
}
int Utils::CreateSocket_SurveyNode(const char* ip, int port)
{
	char url[128] = {0};
	int sock;

	if ((sock = nn_socket(AF_SP, NN_RESPONDENT)) < 0)
	{
		dbout("create socket error\n");
		return -1;
	}
	Utils::CreateUrl(url, sizeof(url), ip, port);
	if (nn_connect(sock, url) < 0)
	{
		dbout("connect socket to %s error\n", url);
		return -1;
	}
	return sock;
}
int Utils::CreateSocket_SurveyCenter(int port)
{
	char url[128] = {0};
	int sock;

	if ((sock = nn_socket(AF_SP, NN_SURVEYOR)) < 0)
	{
		dbout("create socket error\n");
		return -1;
	}
	Utils::CreateUrl(url, sizeof(url), "*", port);
	if (nn_bind(sock, url) < 0)
	{
		dbout("bind socket to %s error\n", url);
		return -1;
	}
	return sock;
}

int Utils::ParseProtocol(string msg, string flag, string& head, string& content)
{
	int ret = 0;
	size_t found = msg.find_first_of(flag.data());

	if (found != string::npos)
	{	//找到了协议标记
		string protocol_head = msg.substr(0, found);
		string protocol_content = msg.substr(found + 1);
		head = protocol_head;
		content = protocol_content;
	}
	else
	{
		dbout("not find protocol flag\n");
		ret = -1;
	}

	return ret;
}

void Utils::SplitString(const std::string& s, std::vector<std::string>& v, const std::string& c)
{
	std::string::size_type pos1, pos2;
	pos2 = s.find(c);
	pos1 = 0;
	while(std::string::npos != pos2)
	{
		v.push_back(s.substr(pos1, pos2-pos1));

		pos1 = pos2 + c.size();
		pos2 = s.find(c, pos1);
	}
	if(pos1 != s.length())
	v.push_back(s.substr(pos1));
}

string Utils::Int2String(int i)
{
	char temp[32] = {0};
	snprintf(temp, sizeof(temp), "%d", i);
	string ret = temp;
	return ret;
}

void Utils::RandomCreatePlate(int num_base, char* plate)
{
	int num = num_base * 10000 + (int)(9999.0 * rand() / (RAND_MAX + 1.0));
	sprintf(plate, "%s%d", PLATE_HEAD, num);
}

int Utils::Msg_Send(int sock, Message& msg_send)
{
	size_t data_len = msg_send.getAllDataLen();
	int len = nn_send(sock, msg_send.getAllData(), msg_send.getAllDataLen(), 0);

	if (len != msg_send.getAllDataLen())
		return -1;
	else
		return 0;
}

int Utils::Msg_Recv(int sock, Message& msg_recv)
{
	byte *buf = NULL;
	int len = nn_recv(sock, &buf, NN_MSG, 0);

	if (len < 0)
	{
		if (buf != NULL)
			nn_freemsg(buf);
		return len;
	}
	else
	{
		msg_recv = Message(buf, len);
		nn_freemsg(buf);
		return 0;
	}
}

void (*m_datasync_log_callback)(const char* log) = NULL;	//指向回调函数的指针
static pthread_mutex_t m_log_mutex = PTHREAD_MUTEX_INITIALIZER;

void Utils::writeLog(const char* fmt, ...)
{
	static char log_content[512] = {0};

	if (m_datasync_log_callback == NULL)
		return;

	pthread_mutex_lock(&m_log_mutex);
	va_list args;
	va_start(args, fmt);
	vsnprintf(log_content, sizeof(log_content), fmt, args);
	va_end(args);
	m_datasync_log_callback(log_content);
	pthread_mutex_unlock(&m_log_mutex);
}

