#include "center.h"
#include "center_comm.h"
#include "../utils/utils.h"
#include "../msg/msg.h"

DataSyncCenter::DataSyncCenter()
{
	m_port_up = DEFAULT_PORT_UP;
	m_port_adjust = DEFAULT_PORT_ADJUST;
	m_port_sync = DEFAULT_PORT_SYNC;
	pthread_mutex_init(&m_queue_mutex, NULL);
	pthread_mutex_init(&m_sync_mutex, NULL);
	pthread_cond_init(&m_sync_cond, NULL);
	isReadyForSync = false;
	m_get_all_data_callback = NULL;
	m_receive_upload_data_callback = NULL;
	m_get_feature_callback = NULL;
	m_run_flag = 0;
}

DataSyncCenter::~DataSyncCenter()
{
	nn_shutdown(m_sock_up, 0);
	nn_shutdown(m_sock_adjust, 0);
	nn_shutdown(m_sock_sync, 0);
	pthread_mutex_destroy(&m_queue_mutex);
	pthread_mutex_destroy(&m_sync_mutex);
	pthread_cond_destroy(&m_sync_cond);
}

void DataSyncCenter::SetPort(int port_up, int port_adjust, int port_sync)
{
	m_port_up = port_up;
	m_port_adjust = port_adjust;
	m_port_sync = port_sync;
}

int DataSyncCenter::CreateSocket(void)
{
	int ret = 0;
	int sock_up = 0;
	int sock_down = 0;
	int sock_adjust = 0;
	int sock_sync = 0;

	sock_up = Utils::CreateSocket_Reply(m_port_up);
	sock_adjust = Utils::CreateSocket_SurveyCenter(m_port_adjust);
	sock_sync = Utils::CreateSocket_SurveyCenter(m_port_sync);

	if (sock_up < 0 || sock_sync < 0 || sock_adjust < 0)
	{
		dbout("init socket error\n");
		ret = -1;
	}
	else
	{
		m_sock_up = sock_up;
		m_sock_adjust = sock_adjust;
		m_sock_sync = sock_sync;
		ret = 0;
	}
	return ret;
}

int DataSyncCenter::StartComm(void)
{
	int ret = 0;

	if((pthread_create(&m_up_handle, NULL, do_up_comm_center, this)) != 0)
	{	//创建线程失败
		dbout("create thread error\n");
		ret = -1;
	}
	else
		pthread_detach(m_up_handle);

	if((pthread_create(&m_adjust_handle, NULL, do_adjust_comm_center, this)) != 0)
	{	//创建线程失败
		dbout("create thread error\n");
		ret = -1;
	}
	else
		pthread_detach(m_adjust_handle);

	return ret;
}

int DataSyncCenter::Start()
{
	if (CreateSocket() < 0)
	{
		dbout("create socket error\n");
		return -1;
	}

	m_run_flag = 1;
	if (StartComm() < 0)
	{
		dbout("start communication error\n");
		return -1;
	}

	return 0;
}

int DataSyncCenter::cmd_queue_push(AdjustRequest req)
{
	int ret = 0;

	pthread_mutex_lock(&m_queue_mutex);
	if (m_cmd_queue.size() >= MAX_CMD_QUEUE)
	{
		ret = -1;
	}
	else
	{
		m_cmd_queue.push(req);
	}
	pthread_mutex_unlock(&m_queue_mutex);
	return ret;
}

int DataSyncCenter::cmd_queue_pop(AdjustRequest& req)
{
	int ret = 0;

	pthread_mutex_lock(&m_queue_mutex);
	if (m_cmd_queue.size() > 0)
	{
		req = m_cmd_queue.front();
		m_cmd_queue.pop();
	}
	else
	{
		ret = -1;
	}
	pthread_mutex_unlock(&m_queue_mutex);
	return ret;
}

size_t DataSyncCenter::cmd_queue_size()
{
	size_t size = 0;

	pthread_mutex_lock(&m_queue_mutex);
	size = m_cmd_queue.size();
	pthread_mutex_unlock(&m_queue_mutex);
	return size;
}

int DataSyncCenter::SendMsg_AdjustDataCmd(const char* data, size_t size, int adjust_type)
{
	char* pData = NULL;
	int ret = 0;

	if (data == NULL || size == 0)
	{
		dbout("input param error\n");
		return -1;
	}
	if (adjust_type != ADJUST_TYPE_ADD && adjust_type != ADJUST_TYPE_DEL)
	{
		dbout("adjust type unknown %d\n", adjust_type);
		return -1;
	}

	AdjustRequest req;
	req.data = data;
	req.adjust_type = adjust_type;
	pthread_mutex_lock(&m_sync_mutex);
	if (cmd_queue_push(req) < 0)
	{
		dbout("send queue full\n");
		ret = -1;
	}
	pthread_mutex_unlock(&m_sync_mutex);
	delete[] pData;
	return ret;
}

int DataSyncCenter::CheckAndSyncData(void)
{
	char feature[FEATURE_MAX] = {0};
	size_t feature_size = sizeof (feature);
	if (m_get_feature_callback(feature, &feature_size) != 0)
	{
		dbout("get current feature failed\n");
		return -1;
	}
	string feature_str = feature;
	for (vector<NodeSyncInfo>::iterator iter = m_NodeSyncList.begin(); iter != m_NodeSyncList.end(); iter++)
	{
		if ((*iter).feature != feature_str)
		{
			dbout("feature diff, node: %s, center: %s\n", (*iter).feature.c_str(), feature_str.c_str());
			dbout("send all data to %s:%d\n", (*iter).ip.c_str(), (*iter).port);
			SendSyncDataCmd((*iter).ip, (*iter).port);
		}
	}
	m_NodeSyncList.clear();
	return 0;
}

int DataSyncCenter::SendSyncDataCmd(string ip, int port)
{
	int ret = 0;

	/* 建立down连接 */
	char url[128] = {0};
	int sock;

	if ((sock = nn_socket(AF_SP, NN_REQ)) < 0)
	{
		dbout("create socket error\n");
		return -1;
	}
	Utils::CreateUrl(url, sizeof(url), ip.c_str(), port);

	if (nn_connect(sock, url) < 0)
	{
		dbout("nn_connect socket to %s error\n", url);
		nn_shutdown(sock, 0);
		return -1;
	}

	/* 发送全数据给指定node */
	char* all_data_buf = new char[ALL_DATA_MAX_SIZE];
	size_t all_data_size = ALL_DATA_MAX_SIZE;
	m_get_all_data_callback(all_data_buf, &all_data_size);
	Message msg_send;
	msg_send.CreateSetAllDataRequest(string(all_data_buf));
	if (Utils::Msg_Send(sock, msg_send) != 0)
	{
		dbout("send error\n");
		ret = -1;
	}
	else
	{
		Message msg_recv;
		if (Utils::Msg_Recv(sock, msg_recv) == 0)
		{
			dbout("node replied\n");
			bool isSetOK = false;
			if (msg_recv.ParseSetAllDataReply(isSetOK) == 0)
			{
				if (isSetOK == true)
					dbout("%s:%d sync OK\n", ip.c_str(), port);
				else
					dbout("%s:%d sync NG\n", ip.c_str(), port);
			}
			else
			{
				dbout("parse reply error\n");
			}
		}
		else
		{
			dbout("receive error\n");
			ret = -1;
		}
		dbout("send success\n");
	}
	delete[] all_data_buf;
	nn_shutdown(sock, 0);
	return ret;
}

//解析同步回应
int DataSyncCenter::PushSyncReply(Message& msg_reply)
{
	int ret = 0;
	string ip;
	int port;
	string feature;
	if (msg_reply.ParseSyncReply(ip, port, feature) == 0)
	{
		NodeSyncInfo temp = { ip, port, feature };
		dbout("Node feature feature: %s, ip: %s, port: %d\n",
				temp.feature.c_str(), temp.ip.c_str(), temp.port);
		m_NodeSyncList.push_back(temp);
	}
	else
	{
		dbout("Parse error\n");
		ret = -1;
	}
	return ret;
}

int DataSyncCenter::Sync()
{
	char feature[FEATURE_MAX] = {0};
	size_t feature_size = sizeof (feature);

	if (m_get_feature_callback == NULL)
	{
		return -1;
	}

	pthread_mutex_lock(&m_sync_mutex);

	while (isReadyForSync == false)
	{	//等待满足同步条件
		int s = pthread_cond_wait(&m_sync_cond, &m_sync_mutex);
		if (s != 0)
			dbout("pthread_cond_wait Error!!!!!, return %d\n", s);
	}

	if (m_get_feature_callback(feature, &feature_size) != 0)
	{
		dbout("get feature failed\n");
		pthread_mutex_unlock(&m_sync_mutex);
		return -1;
	}
	Message msg_send;
	msg_send.CreateSyncRequest(string(feature));
	dbout("data sync begin\n");
	if (Utils::Msg_Send(m_sock_sync, msg_send) != 0)
	{
		dbout("send request survey failed\n");
		pthread_mutex_unlock(&m_sync_mutex);
		return -1;
	}
	/* Receive */
	int reply_count = 0;
	while(1)
	{
		char *buf = NULL;
		int bytes = nn_recv(m_sock_sync, &buf, NN_MSG, 0);
		if (bytes < 0 && nn_errno() == ETIMEDOUT) break;
		if (bytes >= 0) {
			dbout("receive survey reply\n");
			++reply_count;
			Message msg_recv((const byte*)buf, bytes);
			if (PushSyncReply(msg_recv) != 0)
			{
				dbout("parse sync reply error\n");
			}
			nn_freemsg (buf);
		} else {
			fprintf(stderr, "nn_recv fail: %s\n", nn_strerror(errno));
			break;
		}
	}
	dbout("current receive [%d] survey reply.\n", reply_count);
	//所有节点都已经回应, 开始使用整合后的全数据与各个节点的特征进行比较, 不相同的进行同步
	int sync_ret = CheckAndSyncData();

	isReadyForSync = false;
	pthread_mutex_unlock(&m_sync_mutex);
	return sync_ret;
}


