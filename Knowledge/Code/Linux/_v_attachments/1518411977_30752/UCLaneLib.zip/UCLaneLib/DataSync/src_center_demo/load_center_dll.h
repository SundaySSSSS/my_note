#ifndef	_LOAD_CENTER_DLL_H_
#define	_LOAD_CENTER_DLL_H_

#include <stdlib.h>

/********************************数据同步动态库接口*****************************************/
//函数功能: 获取动态库版本号
//参数: version_str: [out]取出的版本号, 要保证version_str指向的内存长度超过16
//返回值: 0-成功 1-失败
typedef int (*lfDataSyncCenter_GetVersion)(char* version_str);

//函数功能：设置通信端口(通常不需要设置, 只有在默认端口被占用时才需要调用)
//(当前默认通信端口: 数据上行通信端口-9987, 数据调整通信端口-9985, 数据同步通信端口-9984)
//输入参数：
//port_up - 数据上行通信端口
//port_adjust - 数据调整通信端口
//port_sync - 数据同步通信端口
//返回值：无
typedef void (*lfDataSyncCenter_SetPort)(int port_up, int port_adjust, int port_sync);

//函数功能：注册获取全数据回调函数. 当系统需要知道当前全数据时,进行回调
//输入参数：	int (*)(char* all_data, size_t* size) - 回调函数
//返回值：0 - 成功 其他 - 失败
//回调函数要求:
//回调函数声明: int (*)(char* all_data, size_t* size)
//参数:
//all_data - [out]回调函数内部将数据拷贝到此指针指向的地址中
//size - [in/out] in: all_data指向buffer的长度, 如果发现要写入数据大于此输入值, 则应返回非0值. Out: 写入数据的长度
//返回值: 0-成功, 其他-失败
typedef int (*lfDataSyncCenter_RegGetAllDataCallback)(int (*)(char* all_data, size_t* size));

//函数功能：注册获取全数据特征的回调函数. 当系统需要知道当前全数据特征时,进行回调
//输入参数：	int (*)(char* feature, size_t* size)–回调函数
//返回值：0 - 成功 其他 - 失败
//回调函数要求:
//回调函数声明: int (*)(char* feature, size_t* size)
//参数:
//feature - [out]回调函数内部将特征字串拷贝到此指针指向的地址中
//size - [in/out] in: feature指向buffer的长度, 如果发现要写入数据大于此输入值, 则应返回非0值. Out: 写入数据的长度
//返回值: 0-成功, 其他-失败
typedef int (*lfDataSyncCenter_RegGetFeatureCallback)(int (*)(char* feature, size_t* size));

//函数功能：注册回调函数. 当系统得到某节点上报的数据时,进行回调
//输入参数：int (*)(const char* data, size_t size)–回调函数
//返回值：0 - 成功 其他 - 失败
//回调函数要求:
//回调函数声明: int (*)(const char* data, size_t size)
//参数:	data - [in]上报的数据
//size - [in] data的长度
//返回值: 0-成功, 其他-失败
//备注: 此函数返回时, 要求已经将新数据插入完毕
typedef int (*lfDataSyncCenter_RegReceiveUploadDataCallback)(int (*)(const char* data, size_t size));

//函数功能：向所有节点发送数据调整命令
//输入参数：
//data - 要发送的数据
//size - 发送数据长度
//adjust_type -调整种类 0-删除 1-追加
//返回值： 0 - 成功 其他 - 失败
//备注:此函数返回0, 仅表示加入了发送缓冲队列成功, 并不表示节点真正收到此命令
typedef int (*lfDataSyncCenter_SendMsg_AdjustDataCmd)(const char* data, size_t size, int adjust_type);

//函数功能：手动同步(系统会按照设置的同步周期进行自动同步, 但如果想强制进行一次手动同步, 可以调用此方法)
//输入参数：无
//返回值：0 - 成功 其他 - 失败
typedef int (*lfDataSyncCenter_Sync)(void);

//函数功能：启动连接, 在所有回调函数注册完毕, 参数设置完毕后, 调用此函数启动系统, 系统启动后, 再注册回调函数, 设置参数将不起任何作用
//输入参数：无
//返回值：0 - 成功 其他 - 失败
typedef int (*lfDataSyncCenter_Start)(void);

typedef int (*lfDataSync_RegLogCallback)(void (*printLogCallback)(const char* log));

////////////////////////////////////////////////////////////////////
//函数功能：	动态库加载
//DllPath	动态库所在路径，结束不要有“\”
//返回值：	0成功，1加载动态库失败，2在动态库中找函数失败
int	DataSyncCenterDll_Init(const char *DllPath);

//函数功能：	动态库释放
void DataSyncCenterDll_Free();


/********************************数据同步中心接口*****************************************/
extern lfDataSyncCenter_GetVersion						DataSyncCenterDll_GetVersion;
extern lfDataSyncCenter_SetPort							DataSyncCenterDll_SetPort;
extern lfDataSyncCenter_RegGetAllDataCallback			DataSyncCenterDll_RegGetAllDataCallback;
extern lfDataSyncCenter_RegGetFeatureCallback			DataSyncCenterDll_RegGetFeatureCallback;
extern lfDataSyncCenter_RegReceiveUploadDataCallback	DataSyncCenterDll_RegReceiveUploadDataCallback;
extern lfDataSyncCenter_SendMsg_AdjustDataCmd			DataSyncCenterDll_SendMsg_AdjustDataCmd;
extern lfDataSyncCenter_Sync							DataSyncCenterDll_Sync;
extern lfDataSyncCenter_Start							DataSyncCenterDll_Start;
extern lfDataSync_RegLogCallback                       	DataSyncDll_RegLogCallback;

#endif	/* _LOAD_CENTER_DLL_H_ */
