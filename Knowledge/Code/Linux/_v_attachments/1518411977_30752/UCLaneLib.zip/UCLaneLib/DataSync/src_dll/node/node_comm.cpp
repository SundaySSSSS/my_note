#include "node_comm.h"
#include "node.h"
#include "../msg/msg.h"
#include "../utils/utils.h"

int RequestAllData(int sock, int (*update_all_data_cmd_callback)(const char*, size_t))
{
	int ret = 0;

	if (update_all_data_cmd_callback == NULL)
	{
		dbout("do not regist update_all_data_cmd_callback\n");
		return -1;
	}
	Message msg;
	msg.CreateGetAllDataRequest();
	if (Utils::Msg_Send(sock, msg) != 0)
	{
		dbout("send error\n");
		ret = -1;
	}
	else
	{
		dbout("send ok, waiting reply\n");
		Message replyMsg;
		if (Utils::Msg_Recv(sock, replyMsg) == 0)
		{
			dbout("all data replied\n");
			string all_data;
			bool isGetOK;
			if (replyMsg.ParseGetAllDataReply(isGetOK, all_data) != 0)
			{
				dbout("parse reply error\n");
				ret = -1;
			}
			else
			{
				if (isGetOK)
				{
					if (update_all_data_cmd_callback(all_data.c_str(), all_data.size() + 1) != 0)
					{
						dbout("update_all_data_cmd_callback return error\n");
						ret = -1;
					}
				}
				else
					dbout("center reply NG\n");
			}
		}
		else
		{
			dbout("receive error\n");
			ret = -1;
		}
	}
	return ret;
}

void* do_up_comm_node(void* pthis)
{
	DataSyncNode* self = (DataSyncNode*) pthis;
	int sock = self->m_sock_up;
	int len = 0;

	/* 启动时, 发送获取全数据请求 */
	dbout("send get all data request\n");
	if (RequestAllData(sock, self->m_update_all_data_cmd_callback) < 0)
	{
		dbout("request all data failed\n");
		return (void*)1;
	}

	/* 开始正常运行, 有数据时上报 */
	while (1)
	{
		string upload_data;
		if (self->send_queue_pop(upload_data) == 0)
		{	//有数据等待上报
			Message msg_send;
			msg_send.CreateUploadRequest(upload_data);
			if (Utils::Msg_Send(sock, msg_send) != 0)
			{
				dbout("send error: %s\n", upload_data.c_str());
				continue;
			}
			//接收中心回应
			Message msg_recv;
			if (Utils::Msg_Recv(sock, msg_recv) == 0)
			{
				bool isUploadOK = false;
				if (msg_recv.ParseUploadReply(isUploadOK) != 0)
					dbout("parse reply error\n");
				else
					if (isUploadOK == false)
						dbout("upload failed\n");
			}
			else
				dbout("receive error\n");
		}
		else
		{	//没有待上报的数据
			;
		}
		usleep(100000);
	}

	return (void*)0;
}


void* do_down_comm_node(void* pthis)
{
	DataSyncNode* self = (DataSyncNode*) pthis;
	int sock = self->m_sock_down;

	if (self->m_get_all_data_callback == NULL || self->m_update_all_data_cmd_callback == NULL)
	{
		dbout("callback not regist\n");
		return (void*)1;
	}
	while (1)
	{
		Message msg_recv;
		if (Utils::Msg_Recv(sock, msg_recv) != 0)
		{
			dbout("recv failed\n");
			continue;
		}
		bool isSetOK = false;
		string all_data;
		if (msg_recv.ParseSetAllDataRequest(all_data) == 0)
		{	//中心命令设置此节点的全数据
			if (self->m_update_all_data_cmd_callback(all_data.c_str(), all_data.size() + 1) == 0)
			{
				dbout("update all data success\n");
				isSetOK = true;
			}
			else
			{
				dbout("update all data failed\n");
			}
		}
		else
			dbout("ParseSetAllDataReply error\n");

		Message msg_send;
		msg_send.CreateSetAllDataMsgReply(isSetOK);
		if (Utils::Msg_Send(sock, msg_send) != 0)
		{
			dbout("send reply failed\n");
		}
	}
	return (void*)0;
}

void* do_adjust_comm_node(void* pthis)
{
	DataSyncNode* self = (DataSyncNode*) pthis;
	int sock = self->m_sock_adjust;

	if (self->m_adjust_data_callback == NULL)
	{
		dbout("callback not regist\n");
		return (void*)1;
	}

	while (1)
	{
		Message msg_recv;
		if (Utils::Msg_Recv(sock, msg_recv) == 0)
		{
			vector<AdjustRequest> adjust_requests;
			bool isAdjustOK = false;
			if (msg_recv.ParseAdjustRequest(adjust_requests) == 0)
			{
				for (vector<AdjustRequest>::iterator iter = adjust_requests.begin(); iter != adjust_requests.end(); iter++)
				{
					if (self->m_adjust_data_callback((*iter).data.c_str(), (*iter).data.size() + 1, (*iter).adjust_type) == 0)
					{
						isAdjustOK = true;
						dbout("adjust OK\n");
					}
					else
						dbout("do adjust_data_callback return error\n");
				}
			}
			else
				dbout("parse adjust request error\n");
			Message msg_send;
			msg_send.CreateAdjustReply(isAdjustOK);
			if (Utils::Msg_Send(sock, msg_send) != 0)
			{
				dbout("reply upload data failed\n");
			}
		}
		else
			dbout("recv failed\n");
	}
	return (void*)0;
}


void* do_sync_comm_node(void* pthis)
{
	DataSyncNode* self = (DataSyncNode*) pthis;
	int sock = self->m_sock_sync;
	string ip_node = self->m_ip_node;
	int port_node = self->m_port_down;

	if (self->m_get_feature_callback == NULL || self->m_get_all_data_callback == NULL)
	{
		dbout("callback not regist\n");
		return (void*)1;
	}
	char* all_data_buf = new char[ALL_DATA_MAX_SIZE];
	if (all_data_buf == NULL)
	{
		dbout("malloc mem error\n");
		return (void*)1;
	}

	while (1)
	{
		Message msg_recv;
		if (Utils::Msg_Recv(sock, msg_recv) == 0)
		{
			char local_feature[FEATURE_MAX] = {0};
			string center_feature;
			if (msg_recv.ParseSyncRequest(center_feature) == 0)
			{
				size_t local_feature_size = sizeof(local_feature);
				if (self->m_get_feature_callback(local_feature, &local_feature_size) != 0)
				{
					dbout("get feature failed\n");
				}
			}
			else
				dbout("protocol parse error\n");
			/* 回复数据 */
			Message msg_send;
			msg_send.CreateSyncReply(ip_node, port_node, local_feature);
			if (Utils::Msg_Send(sock, msg_send) != 0)
				dbout("reply upload data failed\n");
		}
		else
			dbout("recv failed\n");
	}
	delete[] all_data_buf;

	return (void*)0;
}
