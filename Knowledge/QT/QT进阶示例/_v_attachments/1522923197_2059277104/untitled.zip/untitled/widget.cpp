#include "widget.h"
#include "ui_widget.h"
#include <QMouseEvent>

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
    // 设置窗口无边框
    this->setWindowFlags(Qt::FramelessWindowHint);
    //阴影效果
    QGraphicsDropShadowEffect *shadow = new QGraphicsDropShadowEffect();
    shadow->setBlurRadius(5);
    shadow->setColor(Qt::black);
    shadow->setOffset(0);
    ui->shadowWidget->setGraphicsEffect(shadow);
    // 将主窗口设置为透明
    this->setAttribute(Qt::WA_TranslucentBackground);
}

Widget::~Widget()
{
    delete ui;
}

void Widget::mousePressEvent(QMouseEvent *event)
{
    QWidget::mousePressEvent(event);
    QPoint screenPos = event->globalPos(); //鼠标相对于整个屏幕的坐标
    QPoint windowPos = this->geometry().topLeft();  //窗口左上角的位置
    this->mouseDragPos = screenPos - windowPos; //鼠标点在窗口中的位置, 利用向量减法可以计算得出
}

void Widget::mouseMoveEvent(QMouseEvent *event)
{
    QWidget::mouseMoveEvent(event);
    QPoint screenPos = event->globalPos(); //在移动中, 获取鼠标相对于整个屏幕的坐标
    QPoint windowPos = screenPos - this->mouseDragPos;
    this->move(windowPos);
}

void Widget::mouseReleaseEvent(QMouseEvent *event)
{
    QWidget::mouseReleaseEvent(event);
    this->mouseDragPos = QPoint();  //放开鼠标时, 重置鼠标拖拽点
}

void Widget::on_btnExit_clicked()
{
    this->close();
}

void Widget::on_btnMax_clicked()
{
    if (this->isMaximized())
        this->showNormal();
    else
        this->showMaximized();
}

void Widget::on_btnMin_clicked()
{
    this->showMinimized();
}
