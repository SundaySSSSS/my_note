#include "calc.h"
#include "ui_calc.h"

calc::calc(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::calc)
{
    ui->setupUi(this);
    displayText = "";
    this->pModel = new model;
}

calc::~calc()
{
    delete ui;
}

void calc::on_btn_0_clicked()
{
    if (displayText != "")
    {
        displayText += this->ui->btn_0->text();
        this->ui->lbl_display->setText(displayText);
    }
}

void calc::on_btn_1_clicked()
{
    displayText += this->ui->btn_1->text();
    this->ui->lbl_display->setText(displayText);
}

void calc::on_btn_2_clicked()
{
    displayText += this->ui->btn_2->text();
    this->ui->lbl_display->setText(displayText);
}

void calc::on_btn_3_clicked()
{
    displayText += this->ui->btn_3->text();
    this->ui->lbl_display->setText(displayText);
}

void calc::on_btn_4_clicked()
{
    displayText += this->ui->btn_4->text();
    this->ui->lbl_display->setText(displayText);
}

void calc::on_btn_5_clicked()
{
    displayText += this->ui->btn_5->text();
    this->ui->lbl_display->setText(displayText);
}

void calc::on_btn_6_clicked()
{
    displayText += this->ui->btn_6->text();
    this->ui->lbl_display->setText(displayText);
}

void calc::on_btn_7_clicked()
{
    displayText += this->ui->btn_7->text();
    this->ui->lbl_display->setText(displayText);
}

void calc::on_btn_8_clicked()
{
    displayText += this->ui->btn_8->text();
    this->ui->lbl_display->setText(displayText);
}

void calc::on_btn_9_clicked()
{
    displayText += this->ui->btn_9->text();
    this->ui->lbl_display->setText(displayText);
}

void calc::flagBtnProcess(QString flag)
{
    int num = displayText.toInt();
    this->pModel->setNum1(num);
    displayText = "";
    this->pModel->setFlag(flag);
}

void calc::on_btn_plus_clicked()
{
    flagBtnProcess(this->ui->btn_plus->text());
}

void calc::on_btn_sub_clicked()
{
    flagBtnProcess(this->ui->btn_sub->text());
}

void calc::on_btn_mul_clicked()
{
    flagBtnProcess(this->ui->btn_mul->text());
}

void calc::on_btn_div_clicked()
{
    flagBtnProcess(this->ui->btn_div->text());
}

void calc::on_btn_equal_clicked()
{
    int num = this->displayText.toInt();
    pModel->setNum2(num);
    QString res = pModel->doCalc();
    this->ui->lbl_display->setText(res);
    displayText = "";
}

void calc::on_btn_clear_clicked()
{
    displayText = "";
    this->ui->lbl_display->setText("0");
    pModel->setNum1(0);
    pModel->setNum2(0);
}
