#include "model.h"
#include <QDebug>

model::model()
{
    num1 = 0;
    num2 = 0;
}

void model::setNum1(int num)
{
    this->num1 = num;
}

void model::setNum2(int num)
{
    this->num2 = num;
}

void model::setFlag(QString flag)
{
    this->flag = flag;
}

QString model::doCalc()
{
    int result = 0;
    if (this->flag == "+")
        result = num1 + num2;
    else if (this->flag == "-")
        result = num1 - num2;
    else if (this->flag == "*")
        result = num1 * num2;
    else if (this->flag == "/")
    {
        if (num2 == 0)
        {
            return "ERROR";
        }
        result = num1 / num2;
    }
    else
    {
        qDebug() << this->flag;
        return "UNKNOWN OPT";
    }
    return QString::number(result);
}
