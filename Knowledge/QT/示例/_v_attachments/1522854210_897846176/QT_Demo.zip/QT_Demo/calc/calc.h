#ifndef CALC_H
#define CALC_H

#include <QDialog>
#include <QString>
#include "model.h"

namespace Ui {
class calc;
}

class calc : public QDialog
{
    Q_OBJECT

public:
    explicit calc(QWidget *parent = 0);
    ~calc();

private slots:
    void on_btn_0_clicked();
    void on_btn_1_clicked();
    void on_btn_2_clicked();
    void on_btn_3_clicked();
    void on_btn_4_clicked();
    void on_btn_5_clicked();
    void on_btn_6_clicked();
    void on_btn_7_clicked();
    void on_btn_8_clicked();
    void on_btn_9_clicked();
    void on_btn_plus_clicked();
    void on_btn_sub_clicked();
    void on_btn_mul_clicked();
    void on_btn_div_clicked();

    void on_btn_equal_clicked();

    void on_btn_clear_clicked();

private:
    Ui::calc *ui;
    model *pModel;
    QString displayText;
    void flagBtnProcess(QString flag);
};

#endif // CALC_H
