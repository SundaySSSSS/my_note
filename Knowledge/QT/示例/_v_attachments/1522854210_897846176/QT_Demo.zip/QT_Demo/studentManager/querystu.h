#ifndef QUERYSTU_H
#define QUERYSTU_H

#include <QDialog>
#include <QStandardItem>
#include <QStandardItemModel>

namespace Ui {
class QueryStu;
}

class QueryStu : public QDialog
{
    Q_OBJECT

public:
    explicit QueryStu(QWidget *parent = 0);
    ~QueryStu();

private slots:
    void on_btn_search_clicked();

private:
    Ui::QueryStu *ui;
    int readFromFile();
    QList<QString> stu_lines;
    void doQuery(int index, QString search_str);
    QStandardItemModel* model;
    void addTableHeader();
    void display(int row, QStringList subs);
};

#endif // QUERYSTU_H
