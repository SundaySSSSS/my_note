#include "querystu.h"
#include "ui_querystu.h"
#include <QFile>
#include <QTextStream>
#include <QMessageBox>
#include <QDebug>


QueryStu::QueryStu(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::QueryStu)
{
    ui->setupUi(this);
    if (readFromFile() == -1)
    {
        QMessageBox::critical(this, "严重错误", "文件打开失败, 请重试");
        this->close();
    }
    this->model = new QStandardItemModel;
    addTableHeader();
}

void QueryStu::addTableHeader()
{
    //设置表头
    model->setHorizontalHeaderItem(0, new QStandardItem("姓名"));
    model->setHorizontalHeaderItem(1, new QStandardItem("学号"));
    model->setHorizontalHeaderItem(2, new QStandardItem("性别"));
    model->setHorizontalHeaderItem(3, new QStandardItem("年龄"));
    model->setHorizontalHeaderItem(4, new QStandardItem("院系"));
    model->setHorizontalHeaderItem(5, new QStandardItem("兴趣"));
    this->ui->tableView->setModel(model);
    this->ui->tableView->setColumnWidth(0, 100);
    this->ui->tableView->setColumnWidth(1, 150);
    this->ui->tableView->setColumnWidth(2, 50);
    this->ui->tableView->setColumnWidth(3, 50);
    this->ui->tableView->setColumnWidth(4, 100);
    this->ui->tableView->setColumnWidth(5, 150);
}

void QueryStu::display(int row, QStringList subs)
{
    for (int i = 0; i < 5; ++i)
    {
        this->model->setItem(row, i, new QStandardItem(subs.at(i)));
    }
    QString ins;
    for (int i = 5; i < subs.length(); ++i)
    {
        ins += subs.at(i) + ",";
    }
    this->model->setItem(row, 5, new QStandardItem(ins));
}

QueryStu::~QueryStu()
{
    delete ui;
}

int QueryStu::readFromFile()
{
    stu_lines.clear();

    QFile file("stu.txt");
    if (! file.open(QIODevice::ReadOnly | QIODevice::Text))
    {
        return -1;
    }
    QTextStream in(&file);
    while(!in.atEnd())
    {
        QString line = in.readLine();
        stu_lines.append(line);
    }
    file.close();
    for (int i = 0; i < stu_lines.length(); ++i)
    {
        qDebug() << stu_lines.at(i);
    }
    return 0;
}

void QueryStu::doQuery(int index, QString search_str)
{
    int row = 0;
    for (int i = 0; i < stu_lines.length(); ++i)
    {
        QString line = stu_lines.at(i);
        line = line.trimmed();  //消除开头结尾可能出现的空格
        QStringList subs = line.split(" ");
        switch(index)
        {
        case 1: //按照姓名查询
            if (search_str == subs.at(0))
            {
                qDebug() << line;
                display(row++, subs);
            }
            break;
        case 2: //按照学号查询
            if (search_str == subs.at(1))
            {
                qDebug() << line;
                display(row++, subs);
            }
            break;
        case 3: //按照院系查询
            if (search_str == subs.at(4))
            {
                qDebug() << line;
                display(row++, subs);
            }
            break;
        default:
            break;
        }

    }
}

void QueryStu::on_btn_search_clicked()
{
    this->model->clear();
    addTableHeader();
    int index = this->ui->cbb_method->currentIndex();
    QString search_str = this->ui->le_search_content->text();
    doQuery(index, search_str);

}
