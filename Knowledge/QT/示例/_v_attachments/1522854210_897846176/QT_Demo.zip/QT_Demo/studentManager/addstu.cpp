#include "addstu.h"
#include "ui_addstu.h"
#include <QString>
#include <QDebug>
#include <QMessageBox>
#include <QFile>
#include <QIODevice>

addStu::addStu(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::addStu)
{
    ui->setupUi(this);
    clearUserInterface();
}

addStu::~addStu()
{
    delete ui;
}

void addStu::on_btn_ok_clicked()
{
    QString name = this->ui->le_name->text();
    QString id = this->ui->le_id->text();
    QString sex = this->ui->sexGroup->checkedButton()->text();
    QString age = this->ui->cbb_age->currentText();
    QString college = this->ui->cbb_college->currentText();

    QString ins = ""; //兴趣字符串
    QList<QAbstractButton*> ins_list = this->ui->insGroup->buttons();
    for (int i = 0; i < ins_list.length(); ++i)
    {
        QAbstractButton* box = ins_list.at(i);
        if (box->isChecked())
        {
            ins += box->text() + " ";
        }
    }

    //对输入信息进行校验
    if (name.length() < 1 || id.length() < 1 || ins.length() < 1)
    {
        QMessageBox::critical(this, "错误", "信息填写不完整, 请重新检查", "确定");
        return;
    }
    QString content = name + '\n' + id + '\n' + age + '\n' + sex + '\n' + college + '\n' + ins;
    QString info = name + " " + id + " " + age + " " + sex + " " + college + " " + ins + "\n";
    int ret = QMessageBox::question(this, "请确认信息", content, "确认", "取消");
    switch(ret)
    {
    case 0: //确认
        clearUserInterface();
        writeToFile(info);
        break;
    default:
        //never reached
        break;
    }
}

void addStu::clearUserInterface()
{
    this->ui->le_name->clear();
    this->ui->le_id->clear();
    this->ui->rbtn_male->setChecked(true);
    this->ui->cbb_age->setCurrentIndex(0);
    this->ui->cbb_college->setCurrentIndex(0);
    QList<QAbstractButton*> ins_list = this->ui->insGroup->buttons();
    for (int i = 0; i < ins_list.length(); ++i)
    {
        QAbstractButton* box = ins_list.at(i);
        box->setChecked(false);
    }
    //恢复焦点
    this->ui->le_name->setFocus();
}

void addStu::writeToFile(QString str)
{
    QFile file("stu.txt");
    if (!file.open(QIODevice::Append | QIODevice::Text))
    {   //打开失败
        QMessageBox::critical(this, "错误", "文件打开失败, 信息没有保存", "确定");
        return;
    }
    QTextStream out(&file);
    out << str;
    file.close();
}


void addStu::on_btn_cancel_clicked()
{
    this->close();
}
