#include "handler.h"

handler::handler(QObject *parent) : QObject(parent)
{

}

handler* handler::pHandler = new handler;

handler * handler::getInstance()
{
    return pHandler;
}

void handler::addScore()
{
    emit beatMouse();
}
