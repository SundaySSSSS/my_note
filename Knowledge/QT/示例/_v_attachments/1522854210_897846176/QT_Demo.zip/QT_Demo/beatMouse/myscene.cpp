#include "myscene.h"
#include <QDebug>

myScene::myScene(QObject *parent) : QGraphicsScene(parent)
{
    for (int i = 0; i < 16; ++i)
    {
        qDebug() << "i = " << i << " 11111";
        this->item[i] = new myItem;
        qDebug() << "22222";
        this->item[i]->setPos(i / 4 * this->item[i]->boundingRect().width(),
                              i % 4 * this->item[i]->boundingRect().height());
        this->addItem(this->item[i]);
        qDebug() << "33333";
    }
    this->ptimer = new QTimer;
    connect(this->ptimer, SIGNAL(timeout()), this, SLOT(showMouse()));
}

void myScene::showMouse()
{
    //重置图片
    for (int i = 0; i < 16; ++i)
    {
        this->item[i]->setPic(":/bg/pic/grand.png");
        this->item[i]->setMouse(false);
    }
    //本次出现的老鼠数量(1-3)
    int count = rand() % 3 + 1;
    for (int i = 0; i < count; ++i)
    {
        //随机生成一个0-15的数, 该位置出现老鼠
        int index = rand() % 16;
        this->item[index]->setPic(":/bg/pic/mouse.png");
        this->item[index]->setMouse(true);
    }
}

void myScene::startGame()
{
    for (int i = 0; i < 16; ++i)
    {
        this->item[i]->setStart(true);
    }
    this->ptimer->start(800);
}

void myScene::pauseGame()
{
    for (int i = 0; i < 16; ++i)
    {
        this->item[i]->setStart(false);
    }
    this->ptimer->stop();
}

void myScene::stopGame()
{
    for (int i = 0; i < 16; ++i)
    {
        this->item[i]->setStart(false);
    }
    this->ptimer->stop();
    //重置图片
    for (int i = 0; i < 16; ++i)
    {
        this->item[i]->setPic(":/bg/pic/grand.png");
        this->item[i]->setMouse(false);
    }
}
