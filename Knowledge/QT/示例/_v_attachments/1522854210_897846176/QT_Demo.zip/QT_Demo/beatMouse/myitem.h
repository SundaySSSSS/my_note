#ifndef MYITEM_H
#define MYITEM_H
#include <QGraphicsPixmapItem>
#include <QString>
#include <QGraphicsSceneMouseEvent>

class myItem : public QGraphicsPixmapItem
{
private:
    bool mouse;
    bool start;
public:
    myItem();
    void setPic(QString path);
    void setMouse(bool mouse);
    bool isMouse();
    void setStart(bool start);
    bool isStart();
    void mousePressEvent(QGraphicsSceneMouseEvent *event);
    void mouseReleaseEvent(QGraphicsSceneMouseEvent *event);
};

#endif // MYITEM_H
