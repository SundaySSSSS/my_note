from django.apps import AppConfig


class HelloappConfig(AppConfig):
    name = 'helloapp'
