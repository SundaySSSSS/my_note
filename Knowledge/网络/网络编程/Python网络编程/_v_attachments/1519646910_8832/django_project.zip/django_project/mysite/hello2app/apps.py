from django.apps import AppConfig


class Hello2AppConfig(AppConfig):
    name = 'hello2app'
