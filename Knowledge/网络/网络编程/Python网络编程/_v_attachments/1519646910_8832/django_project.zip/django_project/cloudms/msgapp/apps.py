from django.apps import AppConfig


class MsgappConfig(AppConfig):
    name = 'msgapp'
